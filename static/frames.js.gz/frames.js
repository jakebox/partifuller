const frames = [`
                                                                                                                    °JJJJJJJJ°°                                    
                                                                                                                 °JJJJJJJJJJJJJJJ°                                 
                                                                                                        °°°°JJJJJJ°°°°°°°°JJJJJJJJJ                                
                                                                                                     °°°°°JJJ°°°°°°°°°°°°°°°°°°JJJJJ°                              
                                                                                                    °°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJRJ                             
                                                                                                  °°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRJ                            
                                                                                                 °°°°°°°°          ° °°°°°°°°°°JJJJJJRR°                           
                                                                                                °°°°°°°              °°°°°°°°°JJJJJJJRRR                           
                                                                                               °°°°°°                °°°°°°°°°JJJJJJJJRRJ                          
                                                                                              °°°°                   °°°°°°°°JJJJJJJJJRRR                          
                                                                                             °°°°                 ° ° °°°°°°JJJJJJJJJJJRR                          
                                                                                            °°°°             °° ° °°°°°°°°°JJJJJJJJJJJJRR°                         
                                                                                           °°°                 °°°°°°°°°°°°°JJJJJJJJJJJRR°                         
                                                                                          °°°                 °°° °°°°°°°°°JJJJJJJJJJJJJR°                         
                                                                                          °°°               °°°°°°°°°°°°°°°°JJJJJJJJJJJJR                          
                                                                                          °°            °°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJR                          
                                                                                         °°°°    °° °°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJ                          
                                               °°°°°°°°                                  °°°°°°°° °°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRJJJJ                           
                                          °°°°°°°°°°°°°JJ°                               °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRRJJ°                           
                                      °°°°°°°°°°°°°°°°°°JJ°                              °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRRR¢J                           
                                    °°°°°°°°°°°°°°°°°°°°°JJJJ°                           °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRR¢J                           
                                   °°°°°°°°°°°°°°°°°°°°°°°JJJJJ°                          J°°°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°°°°°°JJJJJRR¢R                           
                                  °°°°°°°         °°°°°°°°°JJJJJJ°                        °J°°°°°°°°°°°°°°JJJJRRRJ°°°°°°°°°°°°JJJJJJRR¢R                           
                                 °°°°              °°° °°°°°JJJJJJJ°                      °J°°°°°°°°°°°°JJJRRRRRRRJ°°°°°°°°°°°JJJJJJRRR¢°                          
                                °°°°                °°°°°°°°°°JJJJJJ°                      JJ°°°°°°°°°°JJRRRRRRRRRRRJJJJJJJ°°JJJJJJJRRRRJ°°°°°°°°°                 
                                °°°                 °  °°°°°°°°JJJJJJJ                      JJ°°°°°°°°JRRRRRRRRRRRRRRRRRRRRJJJ°JJJJJRRRRJ°°°°°°°°°°                
                               °°°                    °  °°°°°°°JJJJJJJ°                    °JJJ°°JJ°JJRRRRRRRRRRRRRRRRRRRRRRJ°JJJJJRRRRJ°°°°°°°°°°                
                              °°°°                       °°°°°°°°JJJJJJJ°                    °JJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRJ°JJJJR¢RRRJ °°°°°°°°°               
                             °°°                         °°°°°°°°°°JJJJJJJ                    °RJJJJRRRRRRRRRRRRJJJRJJRRRRRRRRJ°JJJJR¢RRRJ° °°°°°°°°               
                             °°°                       °°°° °°°°°°°°JJJJJJJ                    RRJRRRRRRRRRRRRRJJJJJJJRRRRRRRRJ°JJJJR¢RRRJ°   °°°°°°               
                            °°°                        °°° °°°°°°°°°JJJJJJJJ                   RRJRRRRRRRRRRRRRJJJJJJJJJRRRRRRRJJJJRRRRRRJ     °°°°J°              
                           °°°°                        °°°°°°°°°°°°°JJJJJJJJJ                  JRJJRRRRRRJRJRRRRJJJJJJJJJRRRRRRRJJJRRRRRRR     °°°°°J              
                           °°°°°                    °°°° °°°°°°°°°°°JJJJJJJJJJ                 °RJJRRRRRRRJJRRRJJJJJJJJJJRRRRRRRRRRRRR¢RRR°    °°°°°J              
                          °°°°                   ° °°°°°°°°°°°°°°°°JJJJJJJJJJJ                  RRJRRRRRRJJJRRRJJJJJJJJJJRRRRRRRRRRRRR¢RRRJ    J°°°°J              
                          °°°°°        °  ° °   °° °°°°°°°°°°°°°°°°JJJJJJJJJJJJ                 RRJRRRRRRJJJJRRJJJJJJJJJJJRRRRRRRRRRRRRRRRR    J°°°°J              
                          °°°°°°°°             °°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJ                 RRJJRRRRJJJJJJRJJJJJJJJJJJRRRRRRRRRRRRRRRRR   °J°°°°J              
                          °°°°°°°°  °    °  °°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJRR                 °RRJRRRRJJJJJJRJJJJJJJJJJJRRRRRRRRRRRRRRRRR°  °J°°°°J              
                          °°°°°°°°°°°   °° °°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJR                  RRJRRRRJJJJJJRJJJJJJJJJJJJRRRRRRRRRRRRRRRR°  °J°°°°°              
                          J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJR                  RRJRRRRJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJ  °J°°°°°              
                          °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJR°                 JRJJRRJJJJJJJJJJJJJJJJJJJJJJRJRRJJJJRRRRRRR °J°°°°°               
                           J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJ                 °RJJRJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJRRRRRR°JJ°°° °               
                           °J°°°°°JJJJJ°°°°°°°°°°°°°°°°°°°°°°°J°°°JJJJJJJJJJJJJJ                  RRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJ°°°° °               
                            JJ°°JJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJ                  RR°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJ°°°                  
                           °JJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJ                  JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°°°°                  
                    °°°°°°°°JJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJ°                  °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJ°°°                   
                 °°°      °°JRRRJJJJRRRRRRJJ°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJ                    RRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°                    
                °°        °°JJJRRRJRJJJJRRRJJ°°J°°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJ                    JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°                    
                ° °       °°JJJRRJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                    JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR°                    
               °°         °°°JJRRJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                    °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRR¢RJ                    
               °°         °°°JJRJJJJJJJJJJJJJJRRRRJJJJJJJJJJRRRRRJJJJJRRRJJJJ°                      RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRR¢°                    
               °°    °°  °°°°JRRJJJJJJJJJJJJJRRRJJJJJRRJRRRRRRRRRRRRRRRRRJJJ°                       JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRR¢J                    
              °°°         °°JJRRJJJJJJJJJJJJJJRJJJJJJJJJJJJRRRRRRRRRRRRRRJ°°                        °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRR¢R                    
              °°°         °JJJRRJJJJJJJJJJJJJRRJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                         °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRR¢R                    
              °J°         JJJJRRJJJJJJJJJJJJJRRJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                          JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRR¢R                    
              °J°  °°     JJJJRJJJJJJJJJJJJJJRJJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                          JJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRR¢°                   
              JJ°  °°     JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                          °JJJRJJJJJJJJRJRJJJRRRRRRRRRRRRRRRRRRRRRR¢J                   
              JJ°  °°     JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJRJ°°                          °JJJRRRRRRJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢R                   
              °J°  °°     JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°°                           JJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢R                   
              °J° °°°°   °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJJJJ°                            °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                   
              °J°  °°°   °JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJJJJ°                            °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢RRRRR°                  
               J° ° °°J  °JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJRRJJJJ°°                             °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢RJRRRJ                  
               J° °°°°J  JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJRRJRJJJ°°                             °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJRJJ                  
               J°  °°°°° JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJRJRJJJ°°                              °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJ°J                  
               °J  °°°°J°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJRRJRJJJJ°°                              °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°°J°                 
                J°  °°°°°JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJRJJJJ°°                              °°JRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ°°RJ°°R°                 
                J°    °°°JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJJ°°                               °JJRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ°°°°°°°JJJ                 
                °°     °°JJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJ°°°                               °JJRRRRRRRRRRRRRRRRJJJJJJJJJJ°°°°°  °J°JJJ                 
                 °°    °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°°°                               °JJJRRRJRRJRJJJJJJJJJJJJJJJ°°°°°°°°°JJJ°JJ                 
                  °   °°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                 °JJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°JJJ°°J°                 
                   °  °°JRJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°°°                                 °JJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°JJ°°                  
                    ° °°RRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                 °°JRJJ°°°°°°°°°°°°°°°°°°°°°°°°     °JJ°°                  
                     °JJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                 °°JRRJJ°°°°°°°°°°°°°°°°°°°°°°       °°°                   
                      JJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                 °°JRJJJ°°°JJJJJJJ°°°°°°°°°°                               
                      °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                   °JRRRRJJJJJJJJ°°°°°°°°°°°                                
                      °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                   °JRRRRJJJJJ°°°°°°°°                                      
                      JRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                   °JRRRRJ°°°°°°°°°          °°                             
                      JRRR¢RRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                    °JRRRJ°°°°°°°°         °°                               
                      JRRR¢RRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                     °JRRJ°°°°°°°°°                                         
                      RRRR¢RRRRRRRRJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                        °J°°°°°°°°°°°                                        
                      RRRR¢RRRRRRRRRRJJJRRRRRRRRRJJJJJJRRRJJJJJRJJJJ°°                                                                                             
                     °RRRRRRRRRRRRRRRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                             
                     JRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                             
                     JRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                             
                     R¢RR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    °RRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    °¢RR¢¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°°°                                                                                              
                    JRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    JRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    JJRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    RJJJRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°                                                                                               
                   °RJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                               
                   JRRJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                               
                   J¢RJJJJ°°JJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                               
                   RRRRJJJ°°°°°JJJJJJJJJJRRRRRRRRRRRRRRRRRRRRJJJJ°°                                                                                                
                   RRRJRRJJ°°°°°°°JJJJJJJJJJJJJJRRRRRRRRJRJJJJJJJ°°                                                                                                
                   RRJJJRRJJJJ°°°°°°°JJJJJJJJJJJJJJJRJJJJJJJJJJJJ°°                                                                                                
                   JJJJJRJJ°°°°°°°J°°°°°°°°°°°JJJRRRRJJJJJJJJJJJJ°°                                                                                                
                    JJ°RRJ°°°°°°°°°°°°°°°°°°°°°°°°°°J°°°°°°°°JJJJ°°                                                                                                
                    JJ°RR°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°°°                                                                                                
                    °J°JJ°°°°°°°°°°°          °°°°JJ°°°°JJJ°JJJJ°°                                                                                                 
                     °JJ°°      °°°              °°°°  °°°JJRRRJ°°                                                                                                 
                      °J°°     °°°°°°°°                  °°JRJJJ°°                                                                                                 
                        °°  ° °°°  °°°°                  ° JRJJJ°                                                                                                  
                            °°°°°  °°            °°  °° °°°JRJJJ°                                                                                                  
                            °°°°°   °°°°°°°°    °°  °°° ° °JJJJ°                                                                                                   
                                °°°°°°°°°°°°°°°°°°°°°°°°°°°JRJJ                                                                                                    
                                      °°°°°°°°°°°°°°°°°°°°°J°J                                                                                                     
                                         °°°°°°°     °°°°°                                                                                                         
`,`
                                                                                                                   °°JJJJJJJJ°                                     
                                                                                                                °°JJJJJJJJJJJJJJ°                                  
                                                                                                        °°°°JJJJJJ°°°°°°°°JJJJJJJJ°                                
                                                                                                     °°°°JJJJ°°°°°°°°°°°°°°°°JJJJJJJ                               
                                                                                                   °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJR°                             
                                                                                                  °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJRR°                            
                                                                                                 °°°°°°°°           °°°°°°°°°°°JJJJJRRR                            
                                                                                               °°°°°°°               °°°°°°°°°JJJJJJJRRJ                           
                                                                                              °°°°°°                 °°°°°°°°JJJJJJJJRRR                           
                                                                                              °°°°                   °°°°°°°°JJJJJJJJJRRJ                          
                                                                                             °°°                   °°°°°°°°°JJJJJJJJJJRRR                          
                                                                                            °°°               °  °°°°°°°°°°JJJJJJJJJJJRRR                          
                                                                                           °°°                °°°  °°°°°°°°JJJJJJJJJJJRRR                          
                                                                                          °°°                °°° °°°°°°°°°°JJJJJJJJJJJJRR                          
                                                                                          °°               °°°°°°°°°°°°°°°°JJJJJJJJJJJJJR                          
                                                                                         °°°           °°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJRJ                          
                                                                                         °°°°   ° °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJ                           
                                               °°°°°°°°°                                 °°°°°°° ° °°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRJJJJ                           
                                           °°°°°°°°°°°°°J°                               J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRJR                            
                                      °°°°°°°°°°°°°°°°°°JJJ                              J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRRR°                           
                                    °°°°°°°°°°°°°°°°°°°°°JJJJ°°                          °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRR¢°                           
                                   °°°°°°°°°°° °°°°°°°°°°°JJJJJJ°                        °J°°°°°°°°°°°°°°°°°°JJJ°°°°°°°°°°°°°°JJJJJRRR¢J                           
                                  °°°°°°°         °°°°°°°°°°JJJJJJ°                       J°°°°°°°°°°°°°°°JJJJRRJ°°°°°°°°°°°°°JJJJJJRR¢R                           
                                  °°°°               ° °°°°°°JJJJJJ°                      °J°°°°°°°°°°°°JJRRRRRRRRJ°°°°°°°°°°°JJJJJJRR¢R                           
                                 °°°                °° °°°°°°°JJJJJJJ                      JJ°°°°°°°°°°JRRRRRRRRRRRJJ°J°JJJ°°JJJJJJJRRRRJ°°°°°°°°                  
                                °°°                     °°°°°°°°JJJJJJ°                    °JJ°°°°°°°°JRRRRRRRRRRRRRRRRRRRJJJ°JJJJJJRRRRJ°°°°°°°°°                 
                               °°°                     ° °°°°°°°°JJJJJJJ                    JJJJ°JJJ°JRRRRRRRRRRRRRRRRRRRRRRJ°JJJJJJ¢RRRJ°°°°°°°°°°                
                              °°°°                       °°°°°°°°JJJJJJJJ                    °JJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRJ°JJJJJRRRRJ° °°°°°°°°°               
                              °°°                       ° °°°°°°°°°JJJJJJJ°                   JJJJJRRRRRRRRRRRRRRJRRRRRRRRRRRR°JJJJJRRRRRJ °°°°°°°°°               
                             °°°                        °°° °°°°°°°°JJJJJJJ°                  J¢JJRRRRRRRRRRRRRRJJJJJJJRRRRRRRJ°JJJRR¢RRRJ°  °°°°°°°               
                            °°°°                        °°°°°°°°°°J°JJJJJJJJ°                  RRJRRRRRRRRJRRRRJJJJJJJJRRRRRRRRJJJJRR¢RRRJ    °°°°°°               
                            °°°°                       °°°°°°°°°°°°°JJJJJJJJJ°                 RRJRRRRRRRRJRRRRJJJJJJJJJRRRRRRRJJJRRRRRRRJ    °°°°°°°              
                           °°°°°                     °°°°°°°°°°°°°°°JJJJJJJJJJ                 JRJJRRRRRRRJJRRRJJJJJJJJJJRRRRRRRRRRRRRRRRR    °J°°°°°              
                           °°°°                   ° °°°°°°°°°°°°°°°JJJJJJJJJJJJ                °¢JJRRRRRJJJJRRRJJJJJJJJJJRRRRRRRRRRRRRRRRR°    J°°°°°              
                          °°°°°             °     °°°°°°°°°°°°°°°°°JJJJJJJJJJJJ                 RRJRRRRRJJJJRRRJJJJJJJJJJRRRRRRRRRRRRRRRRRJ   °J°°°°°              
                          °°°°°°°°°          °  °  °°°°°°°°°°°°°°°°JJJJJJJJJJJR°                RRJJRRRRJJJJJJRJJJJJJJJJJJRRRRRRRRRRRRRRRRJ   °°°°°°°              
                          °°°°°°°°° °   ° °°°° °°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJRJ                RRJJRRRRRJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRR   °°°°°°°              
                          °°°°°°°°°°°    ° °°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJRJ                °RJJJRRRJJJJJJRJJJJJJJJJJJRRRRRRRRRRRRRRRRR   °°°°°°               
                          °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJRJ                 RRJJRRJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRR°  °°°°°°               
                           J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJR                 RRJJRRJJJJJJJJJJJJJJJJJJJJJRJRRJJJJRRRRRRRJ °J°°° °               
                           °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJR                 JRJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJ JJ°°° °               
                            J°°°°°JJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJ                 °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJ°°°°                 
                            °JJ°°°JJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJ                  RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°°°°                  
                          °°°JJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJ                  RRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°°°°                  
                    °°°°°°°°JJJJJJJ°JJJJJJJJ°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJ                  JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°°°                   
                  °°       °°JRRRJJJRRRRRRRJ°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJ                  °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°°                    
                 °         °°JJRRRRJJRJJJRRRJJ°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJ°                   RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ                     
                °°        °°°JJRRRJJJJJJJJJJJJJJJJJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJ                    JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°                    
               °°°        °°°JJRRJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                    JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRR¢R°                    
               °°         °°°JJRRJJJJJJJJJJJJJRRRRRRJJJJJJJJJRRRRRJJJJJRRJJJJJ                     °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRR¢R                     
               °°     °   °°°JJRRJJJJJJJJJJJJJRRJJJJJRJRRRRRRRRRRRRRRRRRRJJJ°                       JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRR¢¢                     
               °°          °JJJRJJJJJJJJJJJJJJRRJJJJJJJJJJRRRRRRRRRRRRRRRJJ°                        JJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRR¢J                    
              °J°          JJJJRJJJJJJJJJJJJJJRJJJJJJJJJJJJRRRRRRRRRRRRRJJJ°                        °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRR¢J                    
              °J°         °JJJRRJJJJJJJJJJJJJJRJJJJJJJJJJJJRRRRRRRRRRRRRJJ°°                        °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRR¢R                    
              °J°° °°     °JJJRRJJJJJJJJJJJJJJRJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                          JJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRR¢R                    
              °J°  °°     JJJJRRJJJJJJJJJJJJJRJJJJJJJJJJJJJRRRRRRRRRRRRJJJ°                          °JJRJJJJJJJJJJRRJJRRRRRRRRRRRRRRRRRRRRRRR¢                    
              °J°° °°°    JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJ°                          °JJRRRRRRRJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢°                   
              °J°  °°°    JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°°                          °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢J                   
               J°  °°°    JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJJJJ°°                           JJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢RRRRR                   
               J°  °°°°   JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJJJJ°                            °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢¢RRRRR                   
               J° °°°°°  °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJRRJRJJJJ°                            °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢RRRRJ°                  
               J°  °°°°° °JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRJJJJ°°                            °°JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJRJJ°                  
               °J  °°°°° °JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJRJRJJJJ°°                             °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJ°°J                  
               °J° °°°°JJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJJ°°                             °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°°°J                  
                J°  °°°°°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJRJJJJJJ°°                              °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ°JJ°°JR                  
                °°    °°°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJ°°                              °°JRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ°°°°°°°°JR°                 
                 °°    °°JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJJ°°                               °JRRRRRRRRRRRRRRRRRJJJJJJJJJJ°°°°° °°°JJJ°                 
                 °°    °°JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°°°                               °JJRJRRJJJJJRJJJJJJJJJJJJJ°°°°°°°°°°JJ°JJ°                 
                  °   °°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                               °JJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°JJJ°°J                  
                   °  °°JRJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                °JJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°JJ°°°                  
                      °°RRJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                 °°RJRJ°°°°°°°°°°°°°°°°°°°°°°°°     °J°°                   
                     °°JRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                 °°RRRJ°°°°°°°°°°°°°°°°°°°°°°°       °°                    
                      JJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                 °°RRJJJ°°JJJJJJJJ°°°°°°°°°                                
                       JRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                 °°RRRRRJJJJJJJJ°°°°°°°°°°°                                
                       RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                   °JRRRRJJJJ°°°°°°°°° °                                    
                       RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                   °JRRRRJ°°°°°°°°°         °°°                             
                      °RRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                    °RRRRJ°°°°°°°°        °°                                
                      JRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                     °RRRJ°°°°°°°°                                          
                      JRRR¢RRRRRRRRJJJJJJJRJJJJJJJJJJJJJRJJJJJJJJJJJJ°°                                      °°J°°°°°°°°°°                                         
                      RRRR¢RRRRRRRRRRJJJRRRRRRRRRRRJJJJRRRJJJJJJRJJJ°°°                                                                                            
                      RRRR¢RRRRRRRRRRRRJRRRRRRRRRRRRRRRRRRRRRJRRRRJJ°°                                                                                             
                     °RRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                             
                     °RRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                             
                     JRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                             
                     R¢RR¢¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                     RRRR¢¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    °RRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    JJRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    JJJR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    JJJJRRJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    JJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                               
                    RRJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                               
                   °¢RRJJJ°°°JJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                               
                   JRRRJJJ°°°°°°JJJJJJJJJJRRRRRRRRRRRRRRRRRRRRJJJJ°°                                                                                               
                   JRRJJRJJ°°°°°°°°JJJJJJJJJJJJJJRRRRRRRJRJJJJJJJ°°                                                                                                
                   JRJJJRRJJJJJ°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                                                                                
                   °JJJJRRJ°°°°°°°°°°°°°°°°°°°JJJRRRRRJJJJJJJJJJJ°°                                                                                                
                    JJJJRJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°J°°                                                                                                
                    JJ°JRJ°°°°°°°°°°°°°°°°°°°°°J°°°°°°°°°°°°°°°JJ°°                                                                                                
                     J°JJ°°°°°°°°°°°         °°°°°JJ°°°°°JJ°°JJJJ°°                                                                                                
                      JJJ°°      °°               °°°  °°°°JJRRR°°                                                                                                 
                       J°°      °° °°°°            °     °°JRJJJ°°                                                                                                 
                        °°    °°°°  °°°            °     °°°RJJJ°°                                                                                                 
                           °°°°°°° °°            °°  °°°°°°JRJJJ°                                                                                                  
                             °°°°   °°°°°°°°°    ° °°°°°°  JJJJJ                                                                                                   
                                °° °°°°°°°°°°°°°°°°°°°°°°°°JJJJ                                                                                                    
                                      °°°°°°°°°°°°°°°°°°°°°JJJ                                                                                                     
                                         °°°°°°°°    °°°°°                                                                                                         
`,`
                                                                                                                    °°°°°°                                         
                                                                                                                °JJJJJJJJJJJ°°                                     
                                                                                                      °°°°°°°°JJJJJ°JJJJJJJJJJJ°                                   
                                                                                                   °°°°JJJ°°°°°°°°°°°°°°°°JJJJJJJ°                                 
                                                                                                 °°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJRJ                                
                                                                                                °°°°°°°°° °° °°°°°°°°°°°°°°°°JJJJJRR                               
                                                                                              °°°°°°°°            °°°°°°°°°°°JJJJJJRR                              
                                                                                             °°°°°°                °°°°°°°°°°°JJJJJRRJ                             
                                                                                            °°°°°                   °°°°°°°°°JJJJJJRRR                             
                                                                                           °°°°                    °°°°°°°°JJJJJJJJJRRJ                            
                                                                                           °°°                     °°°°°°°JJJJJJJJJJRRR                            
                                                                                          °°°                     °°°°°°°JJJJJJJJJJJRRR                            
                                                                                         °°°                      °°°°°°°JJJJJJJJJJJJRR                            
                                                                                        °°°                 °   °°°°°°°°°°JJJJJJJJJJJRR                            
                                                                                        °°               °°°° °°°°°°°°°°°°JJJJJJJJJJJRR                            
                                                                                       °°°°         °°°°°°°°  °°°°°°°°°°°°°JJJJJJJJJJJR                            
                                                                                       °°°°° ° °°°°°°°°°°°°° ° °°°°°°°°°°°°JJJJJJJJJJRJ                            
                                                 °°°°°°°°°°                            J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJ°                            
                                            °°°°°°°°°°°°°°JJ°                          J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRJJJJJ                             
                                        °°°°°°°°°°°°°°°°°°°JJJ                         J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRRRRR°                             
                                      °°°°°°°°°°°°°°°°°°°°°°JJJJ°                      °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRR¢J                             
                                     °°°°°°°°°°°°°°°°°°°°°°°°JJJJJJ°                    J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRR¢R                             
                                    °°°°°° °       °°°°°°°°°°°°JJJJJJ                   J°°°°°°°°°°°°°°°JJJJJ°°°°°°°°°°°°°°JJJJJJRRR¢R                             
                                    °°°              °°°°°°°°°°°JJJJJJ°                 °J°°°°°°°°°°°JJJJRRRRRJ°°°°°°°°°°°°JJJJJJRRRR¢°                            
                                   °°°                 °°°°°°°°°°JJJJJJJ                 JJ°°°°°°°°°JJRRRRRRRRRJJ°°°°°°°°°°JJJJJJRRRRRJJ°°°°°J°                    
                                  °°°                 °°  °°°°°°°°°JJJJJJ°               °JJ°°°°°°°JJRRRRRRRRRRRRJJJJJJJJ°°JJJJJJRRRRRJ°°°°°°°°°°                  
                                 °°°°                    °° °°°°°°°°JJJJJJ°               JJJ°°JJJ°JRRRRRRRRRRRRRRRRRRRRRJ°°JJJJJRRRRRJ°°°°°°°°°°°                 
                                °°°                       °°°°°°°°°°JJJJJJJ°               °JJJJJJJRRRRRRJRRRRRRRRRRRRRRRRJ°JJJJJRRRRRRJ °°°°°°°°°                 
                                °°°                  °      °°°°°°°°°°JJJJJJJ                JJJJRRRRRRRRRRRRRRRRRRRRRRRRRJ°°JJJJRRRRRRJ° °°°°°°°°                 
                               °°°                        °°°°°°°°°°°°°JJJJJJJ               RJJRRRRRRRRRRJRRRRRRRRRRRRRRRRJ°JJJJR¢RRRRJ° °°°°°°°°                 
                              °°°                        °°°°°°°°°°°°°°JJJJJJJJ              JRJRRRRRRRRRJRJRJRRJRRJJRRRRRRJ°JJJRRRRRRRJJ    °°°°°                 
                              °°°                       °°°°°°°°°°°°°°°JJJJJJJJJ             °RJRRRRRRRRRJRJRRJRJJJRJRRRRRRRJJJJRRRRRRRR      °°°°                 
                             °°°°                      °°°°°°°°°°°°°°°JJJJJJJJJJ°             RJJRRRRRRRRJJRJJRJJRJJJJRRRRRRRRRRRRRRRRRR°    °°°°°                 
                             °°°°                   °°°°°°°°°°°°°°°°°°JJJJJJJJJJJ             RJJJRRRRRRRJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRJ    °J°°°                 
                            °°°°°°        °   °    °°°°°°°°°°°°°°°°°°JJJJJJJJJJJR°            RRJJRRRRRRJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRR    °J°°°                 
                            °°°° ° °°           ° °°°°°°°°°°°°°°°°°°°JJJJJJJJJJJRJ            °RJJRRRRRRJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRR    °J°°°                 
                            °°°°°°°°°       ° °° °°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJRR             RJJRRRRRJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRR°   °J°°°                 
                            °°°°°°°°°°°°    ° °°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJRR             RJJJJJRJJJJJJJJJJJJJJJJJJRRRRRRRRJRRRRRRRR°   °J°°°                 
                             °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJR             JJJJJRJJJJJJJJJJJJJJJJJJJRJRJJRJJJJRRRRRRRJ   J°°°°                 
                             °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJ             °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJ  °J°°°°                 
                             °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJR              RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRR  JJ°°°                  
                              J°°°°°°JJJJJJ°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJ              RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR°JJ°°°°                  
                              °JJ°JJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°JJ°JJJJJJJJJJJJJJJ              RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJJ°°°°                  
                         °°°J°JJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJ              °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJ°°°°                   
                     °°°°°°°°°JRJJJJJ°JJJJJJJJJ°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJ               RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°°°°                    
                   °         °JJRRRRJJRJRRJRRJJ°°°°°°°°°°°°°J°°°JJJJJJJJJJJJJJJJJJ               JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRR°°°                     
                  °         °°°JJRRRJJJJJJJJRRJJJ°J°°°°°°°°JJ°JJJJJJJJJJJJJJJJJJJ°               °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°                      
                 °°         °°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°                      
                 °°         °°JJJRRJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                 JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJ                      
                 °°         °°JJJRRJJJJJJJJJJJJJJRJRJRJRJJJJJJRRRRRRJJJJRRRJJJJJ                  JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJ                      
                °°°    °    °°JJJRRJJJJJJJJJJJJJRRJJJJJJJRJRRRRRRRRRRRRRRRRJJJ°                   °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRR¢J                      
                °°          °°JJJRRJJJJJJJJJJJJJRJJJJJJJJJJJRRRRRRRRRRRRRRRJJ°                    °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRR¢R                      
                °°°         °JJJJRJJJJJJJJJJJJJJRJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                      JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRR¢R                      
                J°°  °      JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                      °JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRR¢R                      
                J°°  °      JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJ°                      °JJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRR¢°                     
                J°°  °      JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJ°                      °JJRJJJJJJJJRJJJRJJRRRRRRRRRRRRRRRRRRRRRR¢°                     
                J°   °°     JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJJ°                       JJRRRRRRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢J                     
                J°  °°°    °JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°                        °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢R                     
                °°   °°°   °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRJJJJJ°                        °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                     
                °°   °°°   °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJRRRJJJJJJ°                        °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢RRRRR°                    
                °J  °°°°°  °JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJRJJJJJJJ°                         JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢RRRRRJ                    
                 J°  °°°J  JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJRJJJJJJ°°                         °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                    
                 J°  °°°°° JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJRJJJJJJ°                          °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°°                    
                 °°  °°°°J°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJJ°°                          °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJRJJ°°°J                    
                  °   °°°°°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJJ°°                           °JRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJRJ°°°°°°J°                   
                  °°    °°°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJ°°                           °JRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°°°°°°°JRJ                   
                  °°     °JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJJ°°                           °JRRRRRRRRRRRRRRRRRJJJJJJJJJJ°°°°°°°°°°JJJ                   
                   °    °°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                            °JJRRRRRRRJRJJJJJJJJJJJJJJ°°°°°°° °°°°JJJJ                   
                    °   °°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                             °JJJJJJJJJJJJJJJJJJJ°°°°°°°°°°  °°°J°°°°J                   
                     °  °°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                             °JJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°                   
                       °°JRJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                             °JRRJJ°°°°°°°°°°°°°°°°°°°°°°°°       °°°                    
                       °°JRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                              °RRRJJ°°°°°°°°°°°°°°°°°°°°°°        °°                     
                        °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                               °RRRJ°°°°°°°°JJJJ°°°°°°°°                                  
                        °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                               °RRJJJJJJJJJJJJ°°°°°°°°°                                   
                        JRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                               °RRRRRRJJJJJJJ°°°° °°                                      
                        JRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                JRRRRJ°°°°J°°°°°       °°°                                
                        JRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                JRRRRJ°°°°°°°°       °°°°                                 
                        RRRR¢RRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                  JRRRJ°°°°°°°°      °°                                    
                       °RRRR¢RRRRRRRRJJJJJJRRJJJJJJJJJJJJJJRJJJJJJJJJJ°°                                   °JJJ°°°°°°°°°                                           
                       °RRRR¢RRRRRRRRRRRJJRRRRRRRRRJJJJJJRRRRJJJJJRJJJ°°                                                                                           
                       JRRRR¢RRRRRRRRRRRRJRRRRRRRRRRRRRRRRRRRRJRRRRJJJ°°                                                                                           
                       JRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                            
                       RRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                            
                      °RRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                            
                      JRRRR¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                            
                      JRRRR¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                            
                      JRRR¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                            
                      JJRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     °JJJR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     °RJJJRRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     JRJJJJJRJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     RRRJJJJ°JJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                     ¢RRJJJ°°°°°JJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    °RRRRJJJ°°°°°°JJJJJJJJJJJRRRRRRRRRRRRRRRRRJJJJJ°°                                                                                              
                    °RRJJJRJJJ°°°°°°°JJJJJJJJJJJJJJJRRRRRRJJJJJJJJ°°°                                                                                              
                     RJJJJRJJJJJ°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                                                                              
                     JJJ°JJJ°°°°°°°°°°°°°°°°°°°°°JJJRJRRJJJJJJJJJJJ°                                                                                               
                     °JJ°JJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°°°°                                                                                               
                      JJ°JJ°°°°°°°°°°°°°° °°°°°°°J°°°°°°°°°°°°°°°J°°                                                                                               
                      °J°J°°°°    °°°°          °°°°JJ°°°°JJJ°JJJJ°°                                                                                               
                       °JJ°°      °°°°             °°°°° °°°JJRRRJ°°                                                                                               
                         °°°     °°°  °°°           °°     °°JRJJJ°                                                                                                
                          °°  °°°°°   °°           °°    °°°°JJJJJ°                                                                                                
                              °°°°°°  °            °°° °°°°°°JJJJ°                                                                                                 
                               °°°°   °°°°°°°°   °°°° ° °°°°°JJJJ°                                                                                                 
                                   °°° °°°°°°°°°°°°°°°°°°°°°°JRJ°                                                                                                  
                                        °°°°°°°°°°°°°°°°°°°°JJJ°                                                                                                   
                                             °°°°°    °°°°°                                                                                                        
`,`
                                                                                                               °°°°°°°°°°°                                         
                                                                                                     °°°°°°°°°JJJJJJJJJJJJJJ                                       
                                                                                                 °°°°JJ°°°°°°°°°°°°°°JJJJJJJJJ°                                    
                                                                                               °°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJ°                                  
                                                                                             °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJRRJ                                 
                                                                                            °°°°°°°           °°°°° °°°°°°°JJJJJRRJ                                
                                                                                           °°°°°°                   °°°°°°°°JJJJJRRJ                               
                                                                                          °°°°°                     °°°°°°°JJJJJJRRR                               
                                                                                         °°°°                    °°°°°°°°°JJJJJJJJRRJ                              
                                                                                         °°°                    °°°°°°°°JJJJJJJJJJRRR                              
                                                                                        °°°                     °°°°°°°°JJJJJJJJJJRRR                              
                                                                                       °°°                     °°°°°°°°°JJJJJJJJJJJRR°                             
                                                                                       °°               °      °°°°°°°°°JJJJJJJJJJJRR°                             
                                                                                      °°°                °  °°°°°°°°°°°°JJJJJJJJJJJRR°                             
                                                                                      °°°         °°°°°°    °°°°°°°°°°°°JJJJJJJJJJJJR°                             
                                                                                     °°°°°°° °° °°°°°°°°°   °°   °°°°°°°JJJJJJJJJJJJR                              
                                                    °°°°°°°°°°                       °°°°°°°°°°°°°°°°°°°  ° °°° °°°°°°°°°JJJJJJJJJJJR                              
                                              °°°°°°°°°°°°°°°JJ°                     °°°°°°°°°°°°°°°°°°°°°°°°° °°° °°°°°JJJJJJJJJJJJ°                              
                                          °°°°°°°°°°°°°°°°°°°°JJJ                    °°°°°°°°°°°°°°°°°°°°°°° °° °° °°°°°JJJJJJRRJJJJ                               
                                         °°°°°°°°°°°°°°°°°°°°°°JJJJ°                  J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRRRRRR                               
                                       °°°°°°°°°°°°°°°°°°°°°°°°°JJJJJ°                °°°°°°°°°°°°°°°°°°°°°° °°°°°°°°°°°°JJJJJRRRRRR                               
                                       °°°°°°°°     °°°°°°°°°°°°°°JJJJJ°              °J°°°°°°°°°°°°°°JJJJ°°°°°°°°°°°°°°°JJJJJJRRRR¢°                              
                                      °°°°              °°°°°°°°°°°JJJJJJ              J°°°°°°°°°°°JJJJJRRJ°°°°°°°°°°°°°°°JJJJJRRRR¢J                              
                                     °°°°                °°°°°°°°°°°JJJJJJ°            °J°°°°°°°°°JJRRRRRRRJJ°°°°°°°°°°°°°JJJJJRRRR¢R°° °°°                        
                                    °°°°                 °°°°°°°°°°°°°JJJJJ°            JJ°°°°°°°JJRRRRRRRRRRJJJJJJJJ°°°°°JJJJJRRRRRRJ°°°°°°°°                     
                                   °°°°                  °°°°°°°°°°°°°°JJJJJJ           °JJJ°°J°°JRRRRRJRRRRRRRRRRRRRJJ°°JJJJJJRRRRRRJ°°°°°°°°°°                   
                                   °°°                       °°°°°°°°°°JJJJJJJ°          °JJJJJJJRRRRRRJRJJJJJJRRRRRRRRJ°°JJJJJRRRRRRJ°°°°°°°°°°°                  
                                  °°°                   °    °°°°°°°°°°°°JJJJJJ°           °JJJJRRRRRRRJJJJJJJJJJRRRRRRJ°°°JJJJRRRRRRJJ  °°°°°°°°                  
                                 °°°°                        °°°°°°°°°°°JJJJJJJJ°           JJJRRRRRRRJJJJJJJJJJJJRRRRRRJ°JJJJJRRRRRRJJ° °°°°°°°°                  
                                °°°°                        °°°°°°°°°°°°°JJJJJJJJ°          RJJRRRRRRRRJJJJJJJJJJJRRRRRRJ°°JJJRRRRRRRRJ°°° °°°°°°                  
                                °°°°                     °°°°°°°°°°°°°°°°JJJJJJJJJ°         JJJJRRRRRRJJJJJJJJJJJJJRRRRRRJJJJJRRRRRRRRJ     °°°°°                  
                               °°°°                     ° °°°°°°°°°°°°°°°JJJJJJJJJJ         JJJJJRRRRRJJJJJJJJJJJJJRRRRRRRJJJRRRRRRRRRJ     °°°°°                  
                               °°°°°                   °°°°°°°°°°°°°°°°°°JJJJJJJJJJ°         RJJJRRRRRRJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRR     °J°°°                  
                               °°°°°°            °    °° °°°°°°°°°°°°°°°JJJJJJJJJJRJ         RJJJJJRRRJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRR     °J°°°                  
                              °°°°°°° °°           ° °°°°°°°°°°°°°°°°°°°JJJJJJJJJJRR         JJJJJJRRRRJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRR°    °J°°°                  
                              °°°°°°°°         °° ° °°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJR°        °JJJJJRRJRJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRR°    °J°°°                  
                               °°°°°°°°°°°°    °°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJR°        °JJJJJJJRJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRJ    JJ°°°                  
                               °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJ°         RJJJJJJJRJJJJJJJJJJJJJJRRRRRJJJJJJRRRRRRRJ    J°°°°                  
                               °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJ         RJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJRRRRRRRRR    J°°°                   
                                J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJ         JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR°  °J°°°                   
                                °J°°°°°°JJJJJ°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJ°         °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJ °JJ°°°                   
                                °JJJJ°°JJJJJJJJJ°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJ°          RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°JJ°°°°                   
                        °°°°°°°J°RJJJJJJJ°°JJJJJJ°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJ°          JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJJ°°°°                    
                      °°      °°JRRRJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJ           JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJ°°°°°                    
                    °          °°JJRRRRJJJJJJJRJJJ°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJ           °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°°°°                     
                    °         °°°JJRRRRJJJJJJJJJJJJ°°J°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJ            JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°°°                      
                   °°         °°JJJJRRJJJJJJJJJJJJJRJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°            JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJ                        
                   °          °°JJJJRRJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°             °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJ°                       
                  °°         °°°JJJRRRJJJJJJJJJJJJJRJJJRRJRJJRJJRRRRRRRJJJJRRJJJJJ               JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJJ                       
                  °°     °    °°JJJRRRJJJJJJJJJJJJJRJJJJJJJJRRRRRRRRRRRRRRRRRJJ°°                JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR¢R                        
                  °°          °JJJJRRJJJJJJJJJJJJJJRJJJJJJJJJJRRRRRRRRRRRRRRRJJ°                 °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRR¢R                        
                  °°          °JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJ                  °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRR¢R                        
                  °°   °      JJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJJ°                   JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRR¢°                       
                  °°   °      JJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJJ°                   JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRR¢°                       
                  °°   °      JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJJ°                   JJRRRRRJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRR¢J                       
                  °°  °°      JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJJJJJ°                   °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                       
                  °°  °°°    °JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJRJRJJJJ°                     JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                       
                  °°  °°°°   °JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRJJJJJ°                     JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                      
                  °°  °°°°   °JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJJ°                     °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                      
                  °°   °°°   JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJ°°                     °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢RRRRRRJ                      
                  °°   °°°J  JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJJ°                       JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJRRJ                      
                   °   °°°°° JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJJ°                       JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJ°°                      
                   °° °°°°JJ°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJ°°                       JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJRJJJ°°°                      
                   °°  °°°°°°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJRJJJJJJJJ°°                       °JRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJJ°°°°°°                     
                    °     °°°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                       °JRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°°°°°°°JJ                     
                    °°     °JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                         JR¢RRRRRRRRRRRRRRRRJJJJJJJJJJ°°°°°°°°°JRR                     
                     °    °°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                         °RRRRRRRRRRRJJJJJJJJJJJJJJ°°°°°°°°°°°JJJJ°                    
                          °°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                         °JJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°   °°°JJJJ                     
                       ° °°°RJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                         °JJJJJJJJJJJJJJJJ°°°°°°°°°° °°°°°°°°°°°°J                     
                        °°°JRJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                           JJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°° °°°°                     
                         °°RRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                           JRRRJ°°°°°°°°°°°°°°°°°°°°°°°°       °°°                      
                          °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                           °RRRJJ°°°°°°°°°°°°°°°°°°°  °       °°                        
                          JRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                           °RRJJJJJJJJJJJJJ°°°°°°°°                                     
                          JRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                            RRRRRRJJJJJJJJ°°°°°°°°                                      
                          RRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                             JRRRRRJJJJJ°°°°°                                            
                          RRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                             JRRRRJ°°°°°°°°°°     °°°°                                   
                         °RRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                              JRRRJ°°°°°°°°°     °°°                                     
                         JRRRR¢RRRRRRRRRJJJJJRRRRJJJJJJJJJJJJJJJJJJJJJJJ°°                               JJRJ°°°°°°°°°                                             
                         JRRRR¢RRRRRRRRRRJJJRRRRRRRRRRRRRJJRRRRJJJJJJJJJ°                                    °°° °                                                 
                         RRRRR¢RRRRRRRRRRRRJRRRRRRRRRRRRRRRRRRRRRRRRJJJJ°                                                                                          
                         R¢RRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                          
                        °RRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                          
                        JRRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                          
                        RRRRR¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                           
                        RRRRR¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                           
                       °JRRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                           
                       °JJRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                           
                       JJJJRRRRJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                           
                       JJJJJJRJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                            
                       RRJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°°                                                                                            
                      °RRRJJ°°°JJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                            
                      JRRRJJ°°°°°°°JJJJJJJJRRRRRRRRRRRRRRRRRRRRRJRRJJ°°                                                                                            
                      RRRRJJJ°°°°°°°°JJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJJ°°                                                                                            
                      JRJJJJRJJJ°°°°°°°°JJJRJJJJJJJJJJJRRRRJJJJJJJJJ°°                                                                                             
                      °RJJJJJJJJ°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJ°                                                                                             
                       JJJ°°°°°°°°°°°°°J°°°°°°°°°°°°JJJJRJJJJJJJJJJ°J°                                                                                             
                       °JJ°°°°°°°°°°°°°°°°°°°°°°°°°°    °°°°°°°°JJ°°°°                                                                                             
                        JJ°°°°°°°°°°°°°°°°°  °°°°°°J°°°°°°°°°°°°°°°°°                                                                                              
                        °JJ°°°       °°°          °°°°JJ°°°°JJJJJJJJ°                                                                                              
                          JJ°       °°°°             °°°°°°°°JJRRJRJ°                                                                                              
                           °°°     °°°  °° °         °°°    °°JRJJJJ°                                                                                              
                             °  °°°°°    °     °    °°°°  ° °°JJJJJ°                                                                                               
                                 °°°°°               °°° °°°°°JJJJJ°                                                                                               
                                  °°°  °°°°°°°°°°°°°°°°°° °°°°JJJJJ                                                                                                
                                       °°°°°°°°°°°°°°°°°°°°°°°JJJJ                                                                                                 
                                           °°°°°°°°°°°°°°°°°°°JJ°                                                                                                  
                                                 °°   ° °°°°                                                                                                       
`,`
                                                                                              °°°°°°      °°°J°°°°°                                                
                                                                                           °°°JJJJJ°°°°°°JJJJJJJJJJJJ°                                             
                                                                                        °°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJ                                           
                                                                                       °°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJ                                         
                                                                                      °°°°°°         °°°°°°°°°°°°°°°JJJJJRJJ                                       
                                                                                     °°°°°                    °°°°°°°JJJJJRRJ                                      
                                                                                    °°°°                      °°°°°°°JJJJJJRRJ                                     
                                                                                   °°°°                      °°°°°°°°°JJJJJRRR°                                    
                                                                                   °°°                       °°°°°°°JJJJJJJJRRR                                    
                                                                                  °°                        °°°°°°°°°JJJJJJJRRR°                                   
                                                                                 °°°                       °°°°°°°°°JJJJJJJJJRRJ                                   
                                                                                 °°°                      °°°°°°°°°JJJJJJJJJJRRJ                                   
                                                                                °°°°                      °°°°°°°°°JJJJJJJJJJRRJ                                   
                                                                                °°°°°                    ° °°°°°°°J°JJJJJJJJJRRJ                                   
                                                                                °°°°°°°°°°°° °            °°°°°°°°°JJJJJJJJJJJRJ                                   
                                                                                °°°°°°°°°°°°°°°°           ° °°°°°°JJJJJJJJJJJRJ                                   
                                                        °°°°°°°°°°°°°°          °°°°°°°°°°°°°°°°    °     ° °°°°°°°JJJJJJJJJJJJJ                                   
                                                  °°°°°°°°°°°°°°°°°°°°J°        °°°°°°°°°°°°°°°°            °°°°°°°°JJJJJJJJJJJ°                                   
                                                 °°°°°°°°°°°°°°°°°°°°°°JJ       °J°°°°°°°°°°°°°°°°°°       °°°°°°°°°JJJRJJJJJJJ                                    
                                               °°°°°°°°°°°°°°°°°°°°°°°°°JJJ°     J°°°°°°°°°°°°°°°° °    ° °°°°°°°°°°JJJRRRJJRR°                                    
                                              °°°° °°°°°°°°°°°°°°°°°°°°°°JJJJ    JJ°°°°°°°J°°°°J°°°° °°°°°°°°°°°°°°°JJJRRRRRRR°                                    
                                             °°°°°            °°°°°°°°°°°°°JJJ°  °JJ°°°°°°J°JJJJJJ°°°°°  °°°°°°°°°°JJJJRRRRRRRJ                                    
                                            °°°°°             ° °°°°°°°°°°°°JJJJ  JJJ°°°°°°JJRRRRRJ°°°°°°°°°°°°°°°°°JJJRRRRRRRR                                    
                                           °°°°°              ° °°°°°°°°°°°°°JJJJ°°JJJ°°°°°JRRRRRRRJ°°°°°°°°°°°°°°°JJJJRRRRRRRR                                    
                                           °°°°                   °°°°°°°°°°°°JJJJJJJJJJJ°JJRRRRRRRRJJJJJJJ°°°°°°°°JJJJRRRRRRRRJ°                                  
                                          °°°°                   °°°°°°°°°°°°°°JJJJJJJJJJJJJRRRRRRRRRRRRRRRRJJ°°°°°JJJJRRRRRRRRJJ°°°°°°°°                          
                                         °°°°°                   °°°°°°°°°°°°°°JJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRJ°°°°JJJJRRRRRRRRJJ°°°°°°°°°°                        
                                        °°°°°                    °°°°°°°°°°°°°°°°JJJJJJJJJJJJRRRRRRRRRRRJJJRRRR°°°°JJJJRRRRRRRRJJ°°°°°°°°°°                        
                                       °°°°°                    ° °°°°°°°°°°°°°°JJJJJJJJJJJJJRRRRRRRRRRRRJJRRRRJ°°°°JJJRRRRRRRRJJ° °°°°°°°°°                       
                                       °°°°                      °°°°°°°°°°°°°°°JJJJJJJJJJJJJJRJJRRRRRRRJJJRRRRRJ°°JJJJRRRRRRRRRJJ  °°°°°°°                        
                                      °°°°°                     °°°°°°°°°°°°°°°°JJJJJJJJJJJJJJRJJJRRJRRJJJJRRRRRJ°°JJJRRRRRRRRRRJJ    °°°°°°                       
                                      °°°°                     °°°°°°°°°°°°°°°°°JJJJJJJJRRJJJJRJJJJJJRJJJJJJRRRRRJJJJRRRRRRRRRRRR      °°°°°                       
                                      °°°°                    °°°°°°°°°°°°°°°°°JJJJJJJJJJRJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRJ      °°°°°                       
                                     °°°°°°               °  ° °°°°°°°°°°°°°°°°JJJJJJJJJJRRJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRR      °J°°°                       
                                     °°°°°°°  °          °  °°°°°°°°°°°°°°°°°J°JJJJJJJJJJRRJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRR      °J°°°                       
                                      J°°°°°°°  °°°°     ° °°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJRRRRRRRRJRRRRRRRRRRR      °°°°°                       
                                      JJ°°°° °°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°J°JJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJRRRRRRJJJRJRRRRRRRRR°     °°°°°                       
                                      °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJRRRRRRRR°     J°°°°                       
                                       °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJRRJ     J°°°                        
                                       °J°°°°°°°°J°°°°°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJ    °J°°°                        
                                       °JJJJ°°°°°°JJJJJJJ°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJ    J°°°°                        
                               °°°°°°J°JRJJJJJJ°JJJJJJJJJJJ°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJ   °J°°°°                        
                           °°        °°JRRRJJJ°°°°JJJJJJJ°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJ  JJ°°°°                         
                          °          °°JRRRRRRJJJJJJJJJJJJJ°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJ°°°°°                         
                         °           °°JJJRRRRJJJJJJJJJJJJJJ°°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJ°°°°°                          
                         °          °°°JJJJRRRJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJ°°°°                           
                        °°          °°°JJJJJRJJJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJ°°°                            
                        °           ° °JJJJRJJJJJJJJJJJJJJJJRJRRRRJJJJJJJJJJJJJJJJJJJJJJJ °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJ                              
                        °     °     °°JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRJJ°  °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJ                              
                        °            °JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRJ     JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJ                             
                        °            JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJRJJJRRJ°     JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJRRRRRRRJ                              
                            °        JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJRJJJRRR      JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRR°                              
                        °   °°       JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJRJJJJJRJ      °JJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRR°                              
                        °   °°      °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJJJRRJ      °JJJJJJRJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRR°                              
                        °   °°      °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJRR°       JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                              
                        °   °°      JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJJJJJRJ        JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                              
                        °   °°°     JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJJJRJ        °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                              
                        °  °°°°     JJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJJJJJRJ        °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                              
                        °  °°°°    °JJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJJJJJJJJJ°        °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                             
                        °   °°°°   °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJRRRJJJJJJJJJ°         JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                             
                        °   °°°J°  JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJ          JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJ°                             
                            °°°°J° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJ          JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJJ                             
                         °   °°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°          °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°°                             
                         °°  °°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ            RRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°°°°J                             
                                °°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ            RRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJJ°°°°°°°°                            
                          °     ° °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ            JRRRRRRRRRRRRRJJJJJJJJJJJJJJJ°°°°°°°°°°°J                            
                                ° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°            JRRRRRRJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°JJJ                            
                            °  °° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°            JJRJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°JJRR                            
                             ° °°°RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ             JJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°  °°JJJJJJ                            
                              °J°JRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ             °J°°°JJ°°°°°°°°°°°°°°°°°°°° °°°°°°°°°°JJJ                            
                               J°RRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°              J°°°°JJ°°°°°°°°°°°°°°°°°°°°°°°    °°°JJ°                            
                                JRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°              J°°°°JJ°°°°°°°°°°°°°°J°°°°°°      °°°°°                             
                                JRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°               JJJJJJJ°°°°°JJJJ°°°°°°°°          °°                                
                                JRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°               °RRRRRRJJJJJJ°°°°°°°°°                                              
                                RRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°               °RRRRRJJJ°°°°°°°°°                                                  
                               °RRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                RRRRRJJ°°°°°°°°    °°                                              
                               °RRRRRRRRRRRJJJJJJJJJJJRRRRRJRJRJJJJJJJJJJJJJJJJ                  JRRRJJ°°°°°°°° °°°                                                
                               J¢RRRRRRRRRRRRJJJJJJJJRRRRRRRRRRRRRRJJJJJJJJJJJ°                    °°°°°°°°°°°                                                     
                               J¢RRRRRRRRRRRRRRRRJJJJRRRRRRRRRRRRRRRRJJJJJJJJJ°                                                                                    
                               R¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJ°                                                                                    
                              °R¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ                                                                                     
                              JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                     
                              JRRRRRRRRRRRRRRRRRRRJRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                     
                              JRJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                     
                             °JRJJJJRRRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                     
                             JJJJJJJJRRJJRRJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                                                                      
                             JJJJJJJJJJJJRRRRRJRJRRRRRRRRRRRRRRRRRRRRRRRRJRJ°                                                                                      
                             JJJJJJJJJJJJJJJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                      
                             JJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                      
                            JRRJJJJJ°°°JJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRJ                                                                                       
                            RRRRJJJ°°°°°°°JJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRJJ°                                                                                       
                            RRRRRRJ°°°°°°°°°°JJJJJJJJJJRRRRRRRRRRRRJJJJJJJJ°                                                                                       
                            RRJJJJJJJ°°°°°°°° °°JJJJJJJJJJJJJJRRRRJJJJJJJJJ°                                                                                       
                            RRJJJJ°JJJ°°°°°°°°  °°°°JJJJJJJJJJJJJJJJJJJJJJJ°                                                                                       
                            JJJJJJ°°°°°°°°°°°°°°°°° °° °°°°JJJJJJJJJJJJJJ°°                                                                                        
                             JJJJ°°°°°° °°°°°°°°°°°°°°°°°  °°°°°°°°°°°°°                                                                                           
                              JJJ°        °°°°°°°°°°°°°°°°°° °°°°°°°°°°°                                                                                           
                               JJ°          °°  °    °°°°°°°°°° °°°°°°°°°°                                                                                         
                                °J°°          ° °        °°°°°°°°JJJJJJJJJ                                                                                         
                                  °°       °     ° °          °°°°°°JJJJJJ                                                                                         
                                    °°    °°                   °°°°°JJJ°°°                                                                                         
                                      °°°°°°              °°°° °°° °°JJ°°°                                                                                         
                                          °°      °°°°°°°°°°°° °°°°°JJJ°°                                                                                          
                                            °°°°  °°°°°°°°°°°° °°° °JJJJ°                                                                                          
                                                   °°°°°°°°°°°°°°°°°JJ°                                                                                            
                                                        °°°°°°°°°°°°°                                                                                              
`,`
                                                                                        °°°°JJJJ°°°°°°°°°JJJJJJ°°                                                  
                                                                                      °°°°°°°°°°°°°°°°JJJJJJJJJJJJ°                                                
                                                                                    °°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJ°                                              
                                                                                   °°°°°°°    °°°°°°°°°°°°°°°°°°JJJJJJ°                                            
                                                                                  °°°°°               °°°°°°°°°°JJJJJJRJ°                                          
                                                                                 °°°°                     °°°°°°°°JJJJRRJ°                                         
                                                                                °°°                        °°°°°°°JJJJJRJR°                                        
                                                                               °°°                        °°°°°°°°JJJJJRRRJ                                        
                                                                               °°                        °°°°°°°°JJJJJJJRRRJ                                       
                                                                              °°°                        °°°°°°°°°JJJJJJJRRR                                       
                                                                             °°°°                        °°°°°°°°°JJJJJJJRRR                                       
                                                                             °°°°                        °°°°°°°°JJJJJJJJRRR                                       
                                                                             °°°°°°°                     ° °°°°°JJJJJJJJJRRR                                       
                                                                             °°°°°°°°°°°                °°°°°°°°JJJJJJJJJJRR                                       
                                                                             °°°°°°°°°°°°°              °°°°°°°JJJJJJJJJJJRR                                       
                                                              °°°°°°°°°      °°°°°°°°°°°°°              °°°°°°JJJJJJJJJJJJJR                                       
                                                       °°°°°°°°°°°°°°°°°J°   J°°°°°°°°°°°°      °      °°°°°°°JJJJJJJJJJJJJJ                                       
                                                    °°°°°°°°°°°°°°°°°°°°°JJ  J°°°°°°°°°°°°°  °          °°°°°°JJJJJJJJJJJJJJ                                       
                                                  °°°°°°°°°°°°°°°°°°°°°°°°JJ °°°°°°°°°°°°°°°°°°° °    °°°°°°°°JJJJRJJJJJJJJJ                                       
                                                 °°°°°°°°°°°°°°°°°°°°°°°°°°JJJJ°°°°°°°J°°°°°° ° °°°° °°°°°°°°°°JJJRRRRJJJJJ                                        
                                                °°°°  ° °  ° °°°°°°°°°°°°°°°°JJJ°°°°°JJJJJJ°°°°°°°°°°°°°°°°°°°°JJJRRRRRRRRJ                                        
                                               °°°°°             °°°°°°°°°°°°°°JJJ°°°J°JJRRJ°°°°°°°°°°°°°°°°°°JJJJRRRRRRRRJ                                        
                                              °°°°°              °°°°°°°°°°°°°°°JJJJJ°JJRRRRJ°°°°°°°°°°°°°°°°°JJJJRRRRRRRRR                                        
                                             °°°°                  °°°°°°°°°°°°°°JJJJJJJRRRRRJJ°°°°°°°°°°°°°°°JJJJRRRRRRRRR°                                       
                                            °°°°°                  ° °°°°°°°°°°°°°JJJJJJRRRRRRRJJJJJJ°°°°°°°°°JJJJRRRRRRRRJJ                                       
                                           °°°°°°                 °° °°°°°°°°°°°°°JJJJJJRRRRRRRRRRRRRRJJ°°°°°°JJJJRRRRRRRRJJJJ°°°°°°°                              
                                           °°°°                    °°°°°°°°°°°°°°°JJJJJJJRRRRRRRRRRRRRRRJ°°°°°JJJJRRRRRRRRRJJ°°°°°°°°°                             
                                          °°°°                     °°°°°°°°°°°°°°JJJJJJJJRRRRRRRRRRRRRRRRJ°°°°JJJJRRRRRRRRRJJ° °°°°°°°°                            
                                         °°°°°                      °°°°°°°°°°°°°°JJJJJJJJRRRRRRRRRRRRRRRR°°°°JJJJRRRRRRRRRJJ° °°°°°°°°°                           
                                         °°°°°                      °°°°°°°°°°°°°JJJJJJJJJRRRRRRRRRRRJRRRRJ°°°°JJRRRRRRRRRRJJJ  °°°°°°°°                           
                                        °°°°°                       °°°°°°°°°°°°°JJJJJJJJJJRJRJRRRRRRJRRRRRJ°°JJJRRRRRRRRRRRJJ   °°°°°°°                           
                                        °°°°°                  ° ° °°°°°°°°°°°°°JJJJJJJJJJJRRJJJJRRJJRJRRRRRJJJJRRRRRRRRRRRRR°     °°°°°                           
                                        °°°°°                 °°° °°°°°°°°°°°°°°JJJJJJJJJJJJRJJJJRJJJJJRRRRRRRRRRRRRRRRRRRRRR       °°°°                           
                                        °°°°°                °  °°°°°°°°°°°°°°°JJJJJJJJJJJJJRJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRR       J°°°                           
                                        J°°°°°    °  °       °°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJRRJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRR       J°°°                           
                                        JJ°°°°°    °°°°°°  °°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJRJJJJJJJJJJRRRRRRJJRJJRRRRRRRRRJ       J°°°                           
                                        °JJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJJJJJRRRRRRJRJ      °J°°°                           
                                         JJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJRJJJJJJJJJJRRRJJJJJJJJJJRRRRJJRJ      °°°°°                           
                                         °JJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJRJ°     J°°°°                           
                                          JJJJJ°°°°°°JJJJJJJ°J°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°     J°°°                            
                                 °°°°°°°°°JRJJJJJJ°°JJJJJJJJJJJ°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJ    °J°°°                            
                              °°°°°°°°°J°°JRRJJJJJJJ°°°JJJJJJJJ°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJ    J°°°°                            
                            °°         °°°RRRRRRRJJJJJJJJJJJJJJ°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ   JJ°°°                             
                           °           °°°JRRRRRRRJJJJJJJJJJJJJJ°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°JJ°°°°                             
                           °           J°JJJJJRRRRJJJJJJJJJJRRRRRJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°                              
                          °           °J°JJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°                               
                          °           °°°JJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                
                          °           J°°JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                  
                          °    °       °°JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJ                                  
                                       °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJ°                                 
                         °    °        °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJRRJRRRJJ°                                 
                         °    °        °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRRJJJJJJJRJJJJJJJJJJJJRRRRJJRRRRRRRRRRRRRRJ                                   
                         °   °°        JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRRJRJJJJJRRRRJJRRJJJJJRRRRRRRRRRRRRRRRRRRRR                                   
                         °    °°       JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJJRRJJRRJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                   
                         °   °°°       JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJRRJ°RRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                   
                         °   °°°      °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJRR°°RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                   
                             °°°      JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJRJ  RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                   
                              °°°     JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJRJ  JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                  
                          °   °°J     JJJJJJJJJJJJJJJJJJJJJJJJJJJRJRRRRRRRRRRJJJJJJRRJ  JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                  
                             °°°°°   °JJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJRRRRJJJJJJRR°  °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                  
                          °   °°°J°  °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJRJ°  °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJ                                  
                          °   °°°°J° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJRJ   °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ                                  
                           °  °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJ    RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJ                                  
                           °   °°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°    JRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJ°°°J                                  
                            °   °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ     JRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJJJ°°°°°°J°                                 
                            °     ° °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ     °RRRRRRRRJJJJRJJJJJJJJJJJJJJJ°°°°°°°°°°J°                                 
                             °   °° °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ     °RRRJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°JJ                                 
                              °  °J JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°     °JJJRRJJJJJJJJJJJJJ°°°°°°°°°°°°°°  °°°JRJ                                 
                               °°J°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°      °°JJJJ°°°°°°°°°°°°°°°°°°° °°°°°°°°°JJJJJ                                 
                                °J°°RRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ       °°°JJJ°°°°°°°°°°°°°°°°°°°°    °°°JJJJJJJ                                 
                                 °°JRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ       °°°JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJ                                 
                                  °RRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°       J°JJJJ°°°°°°°°°°°°°°°°°°°°°°°      °°JJ                                  
                                  JRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ        °JJJJJJ°°°°JJJJJ°°°°°°°°           °°                                    
                                  JRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ        °RRRRRJJJJ°°°°°°°°°°°°                                                   
                                  JRRRRRRRRJJJJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJ°         RRRRRJJ°°°°°°°°°° °°                                                    
                                  RRRRRRRRRRRJJJJJJJJJJJJJJRRRRRRJJJJJJJJJJJJJJJJ°         °RRRRJ°°°°°°°°°  °°°                                                    
                                 °RRRRRRRRRRJRRRJJJJJJJJJJRRRRRRRRRRJRJRJJJJJJJJJ°           °JJJ°°°°°°°°°°°°°                                                     
                                 °RRRRRRRRRRRRRRRJRJRJJJJRRRRRRRRRRRRRRRRJJJJJJJJ                °                                                                 
                                 J¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°                                                                                  
                                 JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°                                                                                  
                                 R¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJ°                                                                                  
                                JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJRJ                                                                                   
                                JRJJJRRRRRRRRRRRRRRRRRJRRRRRRRRRRRRRRRRRJRRJRRR°                                                                                   
                                JJJJJJRRRRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJRJ°                                                                                   
                               °RJJJJJJJRJJJJRJRJRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°                                                                                   
                               JJJJJJJJJJJJJJRJRJJJJJRRRRRRRRRRRRRRRRRRRJJJJJRJ                                                                                    
                               JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRJJJRJJJ                                                                                    
                               RJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRJRJ°                                                                                    
                               RJJJJJJJ°JJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                    
                             JRRRJJJ°°°°°°°JJJJJJJJJJRRRRRRRRRRRRRRRRRJJJRRRJ                                                                                     
                              RRRRRJJJ°°°°°°°°°°JJJJJJJJJJJRRRRRRRRRRRJJJJJJJJ                                                                                     
                              RRRRRRRJJ°°°°°°°°°°°°JJJJJJJJJJJJJJJJJRJJJJJJJJ°                                                                                     
                              RRJRJJJJJ°°°°°°°°°°°° °°JJJJJJJJJJJJJJJJJJJJJJJ°                                                                                     
                              JRJJJJJ°°°°°°°°°°°°° ° °°°°°°°°°JJJJJJJJJJJJJJ°°                                                                                     
                               RJJJJ°°° °°°°°°°°°°°°°°°°  °°°°°°°°°°°°°°°°°°                                                                                       
                               °JJJ°°°      °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°                                                                                       
                                 JJ°°°       °°      °°°°°°°°°°°°°°°°°°°°°°°                                                                                       
                                  °J°°                    °°°°°°°°°°°°°°°JJJ°                                                                                      
                                    °°°                        °°°°°°JJJJJRR°                                                                                      
                                      °°°                         °°°°°JJJJJ                                                                                       
                                         °   °°                   °°°°°°°°°°                                                                                       
                                            °°°°     °°°°   °      ° °°°°°°                                                                                        
                                               °°°    °°°°°°°°°°   ° °°°°°°                                                                                        
                                                       °°°°°°°°°°°°°°°°°°°                                                                                         
                                                           °°°°°°°°°°°°                                                                                            
`,`
                                                                                         °°°°           °°                                                         
                                                                                    °°°°JJJJJJ°°°°°°°JJJJJJJJJ°                                                    
                                                                                   °°°°°°°°°°°°°°°°°°JJJJJJJJJJJJ                                                  
                                                                                 °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJ                                                
                                                                                °°°°°°      °°°°°°°°°°°°°°°°°JJJJJJJ°                                              
                                                                               °°°°                   °°°°°°°°°JJJJJJJ                                             
                                                                              °°°°                     °°°°°°°°JJJJJJJJ                                            
                                                                             °°°°                       °°°°°°°JJJJJJJJJ                                           
                                                                             °°°                        °°°°°°°JJJJJJJRJJ                                          
                                                                            °°°                       °°°°°°°°°JJJJJJJJJR                                          
                                                                           °°°                        °°°°°°°°°JJJJJJJJRRJ                                         
                                                                           °°°°                       °°°°°°°°°JJJJJJJJRRJ                                         
                                                                           °°°°°                     °°°°°°°°°°°JJJJJJJRRJ                                         
                                                                          °°°°°°°°°°                 ° °°°°°°JJ°JJJJJJJRRJ                                         
                                                                          °°°°°°°°°°°                  °°°°°JJJJJJJJJJJRRJ                                         
                                                                 °°°°°°   °°°°°°°°°°°                 °°°°°JJJJJJJJJJJJJRJ                                         
                                                           °°°°°°°°°°°°°°°J°°°°°°°°°°°              °°°°°°°JJJJJJJJJJJJJRJ                                         
                                                      °°°°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°°°°°°°°      °° °°°°°JJJJJJJJJJJJJJ°                                         
                                                    °°°°°°°°°°°°°°°°°°°°°°°JJJ°°°°°°°°°°°°°°°      °°°°°°°°JJJJJJJJJJJJJJ°                                         
                                                  °°°°  °°°°°°°°°°°°°°°°°°°°°JJ°°JJJJ°°°°°°°°° °  °°°°°°°°JJJJRRJJJJJJJJJ                                          
                                                 °°°°     °°°°°°°°°°°°°°°°°°°JJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°JJJRRRRJJJJJJ°                                          
                                                °°°°°            °°°°°°°°°°°°°°°JJJJJJJ°°°°°°°°°°°°°°°°°°°JJJJRRRRRRRRRR                                           
                                               °°°°°              °°°°°°°°°°°°°°°JJJJRRJ°°°°°°°°°°°°°°°°°°JJJJRRRRRRRRRR                                           
                                               °°° °               °°°°°°°°°°°°°°°JJJRRRJJ°°°°°°°°°°°°°°°°°JJJRRRRRRRRRR°                                          
                                              °°°°                 ° °°°°°°°°°°°°°°JJJRRRRJJ°°°°°°°°°°°°°°JJJJRRRRRRRRRRJ                                          
                                             °°°°                   °°°°°°°°°°°°°°°JJJJRRRRRJJJJJJ°°°°°°°°JJJJRRRRRRRRRRJ°                                         
                                            °°°°                     °°°°°°°°°°°°°°°JJJJJRRRRRRRRRJJ°°°°°°°JJJRRRRRRRRRRJ°J°°°°°°                                  
                                           °°°°°                     °°°°°°°°°°°°°°JJJJJJJRRRRRRRRRRJ°°°°°°JJJRRRRRRRRRRJ°J°°°°°°°°                                
                                           °°°°°                     °°°°°°°°°°°°°°JJJJJJJRRRRRRRRRRRJ°°°°JJJJRRRRRRRRRRJJJ °°°°°°°°°                              
                                          °°°°°                     °°°°°°°°°°°°°°JJJJJJJJJRRRRRRRRRRRJ°°°°JJJRRRRRRRRRRJJJ  °°°°°°°°                              
                                          °°°°                     ° °°°°°°°°°°°°JJJJJJJJJJJRRRRRRRRRRJ°°°°JJRRRRRRRRRRRJJJ   °°°°°°°                              
                                         °°°°°                     °°°°°°°°°°°°°°JJJJJJJJJJJRRRRRRRRRRRJ°°JJJRRRRRRRRRRRJJJ°  °°°°°°°                              
                                         °°°°°                   °°° °°°°°°°°°°°JJJJJJJJJJJJJRRRRRRRRRRRJJJJRRRRRRRRRRRRRRJ     °°°°°°                             
                                         °°°°°°                  ° °°°°°°°°°°°JJ°JJJJJJJJJJJJRRJJJRRRRRRRRRRRRRRRRRRRRRRRR°      °°°°                              
                                         °°°°°°°°    °          °° °°°°°°°°°°J°°JJJJJJJJJJJJJRRJJJJRRRRRRRRRRRRRRRRRRRRRRR       °°°°                              
                                         °J°°°°°      °°°°°°   °°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRR       °°°°                              
                                         °JJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJRJRRRRRRRRJJRRRRRRJRRJR       °°°°                              
                                          JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°J°°JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJJJJJRRRJJJJJJ°      J°°°                              
                                          °JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJRJJJJJJRRRRRJJJJJJJJRRJRJJJJ°      J°°°                              
                                           JJJJJ°°°°°°°°JJJJJJ°°J°°°°°°°°°°JJJJJJJJJJJJJJJJJJJRJJJJJJRRJJJJJJJJJJJRJJJJJJJ°     °J°°°                              
                                           JJJJJJJJ°°°°JJJJJJJJJJ°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ     °°°°°                              
                               °°°°°°°°°JJ°JRRRJJJJJJJJJ°°°JJJJJJJ°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ     J°°°°                              
                              °°        °°°JRRRRRJJJJJJJJJJJJJJJJ°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ    °J°°°                               
                             °          °°°JJJRRRRRRJJJJJJJJJJJJJJJ°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ   °J°°°°                               
                            °           °°°JJJJRRRRRJJJJJJJJJRRRRRJJ°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°JJ°°°°                                
                                        J°°JJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°J°°°°°                                 
                           °           °J JJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°                                 
                           °           °J JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°                                  
                           °           °°°JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                                     
                          °    °°        °JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                                     
                          °    °         JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJJJRRRJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJR°°                                   
                          °    °         JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRRJJRRJJJJJJJJJJJJJJJJJJJJJJRRRRRJJRRJJRJ                                    
                          °   °°°        JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRRJJRRRRRRRRRJJJJRRRRRRRRRRRRRRRRRRRRRJ                                      
                          °   °°°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRRJJRRRRRRRRRRRRJRRRRRRRRRRRRRRRRRRRRRR                                      
                          °   °°°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJRRJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                      
                          °   °°°       JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                      
                          °   °°°       JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                      
                          °   °°°      °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                      
                          °°   °°°     °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJRRJRRRRRJJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                      
                           °   °°J     JJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJRJJRJRJRRJJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                     
                           °   °°°J    JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ                                     
                               °°°°J  °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJ                                     
                               °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ                                     
                            °   °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJ                                     
                                °°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJ°°JJJ                                     
                                  °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°JRRRRRRRRRRRRRRRRRRRJJJJJJJJJJJJ°°°°°JJJ                                     
                              °   °°° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°JRRRRRRRJJJJJJJJJJJJJJJJRJJJ°°°°°°°°°JJJ                                     
                                  °J° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ °RRRRRJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°JJJ°                                    
                                ° °J °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ °JJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°    °°JRJ                                    
                                 °JJ JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°  °JJJJ°°°°°°°°°°°°°°°°°°°° °     °°°JJRJJ                                    
                                  J°°RRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ   °JJJJ°°°°°°°°°°°°°°°°°°°°  °°°°°°°JJJJJJ                                    
                                   °JRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ   JJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJR°                                    
                                   °JRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ   JJJJJ°°°°°°°°°°°°°°°°°°°°°°°       °JJJ                                     
                                   °JRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°   JRRRJJJJJJJJ°JJJ°°°°°°°°           °°                                       
                                   °RRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°   JRRRRJJJJ°°°°°°°°°°°°                                                       
                                   °RRRRRRRRRRRJJJJJJJJJJJJJJRRRJRJJRJJJJJJJJJJJJJJ     RRRRJ°°°°°°°°°°°°°°                                                        
                                   JRRRRRRRRRRRRRRRRJJJJJJJJJRRRRRRRRRRRJJRJJJJJJJ°      JRJJ°°°°°°°°°°°°°°°°                                                      
                                   JRRRRRRRRRRRRRRRRRRRJJJJRRRRRRRRRRRRRRRRJJJJJJJ°        °°°°°°°°°°°°°°                                                          
                                   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ                                                                                 
                                  °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ                                                                                 
                                  JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°                                                                                 
                                  JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJRJ°                                                                                 
                                 °RJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJRJ°                                                                                 
                                 JRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRRJ                                                                                  
                                 JJJJJJJJJRRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ                                                                                  
                                 JJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°                                                                                  
                                 RJJJJJJJJJJJJJJJJJJJJRJRRRRRRRRRRRRRRRRRJJJJJJJ°                                                                                  
                                °RJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRJJJJJRJ                                                                                   
                                JRJJJJJJ°JJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRJJJJRRJ                                                                                   
                                RRJJJJ°°°°°°°JJJJJJJJJJJJRRRRRRRRRRRRRRRRJRJRRJ°                                                                                   
                                ¢RRRJJ°°°°°°°°°°°JJJJJJJJJJRRRRRRRRRRRRRJJJJJJJ°                                                                                   
                               °¢RRRRRJJ°°°°°°°°°° °°JJJJJJJJJJJJJJJJJRRJJJJJJJ                                                                                    
                               JRRRRRRJJJ°°°°°°°°°°°°°°°JJJJRRRJJJJJJJJJJJJJRRJ                                                                                    
                               °RRRRJJ°°J°°°°°°°°°°°°°°°°° °°°°JJJJJJJJJJJJJJJ°                                                                                    
                                RRRJJJ°°°°°°°°°°°°°°°°°°°° °°°°°°°°°°°°°°°°°°°                                                                                     
                                °RJJJ°°°°   °°°°°°°°°°°°°°° °°°°°°°°°°°°°°°°°                                                                                      
                                 °JJ°°°°      °°°     °°°°°°°°°°°°°°°°°°°°°°°°                                                                                     
                                   °°°°°                 °°°°°°°°°    °°°°°°JJ                                                                                     
                                     °°°°                      °°°°°°°°°JJJRRJ                                                                                     
                                       °°°°                        °°°°°JJJJJ°                                                                                     
                                          °°   °°                   °°°°°°°°J                                                                                      
                                                °                    °°°°°°°°                                                                                      
                                                 °°°°    °°°°°°°     ° °°°°°                                                                                       
                                                       °°°°°°°°°°°°°°°°°°°°                                                                                        
                                                             ° ° ° °°°°°°                                                                                          
`,`
                                                                                    °°JJJJJJJ°J°°°°JJJJJJJJJ°                                                      
                                                                                 °°°°°°°°°°°°°°°°°JJJJJJJJJJJJJ                                                    
                                                                               °°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJ°                                                  
                                                                              °°°°°°°    °°°°°°°°°°°°°°°°°°°JJJJJJ°                                                
                                                                             °°°°°                 °°°°°°°°°°JJJJJJJ                                               
                                                                            °°°°                    °°°°°°°°°JJJJJJJJ                                              
                                                                           °°°°                     °°°°°°°°°°JJJJJJJJ                                             
                                                                           °°°                      °°°°°°°°JJJJJJJJJR°                                            
                                                                          °°°                       °°°°°°°°°JJJJJJJJRJ                                            
                                                                         °°°                       °°°°°°°°°°JJJJJJJJRR                                            
                                                                         °°°                       °°°°°°°°°°JJJJJJJJRR°                                           
                                                                        °°°°°                     ° °°°°°°°°°°JJJJJJJRRJ                                           
                                                                        °°°°°°°°°                  °°°°°°°°°°JJJJJJJJRR°                                           
                                                                        °°°°°°°°°°                 °°°°°°°°°°JJJJJJJJRR°                                           
                                                                °°°°°°°°°°°°°°°°°°                 °°°°°JJJJJJJJJJJJJJR°                                           
                                                         °°°°°°°°°°°°°°°°°J°°°°°°°°°             °°°°°°°°JJJJJJJJJJJJJR                                            
                                                      °°°°°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°°°      °° °°°°°°JJJJJJJJJJJJJJJ                                            
                                                    °°° °°°°°°°°°°°°°°°°°°°°JJJ°°°°°°°°°          °°°°°°JJJJJJJJJJJJJJJ                                            
                                                   °°°     °°°°°°°°°°°°°°°°°°°J°JJ°°°°°°°°°°  °°°°°°°°°°JJJRJJJJJJJJJJJ                                            
                                                 °°°°          °°°°°°°°°°°°°°°JJJJJ°°°°°°°°°°°°°°°°°°°°°JJRRRRJJJJJJJJ                                             
                                                 °°°°°           °°°°°°°°°°°°°°°°JJJ°°°°°°°°°°°°°°°°°°°JJJRRRRRRRRRRRR                                             
                                                °°°°°              °°°°°°°°°°°°°°°JJJ°°°°°°°°°°°°°°°°°°JJJRRRRRRRRRRR¢                                             
                                               °°° °°               °°°°°°°°°°°°°°°JJJ°°°°°°°°°°°°°°°°°°JJRRRRRRRRRRR¢                                             
                                              °°°°                    °°°°°°°°°°°°°JJJJJJ°°°°°°°°°°°°°°°°JRRRRRRRRRRRR°                                            
                                             °°°°                    °°°°°°°°°°°°°°°JJJJJJJJJJ°°°°°°°°J°JJJRRRRRRRRRRJJ                                            
                                             °°°                      °°°°°°°°°°°°°JJJJJJRRRRRJJ°°°°°°°°JJJRRRRRRRRRJJ°JJ°°                                        
                                            °°°°°                   °°°°°°°°°°°°°°°°JJJJJJRRRRRRJ°°°°°°JJJJRRRRRRRRRJJ°R°°°°°°°°                                   
                                           °°°°                        °°°°°°°°°°°°JJJJJJJJRRRRRRJ°°°°°JJJRRRRRRRRRRRJJR°°°°°°°°°°                                 
                                           °°°°                      °°°°°°°°°°J°°°JJJJJJJJJRRRRRRJ°°°°°JJRRRRRRRRRRR°JR°   °°°°°°°                                
                                          °°°°                      °°°°°°°°°°°°°°JJJJJJJJJJRRRRRRJ°°°°JJJRRRRRRRRRRRJJR°  °°°°°°°°                                
                                          °°°°                     °°°°°°°°°°°°J°JJJJJJJJJJJJRRRRRRJJ°JJJRRRRRRRRRRRRJJJJ   °°°°°°                                 
                                         °°°°°°                   °°°°°°°°°°°°J°JJJJJJJJJJJJJRRRRRRRJJJJRRRRRRRRRRRRRJJJ°    °°°°°                                 
                                         °°°°°°°°           °    °°°°°°°°°°°°°JJJ°JJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRR      °°°°°                                
                                         °°°°°°°°     °  °°      °°°°°°°°°°°°JJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRR      °°°°°                                
                                         °J°°°°°°°   °°°°°°°°° °°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRJRRRR       °°°                                 
                                          JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJRRRRRRRRRRJRR       °°°                                 
                                          °JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°J°°JJJJJJJJJJJJJJJJJJRRRRRRRRRRJJJJRRRRRRRJJJR¢      °°°°                                 
                                           JJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJRRRRRRRRRJJJJJJRRRJRJJJJJ¢      °°°°                                 
                                           °JJJJJJ°°°°°°JJJJJJJJJJJ°°°°°°°J°JJJJJJJJJJJJJJJJJJRRRRRRRJJJJJJJJJRJJRJJJJJ¢      °°°°                                 
                                           °JRJJJJJJ°°°°JJJJJJJJJJJ°°°°°°°°°J°JJJJJJJJJJJJJJJJRRJRRRRJJJJJJJJJJJJJJJJJJR°     J°°°                                 
                                 °°°°°°°°JJ°JRRJJJJJJJJJJJ°JJJJJJJJ°°°°°°°°JJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJJJJR°    °°°°°                                 
                               °°        °°°JRRRRRRRJJJJJJJJJJJJJJJ°°°°°°°JJJJJJJJJJJJJJJJJJJJJJRJRJJJJJJJJJJJJJJJJJJJJRJ    J°°°                                  
                              °          °°°JJJRRRRRRRJJJJJJJJJJRJJJJ°°°JJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJ   °°°°°                                  
                             °           J°°JJJJRJRRRJJJJJJJJJJRRRRRRJ°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  JJ°°°°                                  
                            °           °J°JJJJJJJJJJJJJJJJJJJJJJRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°JJ°°°°°                                   
                            °           °J°JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°                                    
                            °           J° JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°                                     
                                        J°°JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                       
                                         °°JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                                        
                           °    °        °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJRRRRJJRRJJRRJJJJJJJJJJJJJJJRJRRJJJJJJR° °                                     
                           °    °        °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRRJRRRRRRRJJJRJRJJJJJJJRRRRRRRRRRJJRJ°                                      
                           °    °        °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJRRRJRRRRRRRRRJRRRRRRRRRRRRRRRRRRRRRJJJ                                        
                           °   °°        °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                           °   °°        °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                           °   °°        JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                           °   °°°       JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                        
                           °   °°°      °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                        
                               °°°      °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                        
                               °°°°     JJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJRRJRJRRRRJJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                        
                            °   °°°°    JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJRRRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                        
                            °   °°°J°  °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ                                        
                            °   °°°°JJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJ                                        
                             °  °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJ                                        
                                 °°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJJJJ                                        
                              °   °°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJR¢¢RRRRRRRRRRRRRJJJJJJJJJJJJJ°°JRRJJ°                                       
                                   °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJJJJJJJJJJJJJJ°°°°°°JRRRJ°                                       
                                °  °J° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJJJRRJJJ°°°°°°°°°°°°°JRRRJJ                                       
                                 ° °J° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°° °° °   °JJRJJ                                       
                                 °°JJ °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°  °      °°JRRJ                                       
                                  °JJ°JRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°      °°°°JJJJJJ                                       
                                    °°JRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JRJJJ°                                       
                                     JRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°    °JRRJ                                        
                                     JRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJ°°°°°°JJ°°°°°°°°°°          °JJ°                                         
                                     JRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJRRRJJJJJ°°°°°°°°°°°°                                                          
                                    °JRRRRRRRRRRJJJJJJJJJJJJJJJJRRRRJJRJJJJJRJJJJJJJ°RRRJJ°°°°°°°°°°°°                                                             
                                    °RRRRRRRRRRRRRRRRJRJJJJJJJJRRRRRRRRRRRRRRJJJJJJJ  JJJ°°°°°°°°°°°°°°°                                                           
                                    JRRRRRRRRRRRRRRRRRRRRJJJRRRRRRRRRRRRRRRRRJJJJJJ°    °°°°°°°°°°°°°                                                              
                                    JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                               
                                    JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJRJ                                                                                
                                   °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRRJ                                                                                
                                   °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJR°                                                                                
                                   JRJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                                
                                   JJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ                                                                                 
                                   JJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJRJ                                                                                 
                                  °RJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRRJ                                                                                 
                                  JRJJJJJJJJJJJJJJJJRJRRRRRRRRRRRRRRRRRRRRRJJJJJJ°                                                                                 
                                  RRRJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                                 
                                  RRRRJJJ°°°JJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRJJJJRJ                                                                                  
                                 °RRJJJJ°°°°°°°°JJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJJ                                                                                  
                                 JRRJJJ°°°°°°°°°°°°JJJJJJJJJJJJJRRRRRRRRRRJJJJJJ°                                                                                  
                                 R¢RRRJJJ°°°°°°°°°°°°°°°JJRJJJJJJJJJJJJJRJJJJJJJ°                                                                                  
                                 RRRRRRRJJJ°°°°°°°°°°°°° °°JJJJJJJJJJJJJJJJJJRRJ°                                                                                  
                                 RRRRRJJ°°J°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJ°°°°                                                                                   
                                 JRRRRJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°                                                                                   
                                  RRRJJ°°°°  °°°°°°°°°°°°°°°° ° °°°°°°°°°°°°°°°                                                                                    
                                   JJJ°° °     °°°     °°°°°°°°°° °°°°°°°°°°°°°°                                                                                   
                                    °J°°°°                  °°°°°°°°  ° °°°°JJR°                                                                                   
                                       °°°°°                     °°°°°°°°°JJJRR                                                                                    
                                         °°°°                       °°°°°°°°JJJ                                                                                    
                                            °°   °°                   °°°°°°°°°                                                                                    
                                                  °°        °°  °      °°°°°°°                                                                                     
                                                      °°°°°°°°°°°°°    °°°°°°                                                                                      
                                                             °°°°°°° °°°°°°°                                                                                       
`,`
                                                                                         °°°       °°°°°°°°                                                        
                                                                                    °°°JJJJ°°°°J°JJJJJJJJJJJJJ                                                     
                                                                                 °°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJ                                                   
                                                                                °°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJ°                                                 
                                                                              °°°°°°   °   °°  °° °°°°°°°°°°JJJJJJJ°                                               
                                                                             °°°°°                 ° °°°°°°°JJJJJJJJ°                                              
                                                                            °°°°                     °°°°°°°°JJJJJJJJ°                                             
                                                                           °°°                      °°°°°°°°°JJJJJJJJR                                             
                                                                          °°°                       °°°°°°°°JJJJJJJJJJJ                                            
                                                                          °°°                      °°°°°°°°°°°JJJJJJJJJ                                            
                                                                         °°°                      °°°°°°°°°°°JJJJJJJJRR                                            
                                                                         °°°°                     °°°°°°°°°°°JJJJJJJJRR°                                           
                                                                        °°°°°°                     °°°°°°°°°°JJJJJJJJRR°                                           
                                                                        °°°°°°°°°                 °°°°°°°°°°°JJJJJJJJRR°                                           
                                                                        °°°°°°°°°°                 °°°°°°JJ°JJJJJJJJJRR                                            
                                                              °°°°°°°°°°J°°°°°°°°°°              °°°°°°°JJJJJJJJJJJJJJJ                                            
                                                        °°°°°°°°°°°°°°°°°°J°°°°°°°°             °  °°°°JJJJJJJJJJJJJJJJ                                            
                                                     °°°°°°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°°          °°°°°°JJJJJJJJJJJJJJJ                                            
                                                   °°°°  °°°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°°°      °°°°°°°JJJJJJJJJJJJJJJ°                                            
                                                  °°°°      °°°°°°°°°°°°°°°°°°JJJJ°°°°°°°°°° ° ° °°°°°°JJJRRRJJJJJJJJJ                                             
                                                 °°°°            °°°°°°°°°°°°°JJJJJ°°°°°°°°°°°°°°°°°°°°JJJRRRRRJJJJJJJ                                             
                                                °°°°°              °°°°°°°°°°°°°°JJJ°°°°°°°°°°°°°°°°°°°JJJRRRRRRRRRRRJ                                             
                                               °°°°°                °°°°°°°°°°°°°JJJJ°°°°°°°°°°°°°°°°°°JJJRRRRRRRRRRRR                                             
                                               °°° °                °°°°°°°°°°°°°°JJJJJ°°°°°°°°°°°°°°°JJJJRRRRRRRRRRRR                                             
                                              °°°°                   °°°°°°°°°°°°°°JJJJJJJJJJ°°°°°°°°°°°JJRRRRRRRRRRRR                                             
                                             °°°°                    °°°°°°°°°°°°°°JJJJJRRRRRJJ°°°°°°°°JJJRRRRRRRRRRJJ°                                            
                                             °°°                     °°°°°°°°°°°°°°JJJJJJRRRRRRJ°°°°°°°JJJRRRRRRRRRRJJJR°°°°°                                      
                                            °°°°                    °° °°°°°°°°°°°°JJJJJJJRRRRRRJ°°°°°°JJJRRRRRRRRRRJ°JJ°°°°°°°°                                   
                                           °°°°                       °°°°°°°°°°°°°JJJJJJJJRRRRRRJ°°°°°JJJRRRRRRRRRRJJJJ   °°°°°°                                  
                                           °°°                       °°°°°°°°°°°°°°JJJJJJJJJRRRRRJ°°°°JJJRRRRRRRRRRRJJJJ    °°°°°°                                 
                                          °°°°                     °°°°°°°°°°°°°°°JJJJJJJJJJRRRRRRJ°°°JJJRRRRRRRRRRRJJJR   °°°°°° °                                
                                          °°°°°                 ° °°°°°°°°°°°°°J°JJJJJJJJJJJJRRRRRRJJJJJRRRRRRRRRRRRJJJR°  °°°°°° °                                
                                         °°°°°°                   °°°°°°°°°°°°°JJJJJJJJJJJJJRRRRRRRRJJJRRRRRRRRRRRRRRRJJ     °°°°°                                 
                                         °°°°°°°°           °    °°°°°°°°°°°°°JJ°JJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRJR       °°°°                                 
                                         °°°°°°°°     °  °° °   °°°°°°°°°°°°°JJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRR       °°°°                                 
                                         °JJ°°°°°°     °°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRJRR¢       °°°°                                 
                                          JJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJJRRRRRRRRRJJR¢°      °°°°                                 
                                          °JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJJRRRRRRJJJJR°      °°°°                                 
                                           JJJJ°°°°°°°°°°°J°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJRRRRRRRRRJJJJJJRRRJJJJJJRJ      °°°°                                 
                                           °JJJJJJ°°°°°°JJJJJJJJJJJ°°°°°°°JJJJJJJJJJJJJJJJJJJJRRRRRRRRJJJJJJJJJJJJJJJJRR     °°°°                                  
                                           °JRRJJJJJJJ°JJJJJJJJJJJJ°°°°°°°°°J°JJJJJJJJJJJJJJJJRJRJRRJJJJJJJJJJJJJJJJJJRR     J°°°                                  
                                 °°°°°°°°JJ°JRRRJJJJJJJJJJJJJJJJJJJ°°°°°°°JJ°JJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJRR     J°°°                                  
                               °°        °°°JRRRRRRRRJJJJJJJJJJJJJJJ°°°°°°JJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJ¢    °°°°°                                  
                              °          °°°JJJRRRRRRRJJJJJJJJRRRRJJJ°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ¢   °J°°°                                   
                             °           °°°JJJJJRRRRJJJJJJJJJJJRRRRRRJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°J°°°°°                                   
                            °            J°JJJJJJJRJJJJJJJJJJJJJJJRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°JJ°°°°°                                    
                            °           °J°JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°                                     
                            °           °J JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJ°°°                                      
                                 °      °°°JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJ°                                        
                                         °°JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJR°                                        
                           °    °         JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJRRRRJRRRRRRJJJJJJJJJJJJJJRRRRRJRRRJJRJ°°                                      
                           °    °         JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJJRRRJRRRRRRRJJRRJRRRRRRRRRRRRRRRRRJJJR°                                       
                           °    °        °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ                                         
                           °    °        °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                         
                           °   °°        °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢J                                         
                           °    °°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                         
                               °°°       JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                               °°°       JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                                °°°      JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                                °°°     °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                            °   °°°°    JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                            °   °°°JJ   JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJR                                         
                                °°°°JJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJR°                                        
                             °   °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJ°                                        
                                 °°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJ¢¢RRRRRRRRRRRRRRRRRJJJJJJJJJJJJJJRJ°                                        
                              °   °°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJRRRRRRRRRJJJRJJJJJJJJJJRJJ°°°°JRRRJJ                                        
                               °   °°J °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°RRRJJ                                        
                                °  °°J °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJJJ°°°°°°°°°° ° ° °°JRRRJ                                        
                                 ° °J° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°° °    °JRRJ                                        
                                  °JJ°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°          °°JRRJ                                        
                                   JJ°°RRJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°    °°°°°JJJJJJ                                        
                                    °°JRRRRJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JRRR°                                        
                                     JRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°    °JRRJ                                         
                                     JRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJ°°°°°°°°°°°°°           °°                                           
                                     JRRRRRRRRRRJJJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJRRJJJ°°°°°°°°°°°                                                              
                                     JRRRRRRRRRRRJJRJJJJJJJJJJJJRRRRRRRRJJJRRJJJJJJJJRRJ°°°°°°°°°°°°°                                                              
                                     JRRRRRRRRRRRRRRRRRJJJJJJJJRRRRRRRRRRRRRRJJJJJJJ  °°°°°°°°°°°°°°°°°                                                            
                                    °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ                                                                               
                                    °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°                                                                               
                                    JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                               
                                    JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ                                                                                
                                    JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ                                                                                
                                   °RJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRRJ                                                                                
                                   JRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°                                                                                
                                   JJJJJJJJJRRJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°                                                                                
                                   RJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ                                                                                 
                                   RRJJJJJJJJJJJJJJJRJRJRRRRRRRRRRRRRRRRRRRJJJJJRJ                                                                                 
                                  JRRRJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRJJJJRJ°                                                                                 
                                  RRRJJJJ°°°°JJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJJJJRJ°                                                                                 
                                  RRRJJJ°°°°°°°°°JJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJ°                                                                                 
                                  RRRJJJ°°°°°°°°°°°°°JJJJJJJJJJJJRRJRRRRRRJJJJJJJ                                                                                  
                                 °¢RRRRJJ°°°°°°°°°°°°°°°°JJRRRRJJJJJJJJJJRJJJJRRJ                                                                                  
                                 J¢RRRRRJJJ°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJ°                                                                                  
                                 °RRRRJJ°°°J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°°°°                                                                                   
                                  RRRRJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°                                                                                   
                                  °RRJJ°°°°   °°°°°°°°°°°°°°°°° °°°°°°°°°°°°°°°°                                                                                   
                                   °JJJ°  °     °°      °°°°°°°°°°°    °°°°°°°JJ                                                                                   
                                     °J°°°°      °           °°°°°°°°°°°°°°°JJRJ                                                                                   
                                       °°°°°                      °°°°°°°°JJJJRJ                                                                                   
                                          °°°                         °°°°°°°JJ                                                                                    
                                             °°                        °°°°°°°°                                                                                    
                                                  °°    °  °°°° °       °°°°°°                                                                                     
                                                       °°°°°°°°°°°°°° °°°°°°°                                                                                      
                                                              °°°°°°°  °°°°                                                                                        
`,`
                                                                                                    °°°JJJJJ°°                                                     
                                                                                       °°°JJ°°°°°°°J°JJJJJJJJJJJ                                                   
                                                                                    °°°°°°°°°°°°°°°°°°°°°°°JJJJJJ°                                                 
                                                                                  °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJ                                                
                                                                                °°°°°° °  °°°  °°  °°°°°°°°°°°JJJJJJJ                                              
                                                                               °°°°°               ° °°°°°°°°°JJJJJJJJ                                             
                                                                             °°°°°                  °°°°°°°°°°JJJJJJJR°                                            
                                                                            °°°°                    °°°°°°°°°JJJJJJJJRJ                                            
                                                                           °°°°                     °°°°°°°°°JJJJJJJJRR°                                           
                                                                          °°°                      °°°°°°°°°°°JJJJJJJRRJ                                           
                                                                         °°°°                    °°°°°°°°°°°°°JJJJJJJRRJ                                           
                                                                         °°°°                    °°°°°°°°°°°°JJJJJJJJRRJ                                           
                                                                        °°°°°°°°                 ° °°°°°°°°°°JJJJJJJJRRJ                                           
                                                                        °°°°°°°°°               ° °°°°°°°°°°JJJJJJJJJJRJ                                           
                                                                        °°°°°°°°°°°              °°°°°°°J°J°JJJJJJJJJJJ°                                           
                                                             °°°°°°°°°°°J°°°°°°°°°°°             °°°°°°°JJJJJJJJJJJJJJR°                                           
                                                       °°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°           °°°°°°°°JJJJJJJJJJJJJJJ                                            
                                                     °°°°°°°°°°°°°°°°°°°°°JJJ°°°°°°°°°           °°°°°°°JJJJJJJJJJJJJJJ                                            
                                                   °°°°  °°°°°°°°°°°°°°°°°°°JJ°°°°°°°° ° °       °°°°°°°JJJJJJJJJJJJJJJ                                            
                                                  °°°°      °°°°°°°°°°°°°°°°°°JJJJJJ°°°    °  °  °°°°°°°JJRRRJJJJJJJJJ                                             
                                                 °°°°°           °°°°°°°°°°°°°JJJJJJJ°°°°°°° °°° °°°°°°°JJRRRRRRJRRJJ°                                             
                                                °°°°°             °°°°°°°°°°°°°°JJJRRJ°°°°°°°°°°°°°°°°°°JJRRRRRRRRRRR                                              
                                               °°°°°               °°°°°°°°°°°°°°JJJRRJ°°°°°°°°°°°°°°°°°JJRRRRRRRRRRR                                              
                                               °°°°               ° °°°°°°°°°°°°°°JJJRRJJ°°°°°°°°°°°°°°JJJRRRRRRRRRRR°                                             
                                              °°°°                   °°°°°°°°°°°°°°JJJRRRJJJJJJ°°°°°°°°JJJRRRRRRRRRRRJ                                             
                                             °°°°°                   °°°°°°°°°°°°°°JJJJJRRRRRRRJ°°°°°°°JJJRRRRRRRRRRJJ°                                            
                                            °°°°°                   °°°°°°°°°°°°°°°JJJJJJRRRRRRRJJ°°°°°JJJRRRRRRRRRRJ°JJ°°°°°                                      
                                            °°°°                     °°°°°°°°°°°°°°°JJJJJRRRRRRRRJ°°°°°JJJRRRRRRRRRRJ°J°°°°°°°°°                                   
                                           °°°°°                     °°°°°°°°°°°°°°JJJJJJJJRRRRRRRJ°°°°JJJRRRRRRRRRRJ°J°°°°°°°°°°                                  
                                           °°°                       °°°°°°°°°°J°°°JJJJJJJJRRRRRRRJ°°°°JJJRRRRRRRRRRJJJ°     °°°°°                                 
                                          °°°°°                    °°°°°°°°°°°°°°JJJJJJJJJJJRRRRRRRJ°°°JJRRRRRRRRRRRJJJ°   °°°°°°                                  
                                          °°°°°°                °° °°°°°°°°°°°°J°JJJJJJJJJJJRRRRRRRRJJJJRRRRRRRRRRRRJJJJ  °°°°°°°                                  
                                          °°°°°°                ° °°°°°°°°°°°°JJJJJJJJJJJJJJRRRRRRRRRJRRRRRRRRRRRRRRRRJ°     °°°°                                  
                                         °°°°°°°°              °°°°°°°°°°°°°°°JJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRJ      °°°°                                  
                                         °°°°°°°°     °° °° ° ° °°°°°°°°°°°°°JJJJJJJJJJJJJJJJRRRRRRRRRRRRJRRRRRRRRRRRRJ       °°°°                                 
                                          JJ°°°°°°° ° °°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJRRRRRRRRJJRRJ       °°°°                                 
                                          JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJ°JJJJJJJJJJJJJJJJRRRRRRRRRRJRJJRRRRRRRRJJRJ       °°°                                  
                                          °JJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJRRRRRRRRRRJJJJJRJRRRRJJJJR      °°°°                                  
                                           JJJJ°°°°°°°°°°°JJJJJJ°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJRRRRRJRJJJJJJJJRRJJJJJJR      °°°°                                  
                                            JJJJJJ°°°°°°JJJJJJJJJJJ°°°°°°°JJJJJJJJJJJJJJJJJJJJJRRRRRRJJJJJJJJJRJJJJJJJR      J°°°                                  
                                           °JJRJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°J°JJJJJJJJJJJJJJJJRJJRJJJJJJJJJJJJJJJJJJJJR     °°°°°                                  
                                 °°°°°°°°JJ°°JRRJJJJJJJJJJJJJJJJJJ°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJJJR°    °°°°°                                  
                               °°        °° JJRRRRRRRJJJJJJJJJJJJJJJ°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJRJ    J°°°                                   
                              °          °°°JJRRRRRRRRJJJJJJJRRRRRJJJ°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ   J°°°°                                   
                             °           °°°JJJJRRRRRRJJJJJJJJJJRRRRRRJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ JJ°°°°                                    
                             °           J°°JJJJJJRJJJJJJJJJJJJJJJJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°J°°°°°°                                    
                            °            J°JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°                                      
                            °           °J °JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                       
                            °           °°°°JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                                         
                            °             °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                                         
                                °         JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJRRRRJJRRRRRJJJJRJJJJJJJJJRJRJJJJJJJJR°°                                       
                                °         JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJRRRJRRRRRRRJJRRRRRRRRRRRRRRRRRRRRJJRJ                                        
                                °         JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ                                          
                                °°        JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJRJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                          
                               °°°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                          
                                °°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                          
                                °°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                          
                                °°°      JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                          
                            °   °°°      JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJRJJRRRRRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                         
                            °   °°°     °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                         
                            °   °°°J    °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJRRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJR°                                         
                                °°°°J   JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJRJ                                         
                             °   °°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ                                         
                                °°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJJ                                         
                                  °°°°JJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJRRRRRRRRRRRRRRRRRRJJJJJJJJJJJJJJRJJ                                         
                              °    °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJRRRJJJJJJJJJJJJJJJJJJJRJJJ°°°°JRRRJ                                         
                                    °J°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJ°°°°°°°°°°JRRRJ                                         
                                °   °J °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°° °°°JJJJ                                         
                                 °  JJ °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°  °      °°JRR°                                        
                                  °°J° JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°       °°°°JRRJ°                                        
                                   JJ°°JRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°° °° °°°°°°°JJJJJJ                                         
                                     °JRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJRJ                                         
                                     °JRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°      °JRJ                                          
                                     °RRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJRRJJJJJ°°°°°°°°°°°°°            °°°                                           
                                     JRRRRRRRRRRJJJJJJJJJJJJJJJJRJJJJJJJJJJJJRJJJJJJJRRJJ°°°°°°°°°°°°                                                              
                                     JRRRRRRRRRRRJRRJJJJJJJJJJJJRRRRRRRJRRRJRRJJJJJJJRJJ°°°°°°°°°°°°°                                                              
                                     JRRRRRRRRRRRRRRRRJRJJJJJJJRRRRRRRRRRRRRRJJJJJJJ° °°°°°°°°°°°°°°°°                                                             
                                     JRRRRRRRRRRRRRRRRRRRRRRJRRRRRRRRRRRRRRRRJJJJJJJ                                                                               
                                     JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ                                                                               
                                    °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°                                                                               
                                    JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                               
                                    JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                               
                                    RJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ                                                                                
                                   °RJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJRJ                                                                                
                                   JJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJR°                                                                                
                                   JRJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                                
                                   RRJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRJJJJRJ                                                                                 
                                   RRRJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRJJJJJJJ                                                                                 
                                  °RRRJJJ°°°°JJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJJRJRRJ                                                                                 
                                  JRRJJJJ°°°°°°°°JJJJJJJJJJJRRRRRRRRRRRRRRRJJJJJJ°                                                                                 
                                  RRRJJJ°°°°°°°°°°°°°JJJJJJJJJJJJJRJJJRRRRRJJJJJJ°                                                                                 
                                  RRRRRJJJ°°°°°°°°°°°°°°°JJJRRRJJJJJJJJJJRJJJJJRJ                                                                                  
                                 °RRRRRRJJJJ°°°°°°°°°°°°°° °°°JJJJJJJJJJJRJJJJJJ°                                                                                  
                                  RRRRRJJ°°J°°°°°°°°°° °°°°°°°°°°°°°°°°°°°J°°°°°°                                                                                  
                                  RRRRJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°                                                                                   
                                   RRRJ°°°°°  °°°°°°°°°°°°°°°° ° °°°°°°°°°°°°°°°                                                                                   
                                    JJJ°° °     °°      °°°°°°°°°°°°° °°°°°°°°°J                                                                                   
                                     °J°°°°                  °°°°°°°°°°  °°°JJRR                                                                                   
                                       °°°°°°                      °°°°°°°°JJJJJ                                                                                   
                                          °°°°                        °°°°°°°JJ°                                                                                   
                                             °°    °                    °°°°°°°                                                                                    
                                                 ° °°       °°°          °°°°°°                                                                                    
                                                       °°°°°°°°°°°°°°  °°°°°°°                                                                                     
                                                               °°°°°°  °°°°°                                                                                       
`,`
                                                                                                     °°°°°°°°°                                                     
                                                                                          °°°° °°°°JJJJJJJ°JJJJJ                                                   
                                                                                     °°°°°°°°°°°°°°°°°°°°°°°JJJJJJ                                                 
                                                                                   °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJ°                                               
                                                                                 °°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRJ                                              
                                                                                °°°°°°              °°°°°°°°°°°JJJJJJR°                                            
                                                                               °°°°°                 °°°°°°°°°°JJJJJJRJ                                            
                                                                              °°°°                   °°°°°°°°°JJJJJJJJRJ                                           
                                                                             °°°                     °°°°°°°°°JJJJJJJJRR                                           
                                                                            °°°                    °°°°°°°°°°°°JJJJJJJRR°                                          
                                                                           °°°                   °°°°°°°°°°°°°JJJJJJJJRR°                                          
                                                                          °°°                    °°°°°°°°°°°°JJJJJJJJJRR°                                          
                                                                         °°°°                   °°°°°°°°°°°°°JJJJJJJJJRR°                                          
                                                                         °°°°°°°                 °°°°°°°°°°J°JJJJJJJJJJR°                                          
                                                                         °°°°°°°°°°°               °°°°°°°JJ°°JJJJJJJJJJ                                           
                                                               °°°°°°°° °°°°°°°°°°°°°              °°°°°°JJJJJJJJJJJJJJJ                                           
                                                        °°°°°°°°°°°°°°°°JJ°°°°°°°°°°°            °°°°°°°°JJJJJJJJJJJJJJJ                                           
                                                     °°°°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°°            °°°°°°JJJJJJJJJJJJJJJJ                                           
                                                   °°°°°°°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°°           °°°°°°°JJJJJJJJJJJJJJ°                                           
                                                  °°°°    °°°°°°°°°°°°°°°°°JJJ°°J°°°°°°°    °  ° °°°°°°°JJJJRJJJJJJJJJJ                                            
                                                 °°°°          °°°°°°°°°°°°°°°JJJJJJJJ°°°°°°  °  °°°°°°°°JJRRRRJJJJJJJ                                             
                                                °°°°°            °°°°°°°°°°°°°°JJJRRRRJ°°°°  °°°°°°°°°°°JJJRRRRRRRRRR                                              
                                               °°°°°              °°°°°°°°°°°°°°JJJRRRRJ°°°°°°°°°°°°°°°°°JJRRRRRRRRRR°                                             
                                               °°°°               ° °°°°°°°°°°°J°JJJRRRRJJ°°°°°°°°°°°°°°JJJRRRRRRRRRR°                                             
                                              °°°                   °°°°°°°°°°°°°JJJJRRRRRJJJJJ°°°°°°°°°°JJRRRRRRRRRRJ                                             
                                             °°°°                 °  °°°°°°°°°°°°°JJJJJRRRRRRRRJJ°°°°°°°JJJRRRRRRRRRJJ                                             
                                            °°°°                    °°°°°°°°°°°°°°°JJJJJRRRRRRRRRJ°°°°°°JJJRRRRRRRRRJJJJ°°°                                        
                                           °°°°°                    °°°°°°°°°°°°°°°°JJJJJRRRRRRRRRJ°°°°°JJJRRRRRRRRRJJJJ°°°°°°°                                    
                                           °°°°                   °  °°°°°°°°°°°°°°JJJJJJJRRRRRRRRRJ°°°°JJJRRRRRRRRRJ°JJ°°°°°°°°°                                  
                                          °°°°                °    ° °°°°°°°°°°°°°°JJJJJJJJRRRRRRRRJ°°°°JJJRRRRRRRRRJ°JJ  °°°°°°°°                                 
                                          °°°°°                    °°°°°°°°°°°°°°°JJJJJJJJJRRRRRRRRRJ°°°JJRRRRRRRRRRJJJJ    °°°°°°                                 
                                          °°°°°           °       °°°°°°°°°°°°°°°JJJJJJJJJJJRRRRRRRRRJJJJJRRRRRRRRRJRJJR°   °°°°°°                                 
                                         °°°°°°                 °°°°°°°°°°°°°°JJJJJJJJJJJJJJRRRRRRRRRJJJJRRRRRRRRRRRRJJJ     °°°°                                  
                                         °°°°°°°                ° °°°°°°°°°°°°°°J°JJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRR       °°°°                                 
                                         °°°°°°°°     °° °°    ° °°°°°°°°°°°°JJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRJ       °°°°                                 
                                         °JJ°°°°°  °°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJRJRRRRRRRRRRRJRRRRRRRRJRRJ       °°°°                                 
                                          JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJRRRRRRRRJJJJR       °°°°                                 
                                          JJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJ°JJJJJJJJJJJJJJJJJJJRRRRRRRJJJJJJRRJRJJJJJR       °°°°                                 
                                           JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJRRJRRRRJJJJJJJJJJRJJRJJJJR      °°°°°                                 
                                           °JJJJ°°°°°°°°°JJJJJJJJ°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJRJRJJJJJJJJJJJJJJJJJJR      °°°°                                  
                                           °JJJJJJJ°°°°JJJJJJJJJJJJ°°°°°°°°JJ°JJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJJJJJJJJJJJ°     J°°°                                  
                                   °°°°°°JJ°JRRJJJJJJJJJJJJJJJJJJJJ°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ    °J°°°                                  
                               °°°°     °°°°JRRRRRJJJJJ°JJJJJJJJJJJ°°°°°°°JJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJ    J°°°°                                  
                              °°         °°°JJRRRRRRRRJJJJJJJJJJJJJJ°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJR   °J°°°                                   
                             °           °°°JJJRRRRRRRJJJJJJJJJRRRRRJJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  JJ°°°°                                   
                             °           J°°JJJJJJRRRJJJJJJJJJJJRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°JJ°°°°°                                    
                            °           °J°JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°                                     
                            °           °J JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°                                      
                            °           J° °JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                        
                                         °°JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                        
                           °    °         JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJRRRRJJRJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJ°                                        
                           °    °         JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJJRRRJRRRRRRRJJRRRRJJRJRJRRRRJJJJJRJJJJ°                                       
                           °    °         JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJRRRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ                                         
                           °    °        °JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                          
                           °   °°        °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                          
                           °   °°°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                          
                               °°°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                          
                               °°°       JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                         
                                °°°      JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                         
                                °°°     °JJJJJJJJJJJJJJJJJJJJJJJJJJJRRJRRRRRRRRRRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                         
                            °   °°°°    JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJRRRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                         
                            °   °°°J°   JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ                                         
                            °   °°°°J° °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ                                         
                             °  °°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJ                                         
                                  °°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJJJJJJ                                         
                              °   °°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJRRRRJJJJJJJJJJJJJ°°°JJJJ                                         
                               °    °°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°JJJJ                                         
                                °   °J °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJJRJJJ°°° °°°°°°°°°°JJJJ°                                        
                                 ° °J° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°J°°°°°°°°°°°°°°°°°°°°°°    °°JJR°                                        
                                 °°°J° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°  ° °   °°°JRR°                                        
                                  °JJ°°RRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°      °°°°JJJJJ°                                        
                                    °°JRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJR                                         
                                     JRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°     °JJRJ                                         
                                     JRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJ°°°°°°°°°°°°          °°J°                                          
                                     JRRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJ°°°°°°°°°°°°                                                            
                                     JRRRRRRRRRRJJJJJJJJJJJJJJJJRRJRJJJJJJJJRJJJJJJJJRRJJ°°°°°°°°°°°°°                                                             
                                     JRRRRRRRRRRRRRRJRJJJJJJJJJRRRRRRRRRRRRRRJJJJJJJ°°JJ°°°°°°°°°°°°°°°                                                            
                                    °RRRRRRRRRRRRRRRRRRRRRJJJJRRRRRRRRRRRRRRRJJJJJJJ    °°°°°                                                                      
                                    °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°                                                                               
                                    JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                               
                                    JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ                                                                                
                                   °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJRJ                                                                                
                                   °RJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRRJ                                                                                
                                   JRJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                                
                                   JJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°                                                                                
                                   RJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ                                                                                 
                                  °RRJJJJJJJJJJJJJJJRJJRRRRRRRRRRRRRRRRRRRRJJJJJRJ                                                                                 
                                  JRRJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRJJJJJJ°                                                                                 
                                  RRRJJJJ°°JJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRJJJRRJ°                                                                                 
                                  RRRJJJJ°°°°°°JJJJJJJJJJJJRRRRRRRRRRRRRRRRJJJJJJ                                                                                  
                                 °RRRJJJ°°°°°°°°°°°JJJJJJJJJJRJRRRRRRRRRRRRJJJJJJ                                                                                  
                                 J¢RRRJJJ°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJRRJJJJJJ°                                                                                  
                                 J¢RRRRRJJ°°°°°°°°°°°°° °°JJJJJJJJJJJJJJJJJJJJRR°                                                                                  
                                 JRRRRRJJ°JJ°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJ°°                                                                                   
                                 °RRRRJJ°°°°°°°°°°°°°°°°°°°°° °°°°°°°°°°°°°°°°°°                                                                                   
                                  RRRJJ°°°°  °°°°°°°°°°°°°°  °°°°°°°°°°°°°°°°°°                                                                                    
                                   JRJ°° °°    °°°  °°°°°°°°°°°°°°°°°°°°°°°°°°°°                                                                                   
                                    °J°°°°      °         °°°°°°°°°°    °°°°°JJJ                                                                                   
                                      °°°°°      °              °°°°°°°°°°JJJRR°                                                                                   
                                        °°°°°                        °°°°°°JJJJ                                                                                    
                                           °°°                        °°°°°°°°J                                                                                    
                                              °   °°                    °°°°°°°                                                                                    
                                                      °°°°°°°°°°°°     °°°°°°°                                                                                     
                                                        °°°°°°°°°°°°°°°°°°°°                                                                                       
                                                                       °°                                                                                          
`,`
                                                                                                     °°°J°JJJJ°°                                                   
                                                                                           °°°°°°°°°JJJJJJJ°JJJJJ°                                                 
                                                                                       °°J°°°°°°°°°°°°°°°°°°°JJJJJJ°                                               
                                                                                    °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJ                                              
                                                                                   °°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJRJR°                                            
                                                                                 °°°°°°°             °°°°°°°°°°°JJJJJRR°                                           
                                                                                °°°°°                 °°°°°°°°°JJJJJJRRR°                                          
                                                                               °°°°                    °°°°°°°°°JJJJJJRRJ                                          
                                                                              °°°                   ° °°°°°°°°JJJJJJJJJRR°                                         
                                                                             °°°°                  °°°°°°°°°°°°JJJJJJJJRRJ                                         
                                                                            °°°°                   °°°°°°°°°°°°JJJJJJJJRRJ                                         
                                                                           °°°                    °°°°°°°°°°°°JJJJJJJJJRRJ                                         
                                                                          °°°°                    °°°°°°°°°°JJ°JJJJJJJJRRJ                                         
                                                                          °°°°°° °                °°°°°°°°°J°JJJJJJJJJJJR°                                         
                                                                  °       °°°°°°°°°°°            °°°°°°°°°°JJJJJJJJJJJJJJ°                                         
                                                         °°°°°°°°°°°°°°° °°°°°°°°°°°°°°            °°°°°°°°JJJJJJJJJJJJJJ                                          
                                                     °°°°°°°°°°°°°°°°°°JJJ°°°°°°°°°°°°    °       °°°°°°°°JJJJJJJJJJJJJJJ                                          
                                                   °°°°°°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°°°°            °°°°°°JJJJJJJJJJJJJJJ                                          
                                                  °°°   °°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°°°°°          °°°°°°JJJJJJJJJJJJJJ°                                          
                                                 °°°          °°°°°°°°°°°°°JJ°°°°J°°°°°°°°    ° °° °°°°°°°JJJRRJJJJJJJJJ                                           
                                                °°°             °°°°°°°°°°°°°JJJ°°°JJJJJ°° °°°  ° °°°°°°°°JJJRRRRJJJJJJ                                            
                                               °°°°             °°°°°°°°°°°°°°J°J°JRRRRRJ°°°° °°°°°°°°°°°°JJJRRRRRRRRR                                             
                                              °°°°               °°°°°°°°°°°°°°°JJJRRRRRRJ°°°°°°°°°°°°°°°°JJJRRRRRRRRR                                             
                                             °°°°°               ° °°°°°°°°°°°°°°JJJRRRRRRJ°°°°°°°°°°°°°°JJJJRRRRRRRRR°                                            
                                            °°°°                    °°°°°°°°°°°°°JJJJRRRRRRRJJJJ°°°°°°°°°JJJJRRRRRRRRR°                                            
                                           °°°°                  °  °°°°°°°°°°°°°JJJJJJRRRRRRRRRRJJ°°°°°°JJJJRRRRRRRRRJ                                            
                                           °°°°                    °°°°°°°°°°°°°°J°JJJJJRRRRRRRRRRRJ°°°°°JJJJRRRRRRRRJJJJ°°°°                                      
                                          °°°°                       °°°°°°°°°°°°°°JJJJJJRRRRRRRRRRRJ°°°°JJJJRRRRRRRRR°J°°°°°°°°°                                  
                                          °°°°                   °  °°°°°°°°°°°°°°JJJJJJJRRRRRRRRRRRR°°°°JJJJRRRRRRRRRJJ°°°°°°°°°°                                 
                                         °°°°°°             °       °°°°°°°°°°°°°°JJJJJJJJRRRRRRRRRRRJ°°°°JJJRRRRRRRRRJJJ  °°°°°°°°                                
                                         °°°°°                  ° °°°°°°°°°°°°°°°°JJJJJJJJJRRRRRRRRRRJ°°°JJJRRRRRRRRRRJJJ   °°°°°°°                                
                                         °°°°°°                °°°°°°°°°°°°°°°°°JJJJJJJJJJJJRRRRRRRRRRJJJJJJRRRRRRRRRRJJJ   °°°°°°°                                
                                         °°°°°°                ° °°°°°°°°°°°°°JJJJJJJJJJJJJJRRRRRRRRRRRJJJJRRRRRRRRRRRJJJ     °°°°                                 
                                         °°°°°°°°° °    °    °° °°°°°°°°°°°°°°J°°JJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRR       °°°°                                
                                         JJJ°°°°  °°°°°°°°°°   °°°°°°°°°°°°°JJJJJJJJJJJJJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRJ       J°°°                                
                                         °JJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJRJJJRRRRRRRRRRRRRRRRRRRJRRJ       J°°°                                
                                         °JJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°JJ°JJJJJJJJJJJJJJJJJRJJJRRRRRRRRJJJRJRRRRRJJJRJ       J°°°                                
                                          JJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°JJJ°JJJJJJJJJJJJJJJJJRJJJJRRRRRRRRJJJJRRRJJJJJJJ      °°°°°                                
                                           JJJJJ°°°°°°°°JJJJJJJ°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJRJJJJJRRRRJRJJJJJJJJJJJJJJJ      °°°°°                                
                                           JJRJJJJ°°°°°JJJJJJJJJJJ°°°°°°°J°JJJJJJJJJJJJJJJJJJJRJJJJRRJJJJJJJJJJJJJJJJJJJ      J°°°                                 
                                 °°°°°°°°R°°JRRJJJJJJJJJJJJJJJJJJJJ°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ      J°°°                                 
                               °°°     °°J°JJRRRRJJJJJJJJJJJJJJJJJ°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ     °J°°°                                 
                             °°          °°JJRRRRRRRRJJJJJJJJJJJJJ°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°    J°°°                                  
                            °           °J°JJJRRRRRRRJJJJJJJJJRRRRJJ°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°   J°°°°                                  
                            °           °J°JJJJJRRRRJJJJJJJJJJJRRRRRJJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ° °JJ°°°°                                  
                                        °°°JJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°                                   
                           °            J°°JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°                                    
                           °           °J °JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°                                     
                           °    °        °°JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                                        
                           °    °        °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                                        
                          °°   °°        JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                       
                          °    °°        JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJRRJRRRRRRRRJJJJRJJJJJJJJJRRRJJJJJRRJJJ                                       
                          °°   °°        JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJRRJRRRRRRRRRRJJRRRRRRRRRRRRRRRRRRRRJ°                                        
                          °    °°        JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                          °    °°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                          °    °°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                           °   °°       JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                           °   °°°      JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                         
                           °   °°J     °JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJRRRRRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                         
                           °   °°°J    JJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJRRRRRRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                        
                               °°°J°   JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJRJJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                        
                            °  °°°°JJ°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                        
                            °   °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ                                        
                             °   °°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJ                                        
                                 °°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJJJ°JJ                                        
                              °   °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRJJJJJJJJJJJJ°°°°°JJ                                        
                               °   °J °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJRJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°JJ                                        
                                ° °J° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJJJJJJJJ°°°°° °°°°°°°°°°°J                                        
                                 °°J° JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°JJ°°°°°°°°°°°°°°°°°°°°   °°°JR°                                       
                                 °JJ°°RRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°  ° °  °°°JJRR°                                       
                                   °°JRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°° °°°  °°°°°°JJJJJ°                                       
                                    JRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJ                                        
                                    JRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJ°°°°°°°°°J°°°°°°°°°°°°      °°JJJ                                        
                                    JRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJ°°°°°°°°°°°           °°J°                                         
                                    JRRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°JRRRRJJ°°°°°°°°°°°°°                                                           
                                   °JRRRRRRRRRRRRRJJJJJJJJJJJJRRRRRRRRRRRJJRJJJJJJJ  JRRRJ°°°°°°°°°°°°°                                                            
                                   °RRRRRRRRRRRRRRRRRRRRJJJJRRRRRRRRRRRRRRRRJJJJJJJ   °JJJ°°°°°°°°°°°°°°                                                           
                                   JRRRRRRRRRRRRRRRRRRRRRRJRRRRRRRRRRRRRRRRRJJJJJJ°      °°°°°°  °°                                                                
                                   JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°                                                                                
                                   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJRJ                                                                                 
                                  °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJRJ                                                                                 
                                  JRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                                 
                                  RJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                                 
                                  RJJJJJJJRRRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ                                                                                  
                                 °RJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ                                                                                  
                                 JRJJJJJJJJJJJJJJJJRRJRRRRRRRRRRRRRRRRRRRRJJJJJJJ                                                                                  
                                 RRRJJJJJJJJJJJJJJJJJRJRRRRRRRRRRRRRRRRRRRJJJJRJ°                                                                                  
                                 RRRJJJJ°JJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRJJJJRJ°                                                                                  
                                °RRJJJJ°°°°°°JJJJJJJJJJJJJRRRRRRRRRRRRRRRJJJJRRJ                                                                                   
                                JRRJJJJ°°°°°°°°°°JJJJJJJJJJRRRRRRRRRRRRRRJJJJJJJ                                                                                   
                                RRRRRJJJ°°°°°°°°°°°°JJJJJJJJJJJJRRJJJJRRRJJJJJJ°                                                                                   
                                RRRRRRRJJ°°°°°°°°°°°°°°°JJRRRRJJJJJJJJJJJJJJJRJ°                                                                                   
                                RRRRRJJ°°J°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJ                                                                                    
                                JRRRJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJ°°°°°                                                                                    
                                °RRRJJ°°°°  °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°                                                                                     
                                 °RJJ°° °     °°°  °°°°°°°°°°° °°°°°°°°°°°°°°°                                                                                     
                                   JJ°°°°      °°       °°°°°°°°°°°° °°°°°°°°J                                                                                     
                                     °°°°°                    °°°°°°°°°°°JJJRR                                                                                     
                                       °°°°     °                 °°°°°°JJJJJJ                                                                                     
                                         °°°    °                   °°°°°°°°JJ                                                                                     
                                             °°°°°                    ° °°°°°                                                                                      
                                                °°       °°°°°° °     °°°°°°°                                                                                      
                                                     °°°°°°°°°°°°°°° °°°°°°°                                                                                       
                                                            °°°°°°°°°°°°°°                                                                                         
`,`
                                                                                                       °°JJJJJJJJJ°                                                
                                                                                                   °°°JJJJJJ°J°JJJJJ°                                              
                                                                                           °°°JJ°°°°°°°°°°°°°°J°JJJJJJ°                                            
                                                                                        °°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJ                                           
                                                                                       °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRR°                                         
                                                                                     °°°°°°°°°°  ° °° °° °°°°°°°°°JJJJJRRR°                                        
                                                                                    °°°°°°°             °°°°°°°°°JJJJJJJRRR                                        
                                                                                   °°°°°                ° °°°°°°°JJJJJJJJRRJ                                       
                                                                                  °°°°°                 °°°°°°°°JJJJJJJJJJRR                                       
                                                                                 °°°°               ° °°°°°°°°°°JJJJJJJJJJRR                                       
                                                                                °°°°                °°°°°°°°°°°°JJJJJJJJJJRR°                                      
                                                                               °°°                  °°°°°°°°°°°JJJJJJJJJJJRR°                                      
                                                                              °°°                    °°°°°°°JJJJJJJJJJJJJJJR°                                      
                                                                             °°°°                  °°°°°°°°°°JJJJJJJJJJJJJRR                                       
                                                                             °°°         °°       °°  °°°°°°°°JJJJJJJJJJJJJJ                                       
                                                                            °°°°°°°°°°°°°°°°          °°°°°°°°JJJJJJJJJJJJJJ                                       
                                                           °                °°°°°°°°°°°°°°°         ° °°°°°°°°JJJJJJJJJJJJJJ                                       
                                                 °°°°°°°°°°°°°°°°°°         °°°°°°°°°°°°°°°°  °°      °°°°°°°JJJJJJJJJJJJJJ°                                       
                                               °°°°°°°°°°°°°°°°°°°JJJ       °°°°°°°°°°°°°°°°°°         °°°°°°°JJJJJJJJJJJJJ                                        
                                             °°°°°°°°°°°°°°°°°°°°°°JJJ      °°°°°°°°°°°°°°°°°°°  °   °°°°°°°°°JJJJRRJJJJJJ°                                        
                                            °°°° °°  °°°°°°°°°°°°°°°°JJ      °°°°°°°°°°°°°°°°°°  ° °  °°°°°°°J°JJJRRRRRRR                                          
                                           °°°°         °° °°°°°°°°°°°JJ°    J°°°°°°°°°°°JJJJ°°°°°°°°°°°°°°°J°°JJJRRRRRRR                                          
                                          °°°°             °°°°°°°°°°°°JJJ   °J°°°°°°°JJJRRRRJ°°°°°°°°°°°°°°°°JJJJRRRRRRR°                                         
                                         °°°°°              °°°°°°°°°°°°JJJ°  JJ°°°°°°JRRRRRRRJ°°°°°°°°°°°°°°°JJJJRRRRRRRJ                                         
                                         °°°°                °°°°°°°°°°°°°JJ° °JJJJ°°JJRRRRRRRRRJJ°°°°°°°°°°°JJJJJRRRRRRRJ                                         
                                        °°°°                 °°°°°°°°°°°°°°°JJ°JJJJ°JJRRRRRRRRRRRRRJJJJJ°°°°°°JJJJRRRRRRRJJJ°°°°                                   
                                       °°°°                   °°°°°°°°°°°°°°JJJ°JJJJJJJRRRRRRRRRRRRRJRRRJJ°°°°JJJJRRRRRRRJJJ°°°°°°°°                               
                                      °°°°                    °°°°°°°°°°°°°°°JJJJJJJJJJRRRRRRRRJRRRRJRRRRJ°°°°JJJJRRRRRRRJ°J°°°°°°°°°                              
                                      °°°°                    °°°°°°°°°°°°°°°JJJJJJJJJJJRRJRRRRRRRRJJRRRRRJ°°°JJJJRRRRRRRJJJ °°°°°°°°                              
                                     °°°°°                     °°°°°°°°°°°°°°°JJJJJJJJJRRJJJRRRRJRJJJJRRRRJ°°°°JJJRRRRRRRRJJ   °°°°°°°                             
                                     °°°°                     °°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJRRRRRRJJJRRRRRJ°°JJJRRRRRRRRRJJ  °°°°°°°°°                            
                                    °°°°°                 °   °°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJRRRJJJJRRRRRRJJJJJRRRRRRRRRJJ°    °°°°°                             
                                    °°°°°°                   °°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJRJJJJJJJRRRRRRRJJJRRRRRRRRRRR°      °°°°°                            
                                    °°°°°°°                °°°°°°°°°°°°°°°°°°JJJJJJJJJJJJRJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRR       °°°°                             
                                    °°°°°°°  °            °°°° °°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRR       J°°°                             
                                    °J°°°°° °°°°°°° ° °   °°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRR°      J°°°                             
                                    °J°°°°°°°°°°°°°°°   °°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJRJJJJJJJJJJJJJJJJRRRRJRRRRJRRJRRRRRR°     °J°°°                             
                                     JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJJJJRJRRRJRRJ     °J°°                              
                                     °JJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJRRJJRRJ     JJ°°                              
                                      °JJ°°°°°°°°°°°°°°°°°°°°°°°°°J°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJ     J°°°                              
                                      °JJJJ°°°°°JJJJJJJ°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRR    °J°°°                              
                            °°°°°°°°J°°RRJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRR    J°°°°                              
                         °°°       °°°JRRRJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRR°  JJ°°°                               
                        °           °°JRRRRRRJJJJJJJJJJJJJJ°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJR°°JJ°°°°                               
                       °            °°JRRRRRRRJJJJJJJJJJJJJ°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJ°°°°                                
                       °           °°°JJJJRRRRJJJJJJJJJJRRRJJ°°°J°J°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJ°°°°                                 
                      °°           J°JJJJJJRRRJJJJJJJJJJJJJJJJ°JJJJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJ°°°°                                 
                      °°          °J JJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJ°°                                   
                      °     °     °°°JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJ                                    
                      °    °        °JJJJJJJJJJJJJJJJJJJJJJJRJRRRRRRRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJ                                    
                      °   °°        JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJ                                   
                     °°   °°       °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRJRRRRRRR°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJRRRRRRJ                                    
                     °°   °°       °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRJ °JJJJJJJJJJJJJJJJJJJJJRJRJRRRRRRRRJRRRRRR                                     
                          °°       °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJRRJ °JJJJJRRJJJJJJJJJJJJJRRRRRRRRRRRRRJRRRRRR°                                    
                         °°°       JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRRJ  JRJRRRRRRRRRRRRRRJJRRRRRRRRRRRRRRRRRRRRR°                                    
                     °   °°°       JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJRRR   JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                    
                         °°°      °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJJJJRRJ   °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                    
                         °°°      JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJRRJ   °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                    
                         °°°J     JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJRR°   °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                    
                      °  °°°°     JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJRJ     JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                    
                      °  °°°°°   °JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJJJJJRJ     JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                   
                      °° °°°°JJ  °JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJJJJRRJ     JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ°                                   
                       °  °°°°JJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJRRRRJJJJJJRJ      JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°                                   
                       °   °°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJRJJJJJJJRJ      °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°°°                                   
                            °°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJR°      °R¢RRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJ°°°°°                                   
                        °    °°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°       R¢RRRRRRRRRRRRRRRRRRRRRJJJJJJJJJ°°°°°°°°                                   
                         °   °° °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ        JRRRRRRRRRRJJJJJJJJJJJJJJJJJ°°°°°°°°°°°J                                   
                             °J JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ        JRJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°JR°                                  
                           ° °°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°        JJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°° °°°JJJJJ                                  
                            °J °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°        JJ°°°°°°°°°°°°°°°°°°°°°°°° °°  °°°JJJJJJJ                                  
                            °J°JRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ         °J°°JJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJ°                                  
                              JRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ          J°°JJ°°°°°°°°°°°°°°°°°°°°°°°°     °°°JJ                                   
                              JRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°          JJJJJJJ°°°°°°JJJ°°°°°°°°  °       °°°°                                    
                              RRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ           JRRRRRJJJJJJJJ°°°°°°°°           °°                                       
                             °RRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°           JRRRRRJJJ°°°°°°°°                                                         
                             °RRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°           °RRRRJJJ°°°°°°°°                                                          
                             J¢RRRRRRRRRJJJJJJJJJJJJJJJRJJRRJJJJJJJJJJJJJJJJJ°            JRRRJJJ°°°°°°°    °°°                                                    
                             J¢RRRRRRRRRRRJJJJJJJJJJJRRRRRRRRRJJJJJJJJJJJJJJJ              °JJJJ°°°°°°°°°°°°                                                       
                             RRRRRRRRRRRRRRRRRRRJJJJRRRRRRRRRRRRRRRRJJJJJJJJ°                    °°°°°                                                             
                            °RRRRRRRRRRRRRRRRRRRRRJJRRRRRRRRRRRRRRRRJJJJJJJJ°                                                                                      
                            JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJ                                                                                       
                            RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJ                                                                                       
                           °RRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°                                                                                       
                           JRJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJRJ°                                                                                       
                           JJJJJJJRRRJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJRJ                                                                                        
                           RJJJJJJJRJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRJJJRJRJ                                                                                        
                          °RJJJJJJJJJJJJJJRJRJRJJRRRRRRRRRRRRRRRRRRJJJJRJJ°                                                                                        
                          RRJJJJJJJJJJJJJJJRJRRRJRRRRRRRRRRRRRRRRRRJJJJJJJ°                                                                                        
                          RJJJJJJJJJJJJJJJJJJRJJRRRRRRRRRRRRRRRRRRRRRJJJJJ                                                                                         
                         °RRJJJJJJJ°JJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRJJJ                                                                                         
                         JRRRRJJJ°°°°°°JJJJJJJJJJRRRRRRRRRRRRRRRRRJRRRRRJ°                                                                                         
                         JRRRRRJJ°°°°°°°°°°JJJJJJJJRRRRRRRRRRRRRRRJJJJJJJ°                                                                                         
                         JRRRRRJJJ°°°°°°°°°°°JJJJJJJJJJJRRRRRRRRRJJJJJJJJ                                                                                          
                         JRJJJJJJ°°°°°°°°°°°  °°JJRRRJJJJJJJJJJJJJJJJJJJ°                                                                                          
                         °RJJJJJ°°°°°°°°°°°°°°°° °°°°JJJJJJJJJJJJJJJJJRJ°                                                                                          
                          RJJJJ°°     °°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJ°°°                                                                                           
                           JJJ°°°      °°°°°°°°°°°°°°°°° °°°°°°°°°°°°°                                                                                             
                            JJ°°                °°°°°°°°°°°°°°°°°°°°°°                                                                                             
                             °J°°                   °°°°°°°°°°°°°°°°°°°°                                                                                           
                               °°°                       °°°°°°°JJJJJRR°                                                                                           
                                 °°°     °                  °°°°°JJJJJJ                                                                                            
                                     °°°°°                   °°  °°°°J°                                                                                            
                                       °°°°  °° °°°°   °°     ° °°°°°°°                                                                                            
                                          °°    °°°°°°°°°°    ° °°°°°°                                                                                             
                                                 °°°°°°°°°°° °  °°°°°                                                                                              
                                                   °°°°°°°°°°°°°°°°°                                                                                               
                                                           °°°°                                                                                                    
`,`
                                                                                                         °°°JJJJJJJJ°                                              
                                                                                                      °°JJJJJJJJJJJJJJ°                                            
                                                                                              °JJJJJ°°°°°°°°°°°°°JJJJJJJ°                                          
                                                                                           °°°°°°°°°°°°°°°°°°°°°°°°°JJJJRJ°                                        
                                                                                         °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRR°                                       
                                                                                        °°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRR°                                      
                                                                                      °°°°°°°°          °  °°°°°°°°°JJJJJJRRR                                      
                                                                                     °°°°°°°               °°°°°°°°JJJJJJJJRRJ                                     
                                                                                    °°°°°               °  °°°°°°°°JJJJJJJJRRR                                     
                                                                                   °°°°°               ° °°°°°°°°°JJJJJJJJJJRR                                     
                                                                                  °°°°°                 °°°°°°°°JJJJJJJJJJJJRR                                     
                                                                                 °°°°                 °°°°°°°°°°JJJJJJJJJJJJRR                                     
                                                                                 °°°                   °°°°°°°°JJJJJJJJJJJJJRR                                     
                                                                                °°°                   °°°°°°°°°JJJJJJJJJJJJJJR                                     
                                                                               °°°°             ° °°°°°°°°°°°°°°JJJJJJJJJJJJJJ                                     
                                                                               °°°         °°°     ° °  °°°°°°°JJJJJJJJJJJJJJJ                                     
                                                                              °°°°°°°°°° °°°°°°     °  °°°°°°°°JJJJJJJJJJJJJJJ                                     
                                                  °°°°°°°°°°°°°               °°°°°°°°°°°°°°°°°   °°° °°°°°°°°°JJJJJJJJJJJJJJ                                      
                                             °°°°°°°°°°°°°°°°°°JJ             °°°°°°°°°°°°°°°°°°°°°° °°  °°°°°°JJJJJJJJJJJJJJ                                      
                                           °°°°°°°°°°°°°°°°°°°°°JJ°           °°°°°°°°°°°°°°°°°°°°°°°    °°°°°°JJJJJJRRJJJJJ                                       
                                          °°°°°°°°°°°°°°°°°°°°°°°JJ°          °°°°°°°°°°°°°°°°°°°° °°°°°°°°°°°°°JJJJJRRRRRR°                                       
                                         °°°°°°°   °°°°°°°°°°°°°°°JJJ°         J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRRRRR¢J                                       
                                        °°°°          °°°°°°°°°°°°°JJJJ°       J°°°°°°°°°°JJJJJJJ°°°°°°°°°°°°°°°JJJJJRRRRR¢J                                       
                                       °°°°              °°°°°°°°°°°JJJJJ      °J°°°°°°°°JJRRRRRRJ°°°°°°°°°°°°°°JJJJJRRRRRRR                                       
                                       °°°                °°°°°°°°°°°°JJJJ      J°°°°°°°JJRRRRRRRRJJ°°°°°°°°°°°°JJJJJRRRRRRR°°                                     
                                      °°°                  °°°°°°°°°°°°°JJJ°    °JJ°J°°°JRRRRRRRRRRRRJJJJJJJ°°°°°JJJJRRRRRRRJJ°°°°°°°°                             
                                     °°°°                  °°°°°°°°°°°°°JJJJ°    °JJJJJJJRRRRRRRRRRJRRRRRRRRJ°°°°JJJJRRRRRRRJJ°°°°°°°°°                            
                                    °°°°                  °°°°°°°°°°°°°°°°JJJJ     JJJJJJRRRRRRRRRJJJJJJRRRRRJ°°°JJJJRRRRRRRJJ°°°°°°°°°°                           
                                   °°°°°                   °°°°°°°°°°°°°°°JJJJJ    °JJJJJRRRRRRRRRJJJJJJRRRRRR°°°JJJJRRRRRRRJJ° °°°°°°°°°                          
                                   °°°°                    °°°°°°°°°°°°°°°°JJJJJ°   JJJJJJRRJRJRRRRJJJJJJRRRRRJ°JJJJJRRRRRRRRJ° °°°°°°°°                           
                                  °°°°°                    °°°°°°°°°°°°°°°JJJJJJJ°  JJJJJJRRJJRJRRJJJJJJJRRRRRRJ°JJJJRRRRRRRRJ°    °°°°°                           
                                  °°°°°                     °°°°°°°°°°°°°°JJJJJJJJ° °JJJJJRJJJRJRJJJJJJJJJRRRRRJJJJJRRRRRRRRRJ°     °°°°                           
                                 °°°°°°                     °°°°°°°°°°°°°°°JJJJJJJJ°°JJJJJJRJJJJJJJJJJJJJJRRRRRRJJJRRRRRRRRRRJ      °°°°°                          
                                 °°°°°°                   ° °°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRR      J°°°                           
                                 °°°°°°° °         °   °°°°°°°°°°°°°°°°°°°°JJJJJJJJRRJJJJJJRRJJJJRJJJJJJJJJRRRRRRRRRRRRRRRRRRR      J°°°                           
                                 °J°°°°°°°  °        °°°° °°°°°°°°°°°°°°J°JJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRR      J°°°                           
                                  J°°°°°°°°°°°°°    ° °°°°°°°°°°°°°°°°°JJ°JJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJRRRRRJRJJJRRRRRRRRR°     J°°°                           
                                  JJ°°°°°°°°°°°°°° °°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJRRRRJJRRRJJRRRRRRRJ     J°°°                           
                                   J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJRRJJRJJJJJJJRRRRRRJ    °J°°°                           
                                   °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRR    °°°°°                           
                                    JJ°°°°°°°°J°°°°°°°°°°°°°°°°°°°°°J°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRR°   JJ°°                            
                                   °JJJJ°°°JJJJJJJJJ°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJRRR°  JJ°°°                            
                        °°°°°°°°°JJ°RRJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJ°JJ°°°°                            
                       °°        °°JRRRJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJ°°°°                             
                      °          °°JRRRRRRJJJJJJJJJJJJ°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJ°°°°                              
                     °           °°JJJRRRRRJJJJJJJJJJJJ°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJ°°°°°                              
                    °°          °°°JJJJRRRJJJJJJJJJJJJRJ°°°J°J°°°°JJJJJJJJJJJJJJJJJJJJ °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRR°°°                                
                    °°          °°°JJJJJRJJJJJJJJJJJJJJJJJ°JJJJJJJJJJJJJJJJJJJJJJJJJJJ °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJ                                 
                    °      °    J°°JJJJJRJJJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJ   JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJ                                 
                    °            °JJJJJJJJJJJJJJJJJJJJJJRRRRRRRJJJJJJJJJJJJJJJJJJJJJ°   °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°                                
                   °°            °JJJJJJJJJJJJJJJJJJJJJJRJJRRRRRRRRRRRRRRRRRJJJRRJJ°    °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJRRRRRJ                                 
                   °°   °        JJJJJJJJJJJJJJJJJJJJJJJRJRRRRRRRRRRRRRRRRRRRRRRRJ      °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJRRRRRRRRRJ                                 
                   °°   °        JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRJRRR°       JJJJJJJJJJJJJJJJJJJJJJJRRJRRRRRRRRRRRRR¢J                                 
                   °   °°       °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJRRJJRRJ        JJJJRJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRR                                 
                   °   °°       °JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJRRJ        JJRRRRRRJJJJJJJJJJJRJRRRRRRRRRRRRRRRRRRRR                                 
                   °   °°°      JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJJJJJRJ        °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                                 
                   °   °°°      JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJJJJJRJ°        °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                                
                   °   °°°     °JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJJJJJRJ          JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                
                   °   °°°°    °JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJJJJJJJ          JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                
                       °°°°    JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJJJJJJJJ          °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                                
                    °  °°°°°   JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJJJJJJJ           °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJRJ                                
                      °°°°°J° °JJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRJRJJJJJJJJJJ           °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJRJ°                               
                    °° °°°°°J°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJRRRJRRRJJJJJJJJJ°            JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ°°                               
                     °  °°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJ°            JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°°°°                               
                     °   °°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ             °RRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJ°°°°°°                               
                            °°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ             °R¢¢RRRRRRRRRRRRRRRRRRRRJJJJJJJJ°°°°°°°°J                               
                      °    °°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°              JRRRRRRRRRRRRRJRJJJJJJJJJJJ°°°°°°°°°°°JR°                              
                       °  °°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°              JRJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°JJJJ                              
                           ° JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ               JJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°   °°JJJJJJ                              
                         °°°°JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°               JJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°JJ°                              
                          J°°RRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°               °RJJ°J°°°°°°°°°°°°°°°°°°°°°°°°°°°° °°°°J                               
                          °°JRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                RJJ°°°°°°°°°°°°°°°°°°°°°°°°°       °°°                                
                           °RRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                 RJJJJ°°°°°°°°JJJ°°°°°°°           °°                                  
                           J¢RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                 JRJJJJJJJJJJJJ°°°°°°°                                                 
                           J¢RRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                 °RRRRRJJJJJ°°°°°°°                                                    
                           R¢RRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                  °RRRRRJ°J°°°°°°°                                                      
                          °R¢RRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                   JRRRRJ°°°°°°°°     °°°°                                              
                          °RRRRRRRRRJJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJ°                    JRRJJ°°°°°°°°                                                       
                          J¢RRRRRRRRRRRJJJJJJJJJJRRRRRRRRRJJJJJJJJJJJJJJJJ°                      °°J°°°°°°°°                                                       
                          R¢RRRRRRRRJRRJRRJJJJJJRRRRRRRRRRRRRJRRJJJJJJJJJJ                                                                                         
                         °R¢RRRRRRRRJRRRRRRRRJJRRRRRRRRRRRRRRRRRRJJJJJJJJ°                                                                                         
                         J¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJ°                                                                                         
                         JRRRRRRRRRRRRRRRRRRRRJRRRRRRRRRRRRRRRRRRRRRJJJJJ                                                                                          
                         RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJRJ°                                                                                          
                        °RRJJRRRRRRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                          
                        JJJRJJRRRRJJJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                          
                        RJJJJJJRRRRJRJRJJRJRRRRRRRRRRRRRRRRRRRRRRRRRRJRJ                                                                                           
                       °JJJJJJJJJJJJJRRJJRRRJJRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                           
                       °JJJJJJJJJJJJJJJJRRRJJRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                           
                       JRRJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°                                                                                           
                       RRRRJJJ°°°JJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRJJ                                                                                            
                      °RRRRRJJ°°°°°°JJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                            
                      JRRRRRRJJ°°°°°°°°JJJJJJJJRRRRRRRRRRRRRRRRRRJJJJJ°                                                                                            
                      °RJJJJJJJJJ°°°°°°°°°JJJJJJJJJJJRRRRRRRRRRRJJJJJJ°                                                                                            
                       RJJJJJ°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJRRJJJJJJJJ°                                                                                             
                       JJJJJ°°°°°°°°°°°°J°°°°°°°°°JJJJRJJJJJJJJJJJRRJJ                                                                                             
                        JJJJ°      °°°°°°°°°°°°°°° °°°°°JJJJJJJJJJJ°°°                                                                                             
                        °JJ°°        °°°° °°°°°°°°°°°°°°°°°°°°°°°°°                                                                                                
                         °J°°         °°       °°°°°°°°°°°°°°°°°°°                                                                                                 
                           J°°         °           °°°°°°°°°JJ°JJJJJJ                                                                                              
                            °°°      °°    °°        ° °°°°°°JJJJJRRJ                                                                                              
                              °     °°°    °        °° °°°°°°°°JJJJJ°                                                                                              
                                 °°°°°°             °°°°°°°°°°°JJJ°°                                                                                               
                                   °°°°   °°°°°°°  °°°°°°°°°° °JJ°°°                                                                                               
                                       °°°°°°°°°°°°°°°°°°°°°°°°JJ°J                                                                                                
                                           °°°°°°°°°°°°°°°°°°°JJJJ°                                                                                                
                                               °°°°°°°°°°°°°°°JJ°                                                                                                  
                                                       °°°°°°                                                                                                      
`,`
                                                                                                              °°°°°°°°                                             
                                                                                                           °JJJJJJJJJJJJ°                                          
                                                                                                        °JJJJJJ°°JJJJJJJJJJ                                        
                                                                                                °°°JJJJ°°°°°°°°°°°°°°JJJJJJJ°                                      
                                                                                              °°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRJ                                     
                                                                                            °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRR                                    
                                                                                           °°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRJ                                   
                                                                                          °°°°°°°              °°°°°°°°JJJJJJJRR°                                  
                                                                                         °°°°°°              ° °°°°°°°JJJJJJJJRRR                                  
                                                                                        °°°°°               °°°°°°°°°°JJJJJJJJJRR°                                 
                                                                                       °°°°°                °°°°°°°°JJJJJJJJJJJRR°                                 
                                                                                      °°°°                  °°°°°°°JJJJJJJJJJJJRRJ                                 
                                                                                     °°°                   °°°°°°°°JJJJJJJJJJJJRRJ                                 
                                                                                    °°°                    °°°°°°°°JJJJJJJJJJJJRRJ                                 
                                                                                   °°°                  °°°°°°°°°°°JJJJJJJJJJJJJR°                                 
                                                                                  °°°°            °°°  °°°°°°°°°°°°JJJJJJJJJJJJJR°                                 
                                                                                  °°°          °°°°°   °°°°°°°°°°°°JJJJJJJJJJJJJJ                                  
                                                                                  °°°   °°°°° °°°°°°   °°°°°°°°°°°°JJJJJJJJJJJJJJ                                  
                                             °°°°°°°°°°°°°°°°°                    °°°°°°°°°°°°°°°°°° °°°°°°°°°°°°°°JJJJJJJJJJJJJ                                   
                                          °°°°°°°°°°°°°°°°°°°JJ                   °°°°°°°°°°°°°°°°°°°°°°°°°°° °°°°°°JJJJJRRJJJJ°                                   
                                         °°°°°°°°°°°°°°°°°°°°°JJ°                 °°°°°°°°°°°°°°°°°°°°°°°° °°°°°°°°JJJJJJRRRRRR                                    
                                        °°°°°°°°°°°°°°°°°°°°°°°JJJ°               °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRRRR¢R                                    
                                       °°°°       °°°°°°°°°°°°°°JJRJ°             J°°°°°°°°°°°°°°°°°J°°°°°°°°°°°°°°°JJJJJJRRRR¢°                                   
                                      °°°°            °°°°°°°°°°°JJJJJ°           °J°°°°°°°°°°°JJJJJJJ°°°°°°°°°°°°°°JJJJJJRRRR¢J                                   
                                     °°°              °°  °°°°°°°°°JJJJJ           J°°°°°°°°°°JJRRRJRRJ°°°°°°°°°°°°J°JJJJJRRRR¢J                                   
                                    °°°                  °°°°°°°°°°°JJJJJ          JJ°°°°°°°°JRRRRRRRRRJJJ°°°°°°°°°JJJJJJJRRRRRRJ°°J°°°°°                          
                                   °°°°                °   °°°°°°°°°°JJJJJ°         JJJ°°°°°JRRRRRRRRRJRRRRJJRRJJ°°°JJJJJJRRRRRR°°°°°°°°°°°                        
                                   °°°                     °°°°°°°°°°°JJJJJ°        °JJJJJJJRRRRRRRJRJJRJRRRRRRRRJJ°JJJJJJRRRRRRJ°°°°°°°°°°                        
                                  °°°                     °°°°°°°°°°°°°JJJJJJ         JJJJJRRRRRRRRJJJJJJJRRRRRRRRJ°°JJJJJRRRRRRJ°°°°°°°°°°°                       
                                 °°°°                     °°°°°°°°°°°°°JJJJJJJ         JJJRRRRRRRRRJJJJJJJRRRRRRRRR°°JJJJJRRRRRRJJ  °°°°°°°°                       
                                 °°°                      °° °°°°°°°°°°°JJJJJJJ        RJJRRRRRRRRRJJJJJJJJJRRRRRRRJ°JJJJRRRRRRRRJ   °°°°°°°                       
                                °°°°                     ° °°°°°°°°°°°°°°JJJJJJJ°      JJJRRRRRRRRJJJJJJJJJJJRRRRRRRJJJJJRRRRRRRRJ     °°°°°                       
                                °°°°         °           °°°°°°°°°°°°°°°°JJJJJJJJ°     °JJRRRRRRRRRJJJJJJJJJJJRRRRRRRJJJRRRRRRRRRJ     °°°°°                       
                               °°°°°°°                  °°°° °°°°°°°°°°°°JJJJJJJJJ°     JJJJRRRRRJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRJ     °°°°°                       
                               °°°°°°° °            °  °°°°°°°°°°°°°°°°°°JJJJJJJJJJ     JJJJJRRRJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRR     °°°°°                       
                               °°°°°°° °           °°  °°°°°°°°°°°°°°°°°JJJJJJJJJJRJ    JJJJRJRRRJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRR     °J°°°                       
                               °°°°°°°°°°°        °  °°°°°°°°°°°°°°°°°°°JJJJJJJJJJRR    JJJJJJJRRJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRR     °J°°°                       
                                °°°°°°°°°°°°     °°°°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJR°   °JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRJ    °J°°                        
                                J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJR°    RJJJJRJJJJJJJJJJJJJJJJJRRRRRRRRRRJRRRRRRRJ    J°°°                        
                                °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJRJ    JJJJJJJJJJJJJJJJJJJJJJJJRRJRRJRJJJRRRRRRRR   °J°°°                        
                                 °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJRJ    °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR   °J°°°                        
                                 °J°°°°°°JJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJ     JJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJRRRRRRR° °J°°°°                        
                               °°°JJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJ     JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJ°JJ°°°                         
                      °°°°°°°°°°JJRJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJ     JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJJ°°°°                         
                     °°        °°JRRRJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJ     JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJ°°°°                          
                    °          °°JJJRRRRJJJJJJJJJJ°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJ     °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°°°°°                          
                    °          °°JJJRRRRRJJJJJJJJJJJ°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJ°      JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRR°°°                            
                   °°          °°JJJRRRRJJJJJJJJJJJJJ°°J°°°°°°°°JJJJJJJJJJJJJJJJJJJJ       JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°                             
                   °°         °°°JJJJRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ       °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJ                             
                  °°     °    °°°JJJRRRJJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°        JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJ°                            
                  °°           °JJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°         JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR¢J                             
                  °°           °JJJJJRRJJJJJJJJJJJJJJJJJJJRJRRRRRRRRRRRRRRRRRJJJJ°          JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRR¢J                             
                  °°           JJJJJJRJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRJJJ            °JJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRR¢R                             
                  °°   °       JJJJJRRJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRJJ°            °JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRR¢R                             
                  °°   °      °JJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJJ°             JJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRR                             
                  °°  °°      °JJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJRRJJJ              JJRRRRRRJJJJJJJJJJRJJRRRRRRRRRRRRRRRRRRRR°                            
                  °°  °°      JJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRJJJJJJJ              °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢J                            
                  °   °°°     JJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRJJJJJJ°              °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢R                            
                  °°  °°°    °JJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJJJ                JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                            
                  °   °°°°   °JJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJJJJJJJJJ                JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°                           
                  °°  °°°°   °JJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJRJJJJJJJJ°                °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢RRRRRR°                           
                  °°  °°°°J  JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJJJ°                °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢RRRJRR°                           
                   ° °°°°°J°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJJ                  JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJRJ°°                           
                   °° °°°°°J°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJJ°                  JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJ°°°                           
                   °°  °°°°°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJJ°                  °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°°°°J                           
                    °     °°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJJ°                  °JRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJ°°°°°°JJ                          
                     °    °°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°                    JR¢RRRRRRRRRRRRRRRRRRRRJJJJJJJ°°°°°°°°JRR                          
                     °   °°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                    JRRRRRRRRRRRRRJRJJJJJJJJJJJ°°°°°°° °°JJJJ                          
                         °°°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                    °JJJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°  °°JJJJJ                          
                       ° °°JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                    °JJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°JJ                          
                        °°°JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                      JJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°J°                          
                         JJRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                      JRRRJJ°°°°°°°°°°°°°°°°°°°°°°°       °°°                           
                          JRRRRJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                      JRRRJ°°°°°°°°°°°°°°°°°°°°°°°       °°°                            
                          RRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                      °RRJJJJ°°°°°JJJJ°°°°°°°                                           
                         °RRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                       °RRRRRJJJJJJJJJ°°°°°°°°                                           
                         J¢RRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                        RRRRRJJJJJJ°°°°°°                                                
                         J¢RRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                        JRRRRJ°°°°°°°°°        °°                                        
                         R¢RRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                         °RRRRJ°°°°°°°°°     °°°°                                         
                        °R¢RRRR¢RRRRJJJJJJJJJJJRJRJJJJJJJJJJJJJJJJJJJJJJ°                          °JRRJ°°°°°°°°°                                                  
                        JRRRRRRRRRRRRRRRRJJJJRRRRRRRRRRRRJJJJJJJJJJJJJJJ°                             °°°°°°°°°°                                                   
                        J¢RRRRRRRRRRRRRRRRJJRRRRRRRRRRRRRRJJRRJJJJJJJJJ°°                                                                                          
                        R¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJ°                                                                                           
                       °RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJ°                                                                                           
                       JRRRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJ°                                                                                           
                       RRRRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                           
                       JRRRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                            
                      °JJRJRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                            
                      JJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                            
                      JJJJJRRRJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                            
                      JJJJJJRJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                             
                     °RRJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                             
                     JRRRJJ°°°°JJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°                                                                                             
                     RRRRRJJ°°°°°°JJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     RRRRJJJJ°°°°°°°JJJJJJJJRRRRRRRRRRRRRRRRRRRRRJJJ°                                                                                              
                     JRJJJ°JJJJJ°°°°°°°JJJJJJJJJJRRRRRRRRRRRRRJJJJJJ°                                                                                              
                     °JJJJ°°°°°°°°°°°°°°°JJJJJJJJJJJJJJRRRJJJJJJJJJ°°                                                                                              
                      JJJ°°°°°°°°°°°°°JJ°°°°°°°°JJRRJJJJJJJJJJJJJRJJ°                                                                                              
                      JJJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJ°°°                                                                                               
                       JJ°°°°     °°°°°°°°°°°°°°JJ°°°°  °°°°°°°°°°°°                                                                                               
                        J°°        °°°°°       °°°°JJ°°°°°°°°°°°°°°°                                                                                               
                         °°        °°°°°           °°°°JJ°JJJJJJJRJ                                                                                                
                          °°      °°°  °°°          °°°°°°°°JJRJJJJ                                                                                                
                            °°°°°°°°°  °°°         °°°°°  °°°JJJJJ°                                                                                                
                               °°°°°°              °°°°°°°°°°JJJJJ°                                                                                                
                                  °°    °°°°°°° ° °°°°°°°° °°JJJJJ                                                                                                 
                                       °°°°°°°°°°°°°°°°°°°°°°JJJJ°                                                                                                 
                                         °°°°°°°°°°°°°°°°°°°JJJJ°                                                                                                  
                                            °°°°°°°°°°°°°°°°JJJ                                                                                                    
                                                     °  °°                                                                                                         
`,`
                                                                                                                °°°°°°J°J°°                                        
                                                                                                             °°JJJJJJJJJJJJJ°                                      
                                                                                                        °°°°JJ°J°°°°°JJJJJJJJJJ                                    
                                                                                                   °°JJJJJ°°°°°°°°°°°°°°°°JJJJJJ                                   
                                                                                                 °°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJR°                                 
                                                                                                °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRR°                                
                                                                                              °°°°°°°°°°°°° °°°°°°°°°°°°°°°JJJJJJRR°                               
                                                                                             °°°°°°°°           °°°°°°°°°°°JJJJJJRRR                               
                                                                                            °°°°°°°             °°° °°°°JJJJJJJJJJRR°                              
                                                                                           °°°°°                °°°°°°°°°JJJJJJJJJRRJ                              
                                                                                          °°°°                  °°°°°°°JJJJJJJJJJJRRR                              
                                                                                         °°°°                ° °°°°°°°°JJJJJJJJJJJRRR                              
                                                                                        °°°°                  °°°°°°°°JJJJJJJJJJJJJRR                              
                                                                                       °°°               °    °°°°°°°°JJJJJJJJJJJJJRR                              
                                                                                      °°°°              °   °°°°°°°°°°°JJJJJJJJJJJJJR                              
                                                                                      °°°            °°°°°°°°°°°°°°°°J°°JJJJJJJJJJJRJ                              
                                                                                     °°°           °°°°°°  °°°°°°°°°°°°°JJJJJJJJJJJR°                              
                                                                                     °°°°   °°°°°°°°°°°°° °°°°°°°°°°°°°°JJJJJJJJJJJJ                               
                                                °°°°°°°°°°°                          °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJ°                               
                                         °°°°°°°°°°°°°°°°°°JJ                        J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJRRJRJ                                
                                       °°°°°°°°°°°°°°°°°°°°°JJ                       J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRR¢J                                
                                      °°°°°°°°°°°°°°°°°°°°°°JJJJ°                    °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRR¢R                                
                                     °°°°°°°°°°°° °°°°°°°°°°°°JJRJ°                  °J°°°°°°°°°°°°°°°°JJJ°°°°°°°°°°°°°°JJJJJJRRR¢R                                
                                    °°°°°°           °°°°°°°°°JJJJJJ°                 J°°°°°°°°°°°°JJJJRRRJ°°°°°°°°°°°°°°JJJJJRRRR¢°                               
                                    °°°                °°°°°°°°°JJJJJJ°               °J°°°°°°°°°°JRRRRRRRRRJ°°°°°°°°°°°JJJJJJRRRR¢J°°°°°                          
                                   °°°                   °°°°°°°°JJJJJJ°               J°°°°°°°°°JRRRRRRRRRRRJJJJJJJJ°°°JJJJJJRRRRRJJ°°°°°°°°                      
                                  °°°                    °°°°°°°°°°JJJJJJ              °JJ°°°°°°JRRRRRRRRRRRRRRRRRRRRJJ°JJJJJJRRRRRJJ°°°°°°°°°                     
                                 °°°                    °° °°°°°°°°°JJJJJJ°             JJJJJJ°JRRRRRRRRRRRRRRRRRRRRRRR°°JJJJJRRRRRJJ°°°°°°°°°°                    
                                 °°°                    °°° °°°°°°°°°JJJJJJ°             °JJJJJRRRRRRRRRRRRRRRRRRRRRRRRJ°JJJJJRRRRRRJ° °°°°°°°°                    
                                °°                      °   °°°°°°°°°°JJJJJJ°             RJJRRRRRRRRRJJRRRRRRRRRRRRRRRR°°JJJJR¢RRRRJ° ° °°°°°°°                   
                               °°°°                    °    °°°°°°°°°°JJJJJJJ°            JRJRRRRRRRRRRRRRRRRRRRRJRRRRRRJ°JJJJRRRRRRJJ    °°°°°°                   
                               °°°                         °°°°°°°°°°°°JJJJJJJJ           °RJRRRRRRRRRJRRRRRRRRJJJRRRRRRRJJJJRRRRRRRR°     °°°                     
                              °°°°                      °  °°°°°°°°°°°°°JJJJJJJJ           RJJRRRRRRRRJJRRJRRJRJRJJRRRRRRRJJRRRRRRRRR°    °°°°°                    
                              °°°°°                   ° °°°°°°°°°°°°°°°°JJJJJJJJJ          RJJRRRRRRRRJRJRRRJJJJJJJRRRRRRRRRRRRRRRRRRJ    °J°°°                    
                              °°°°°°                  °° °°°°°°°°°°°°°°JJJJJJJJJJ°         JRJRRRRRRRJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRJ    °J°°°                    
                             °°°°°°°°°      °  °°°    °°°°°°°°°°°°°°°°°JJJJJJJJJJR         °RJJRRRRRRJJJJJRJJJJJJJJJRRRRRRRRRRRRRRRRRR    °J°°°                    
                             °°°°°°°°°°       °°  °°°°°°°°°°°°°°°°°°°°°JJJJJJJJJRR°         RJJRRRRRJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRR    °J°°°                    
                              °°°°°°°°°°°      °°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJRJ         RJJRRRRRJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRR°   °J°°°                    
                              °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJRJ         JRJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRJRRRRRRRJ   °J°°                     
                              °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJRR         °RJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJRRRRRRRJ   J°°°                     
                               J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJR          RJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR  °J°°°                     
                               °J°°°°°°JJJJ°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJR          RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR°°J°°°°                     
                                JJ°°°JJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJ          JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJJJ°°°                      
                        °°°°°°°°JJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJ          °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJ°°°°                      
                     °°       J°RRJJJJJ°°JJJJJJJ°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJ           RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°°°°°                      
                    °         °°JRRRJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJ           RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°°°                        
                   °         °°°JJRRRRRJRRRRRRRJ°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJ           JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRR°°                         
                  °°         °°°JJJRRRJJJJJJJJRJJJ°°°°°°°°°°°°J°°JJJJJJJJJJJJJJJJJ°           °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°                         
                  °°         °°°JJJRRJJJJJJJJJJJJJJ°JJJ°J°JJJJJJJJJJJJJJJJJJJJJJJJ°            JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJ                         
                 °°          °°JJJRRRJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ             JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRJ                         
                 °°     °    °°JJJRRJJJJJJJJJJJJJJRRJJRJJJJJJJJJJJJJJJJJJJJJJJJJJ°             °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRR¢°                         
                 °°           JJJJRRJJJJJJJJJJJJJJRJJJJJJJJRRRRRRRRRRRRRRRRRJJJJ°               JJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRR¢J                         
                 °°          °JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJ°                 JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRR¢R                         
                 °°   °      °JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJJ°                 °JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRR¢R                         
                 °°   °      JJJJRRJJJJJJJJJJJJJJRJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                  °JJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRR¢R                         
                 °°° °°      JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                   JJRJJJJJJJJJJJJJJRRRJRRRRRRRRRRRRRRRRRRR¢°                        
                 °°  °°      JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJ°                   JJRRRRRRRJRRRRRRRRRRRRRRRRRRRRRRRRR¢RRRR¢J                        
                 °°  °°°    °JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJ°                   °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢R                        
                 °°  °°°    °JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°                    °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                        
                 °°  °°°°   JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJJJJJJJ°                     JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢RRRRRR°                       
                 °°  °°°°   JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRJJJJJJJ°                     °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢RRRRR°                       
                 °°  °°°°° °JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJRJJJJJJJJ°°                     °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢RRRRJ°                       
                 °°° °°°°J °JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJJ°                      °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJRJ°J                       
                  °° °°°°JJJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJJ°°                      °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJRJJJ°°J                       
                  °°   °°°°JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJJ°°                       °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°°°°J°                      
                   °     °°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJJ°°                       °JRRRR¢RRRRRRRRRRRRRRRRRRRRRJJJJJ°°°°°°°RJ                      
                   °°    °°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJ°                        °JRRRRRRRRRRRRRRRRRRRJJJJJJJJJ°°°°°°°°°JJJ                      
                    °    °°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°°                        °JJRRRRRRRRRRRRJJJJJJJJJJJJ°°°°°°   °°JJJJ                      
                     °  °°JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                         °JJJJJJJJJJJJJJJJJJJJJJ°°°°°°°° °°°°°°JJJ                      
                        °°JRJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                         °JJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°J°                      
                       °°°RRJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                          °JJJJJJJ°°°JJ°°°°°°°°°°°°°°°°°°    °°°°°                       
                       °JJRRJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                           JRRRJJ°°°°°°°°°°°°°°°°°°°°°°        °°                        
                        JJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                           °RRRJJ°°°°°°°°°°J°°°°°°°°°°         °                         
                        °RRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                           °RRJJJJJJJJJJJJ°°°°°°°°°                                      
                        °RRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                            °RRRRRRJJJJJJJ°°°°°°°°°                                       
                        JRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                             JRRRRJJJ°°J°°°°°°                                            
                        JRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                             JRRRRJ°°°°°°°°°        °°°                                   
                        RRRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                              JRRRJ°°°°°°°°       °°                                      
                       °RRRRR¢RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                JRRJ°°°°°J°°°°                                             
                       JRRRR¢RRRRRRRRRRJJJJJRRRRRRJJJJJJJJJJJJJJJJJJJJ°°                                   °°°°  °                                                 
                       JRRRR¢RRRRRRRRRRRJJJRRRRRRRRRJRRJJJRRJJJJJJJJJJ°°                                                                                           
                       R¢RRRRRRRRRRRRRRRRJRRRRRRRRRRRRRRRRRRRRJJJJJJJJ°°                                                                                           
                      °RRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJ°                                                                                            
                      JRRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                            
                      RRRRR¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                            
                      RRRRR¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                            
                     °JRRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°°                                                                                             
                     °JJRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     JJJJR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     JJJJJRRJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                    °RRJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°°                                                                                              
                    JRRRJJ°°JJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    RRRRJJ°°°°JJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    RRRRJJJ°°°°°°JJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                              
                    RRRJJJJJJJ°°°°°°JJJJJJJJJRRRRRRRRRRRRRRRRRRJJJ°°                                                                                               
                    JRJJ°JJJJJ°°°°°°°°°JJJJJJJJJJJJRRRRRRRJJJJJJJJ°°                                                                                               
                    °JJJ°J°°°°°°°°°°J°°°°°JJJJJJJJJJJJJJJJJJJJJJJJ°°                                                                                               
                     JJJ°°°°°°°°°°°°°°°°°°°°°°°°°JJJRRRJJJJJJJJJJJ°°                                                                                               
                     °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°°°°                                                                                                
                      JJ°°°°°°°°°°°°°°      °°°°°JJ°°°°°°°°°°°°°°°°                                                                                                
                       JJ°°      °°°°°          °°°°JJ°°°JJJ°JJJJJ°                                                                                                
                        °°°       ° °°°            °°°° °°°JJRRRRJ°                                                                                                
                          °°   °°°°  °°°°          °°°    °°JRJJJ°                                                                                                 
                            ° °°°°°°  °°°     °   °°°°   °°°JRJJJ°                                                                                                 
                              °°°°°  °°  °°°°°  ° °°°°  °°°°JJJJJ                                                                                                  
                                  ° °°°°°°°°°°°°°°°°°°°°°°°°JJJJ°                                                                                                  
                                      °°°°°°°°°°°°°°°°°°°°°°JJJJ                                                                                                   
                                         °°°°°°°°°°°°°°°°°°JJJJ                                                                                                    
                                             °°°°     °°°°°                                                                                                        
`,`
                                                                                                                   °°°°JJJJ°                                       
                                                                                                                °JJJJJJJJJJJJJ°                                    
                                                                                                           °°°JJJJ°°°J°JJJJJJJJJJ                                  
                                                                                                     °°°JJJJ°°°°°°°°°°°°°°°°JJJJJJ°                                
                                                                                                   °°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRJ                               
                                                                                                 °°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRJ                              
                                                                                                °°°°°°°°°° ° °    °°°°°°°°°°°JJJJJJRRJ                             
                                                                                               °°°°°°°°           °°°°°°°°°°JJJJJJJJRR                             
                                                                                              °°°°°°°              °°°°°°°°JJJJJJJJJRRJ                            
                                                                                             °°°°°                 °°°°°°°°JJJJJJJJJRRR                            
                                                                                            °°°°°                ° °°°°°°°JJJJJJJJJJJRR°                           
                                                                                           °°°°                    °°°°°°JJJJJJJJJJJJRR°                           
                                                                                          °°°                    °°°°°°°°JJJJJJJJJJJJRR°                           
                                                                                         °°°°              °°°  °°°°°°°°°JJJJJJJJJJJJRR°                           
                                                                                         °°               °°°°°°°°°°°°°°°°JJJJJJJJJJJJR°                           
                                                                                        °°°           ° °°°°°°°°°°°°°°°°°°JJJJJJJJJJJJR                            
                                                                                        °°°          °°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJ                            
                                                                                       °°°°    °  °°°°°°°°°° °°°°°°°°°°°°°°JJJJJJJJJJJ°                            
                                                °°°°°°°°°                              °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRJJJJ                             
                                          °°°°°°°°°°°°°°°JJ                            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRRR°                             
                                       °°°°°°°°°°°°°°°°°°°JJ°                          °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRR¢J                             
                                     °°°°°°°°°°°°°°°°°°°°°°JJJ°                         J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRRR¢J                             
                                    °°°°°°°°°° °°°°°°°°°°°°°JJJJJ°                      °°°°°°°°°°°°°°°°°°JJJJ°°°°°°°°°°°°°°JJJJJRRR¢R                             
                                   °°°°°°          °°°°°°°°°°JJJJJJ°                    °J°°°°°°°°°°°°JJJJRRRRJJ°°°°°°°°°°°JJJJJJRRRRR                             
                                  °°°°               °°°°°°°°°JJJJJJJ                    JJ°°°°°°°°°°JJRRRRRRRRRJ°°°°°°°°°°JJJJJJRRRRRJ°°°°°°°                     
                                  °°°                  °°°°°°°°°JJJJJJ                   °J°°°°°°°°°JRRRRRRRRRRRRRJJJJJJJJ°°JJJJJRRRRRJ°°°°°°°°°                   
                                 °°°                  °°°°°°°°°°°JJJJJJ°                  JJ°°°°°J°JRRRRRRRRRRRRRRRRRRRRRJJJJJJJJJ¢RRRJ°°°°°°°°°°                  
                                °°°                       °°°°°°°°JJJJJJ°                  JJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRJ°°JJJJJ¢RRRJ° °°°°°°°°°                 
                               °°°                   ° ° ° °°°°°°°°JJJJJJJ                  °JJJJJRRRRRRRRRRRRRRRRRRRRRRRRRJ°JJJJR¢RRRRJ °°°°°°°°°                 
                               °°°                        ° °°°°°°°°JJJJJJJ°                °RJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°JJJJRRRRRRJ° °°°°°°°°                 
                              °°°                         °°°°°°°°°°JJJJJJJJ°                RJJRRRRRRRRRRRRRRRRJJJJJRRRRRRRJ°JJJRRRRRRJ°   °°°°°                  
                             °°°°                       ° °°°°°°°°°°°°JJJJJJJ°               RRJRRRRRRRRRRRRRRRJJJJJJJRRRRRRRJJJRRRRRRRJ     °°°°°°                
                             °°°°°                      ° °°°°°°°°°°°°JJJJJJJJ°              JRJRRRRRRRRRJRRRRRJJJJJJJRRRRRRRRJRRRRRRRRR     °°°° °                
                            °°°°°                    ° °°°°°°°°°°°°°°°JJJJJJJJJ°             °RJJRRRRRRJJJRRRRJJJJJJJJJRRRRRRRRRRRRRRRRR°    °°°° °                
                            °°°°°                   ° °° °°°°°°°°°°°°JJJJJJJJJJJ              RRJRRRRRRJRJRRRRJJJJJJJJJRRRRRRRRRRRRRRRRRJ    °°°° °                
                            °°°°°°°      °° °°°  °  °°°°°°°°°°°°°°°°°°JJJJJJJJJR°             RRJRRRRRRJJJJRRRJJJJJJJJJRRRRRRRRRRRRR¢RRRJ    °°°° °                
                            °°°°°°°°°°      °  °  °°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJ             JRJJRRRRRJJJJJRRJJJJJJJJJJRRRRRRRRRRRRRRRRR    J°°° °                
                            °°°°°°°°°         °° °°°°°°°°°°°°°°°°°°°°JJJJJJJJJJRJ             °RJJRRRRJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRR   °J°°° °                
                            J°°°°°°°°°°° ° °°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJRR              RRJRRRRJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRR°  °J°°°                  
                            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJR°             JRJJRRRJJJJJJJJJJJJJJJJJJJJRRRRJJJJRRRRRRRJ  °J°°°°                 
                             J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJR°             JRJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ °JJ°°°                  
                             °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJ°             °RJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR°JJ°°°                   
                             °J°°°°°JJJJJJ°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJ°              RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJ°°°°                   
                              JJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°JJ°JJJJJJJJJJJJJJ°              RRJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°°°°                    
                      °°°°°°°°JJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJ°              JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°°°°                    
                   °°       °°JRRJJJ°JJJJJJJJJ°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJ°               RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°°                      
                  °         °°JJRRRJJRRRRJRRJJ°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJJ                RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ                       
                 °°°        °°JJJRRRJJJJJJJRRRJ°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJ                JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°                      
                 °°         °°JJJRRJJJJJJJJRJJJJJJJJJ°JJJJJJJJJJJJJJJJJJJJJJJJJJ°                °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRJ                      
                °°         °°°JJJRRJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                 JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRR¢R°                      
                °°     °   °°°°JRRRJJJJJJJJJJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                  JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRR¢¢°                      
                °°          °JJJRRJJJJJJJJJJJJJJRRJJJJJJRJJRRRRRRRRRRRRRRRJJJJ°                   JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRR¢¢J                      
                J°          JJJJRRJJJJJJJJJJJJJJRJJJJJJJJJJJRRRRRRRRRRRRRRJJ°                     °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRR¢R                      
                J°          JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRJJ°                      JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRR¢R                      
                J°  °°      JJJJRJJJJJJJJJJJJJJRJJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                      JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRR¢R                      
                J°  °°     °JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRJ°°                      °JJJJJJJJJJJJJJJRJJJRJRRRRRRRRRRRRRRRRRRR¢°                     
                J°° °°     °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°                       °JJRRRRRRJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢J                     
                J   °°     JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°                        JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢J                     
                J°  °°°    JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°                        JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢R                     
                J°  °°°    JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°°                        °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢¢RRRRR                     
                J°  °°°°  °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°°                        °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢RRRRR°                    
                J°  °°°°  °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°                          °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJRRJ°                    
                J°  °°°°J °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJ°°                          °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJ°J                    
                °J° °°°°J°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJJJJJJJ°°                          °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJRJJ°°°J                    
                 J°  °°°J°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJRJJJJJJJ°°                          °°JRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ°°°°°R°                   
                 °°    °°°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJJJJJJJJJ°°                            °JRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ°°°°°°°JR°                   
                  °     °°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJ°°                            °JR¢RRRRRRRRRRRRRRRRRJJJJJJJJJ°°°°°°°°°JJJ                   
                  °°    °°JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°°                            °JJRRRRRRRRRRRRJJJJJJJJJJJJ°°°°°°  °°°JJJJ                   
                   °   °°JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°°°                            °JJJJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°JJ°°J°                   
                    °  °°JRJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                             °JJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°J°°°J                    
                     ° °°JRJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                              °JJJJJ°°°°°°°°°°°°°°°°°°°°°°°°     °°°°°                    
                      °°JRRJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                              °°RRRJJ°°°°°°°°°°°°°°°°°°°°°°       °°°                     
                       JJRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                              °°RRRJJ°°°°°°°°JJ°°°°°°°°°°°                                
                       °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                               °RRJJJJJJJJJJJJ°°°°°°°°°°                                  
                       °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                °JRRRRJJJJ°JJ°°°°°°°° °                                    
                       °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                °JRRRRJJ°°°°°°°°°°                                         
                       JRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                 JRRRRJ°°°°°°°°°        °°                                 
                       JRRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                 °JRRRJ°°°°°°°°       °°                                   
                       RRRR¢RRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                    JJJJ°°°°°°°°°°                                          
                      °RRRR¢RRRRRRRRJRJJJJRJRJJJJJJJJJJJJJJJJJJJJJJJJJ°                                         ° °°                                               
                      °RRRR¢RRRRRRRRRRRJJRRRRRRRRRRRRJJJJRRJJJJJJJJJJ°°                                                                                            
                      JRRR¢RRRRRRRRRRRRJJRRRRRRRRRRRRRRRRRRRRJRRRRJJJ°°                                                                                            
                      RRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°°                                                                                            
                      RRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     °RRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     J¢RRR¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     JRRR¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                             
                     JRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    °RJRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    JRJJRRRJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    JRJJJJRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°°°                                                                                              
                    RRJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    RRRJJJ°°JJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                   °¢RRRJJ°°°°°JJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                               
                   JRRRJRJJ°°°°°°JJJJJJJJJJJRRRRRRRRRRRRRRRRRRRJJJ°°                                                                                               
                   °RRJJRRJJJJ°°°°°°JJJJJJJJJJJJJRRRRRRRRJJJJJJJJJ°°                                                                                               
                    RJJJJRJJ°°°°°J°°°°°°JJJRJJJJJJJJJJJJJJJJJJJJJJ°                                                                                                
                    JJJ°JJ°°°°°°°°°°°°°°°°°°°°JJJJJJJRJJJJJJJJJJJJ°                                                                                                
                    °JJ°JJ°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°°°°                                                                                                
                     JJ°J°°°°°°°°°°°° ° °°°°°°°°°°°°°°°°°°°°°°°°J°°                                                                                                
                      JJ°°°° ° °°°°°°°          °°JJJ°°°JJJ°°JJJJ°°                                                                                                
                      °J°°      °°°°°             °°°°°°°°°JJRRRJ°                                                                                                 
                        °°°     °°°°°°°°           °      °JRRJJ°°                                                                                                 
                          °°°°°°°°° °°°°          °°     °°°RJJJ°°                                                                                                 
                             °°°°°  °°           °°°  °°°° JRJJJ°                                                                                                  
                               °°°°°°°°°°°°°°°°°°°°°°° °°°°JJJJJ°                                                                                                  
                                     °°°°°°°°°°°°°°°°°°°°°°JJJJ°                                                                                                   
                                      °°°°°°°°°°°°°°°°°°°°°JJJ°                                                                                                    
                                           °°°°°°     °°°°°                                                                                                        
`,`
                                                                                                                   °°JJJJJJJJ°                                     
                                                                                                                °°JJJJJJJJJJJJJJ°                                  
                                                                                                        °°°°JJJJJ°°°°°°°°°°JJJJJJJ°                                
                                                                                                     °°°°JJJ°°°°°°°°°°°°°°°°°°JJJJJJ                               
                                                                                                    °°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJR                              
                                                                                                  °°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRR                             
                                                                                                 °°°°°°°°           °°°°°°°°°°JJJJJJRRR                            
                                                                                               °°°°°°°              °°°°°°°°°°JJJJJJJRRJ                           
                                                                                               °°°°°                 °°°°°°°°JJJJJJJJRRR                           
                                                                                             °°°°°                   °°°°°°°°JJJJJJJJRRR°                          
                                                                                             °°°°                  ° °°°°°°JJJJJJJJJJJRRJ                          
                                                                                            °°°              °° °° °°°°°°°JJJJJJJJJJJJRRR                          
                                                                                           °°°                °°°°°°°°°°°°°JJJJJJJJJJJRRR                          
                                                                                          °°°                 °°° °°°°°°°°°JJJJJJJJJJJJRR                          
                                                                                          °°               °°°°°°°°°°°°°°°°JJJJJJJJJJJRRJ                          
                                                                                         °°°           °°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJR°                          
                                                                                         °°°    °  ° °°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJ                           
                                                 °°°°°°                                  °°°°°°° °°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJ                           
                                            °°°°°°°°°°°°°°                               °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRRJJJ                            
                                       °°°°°°°°°°°°°°°°°JJJ                              °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRRRR                            
                                     °°°°°°°°°°°°°°°°°°°°JJJJ°                           J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRR¢¢                            
                                    °°°°°°°°°°°°°°°°°°°°°°JJRJJ°                         °°°°°°°°°°°°°°°°°°°°JJ°°°°°°°°°°°°°°°JJJJJRR¢¢°                           
                                   °°°°°°°°°     ° °°°°°°°°JJJJJJ°                        J°°°°°°°°°°°°°°°JJJJRRJ°°°°°°°°°°°°°JJJJJRRR¢J                           
                                  °°°°             ° °°°°°°°°JJJJJJ°                      °J°°°°°°°°°°°°JJJRRRRRRJ°°°°°°°°°°°JJJJJJRRR¢R                           
                                 °°°                 °°°°°°°°°JJJJJJ°                     °J°°°°°°°°°°°JRRRRRRRRRRRJJ°JJ°JJJJ°JJJJJRRRRRJ°°°°°°°°                  
                                °°°                  ° °°°°°°°°JJJJJJJ                     JJ°°°°°°°°JJRRRRRRRRRRRRRRRJRRRJJJ°JJJJJR¢RRRJ°°°°°°°°°                 
                               °°°                      °°°°°°°°°JJJJJJ°                    JJJ°JJJJ°JRRRRRRRRRRRRRRRRRRRRRRJ°JJJJJR¢RRRJ°°°°°°°°°°                
                               °°°°                      °°°°°°°°JJJJJJJ°                    °JJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRJ°JJJJR¢RRRJ°°°°°°°°°°                
                              °°°                       ° °° °°°°°JJJJJJJJ                    JJJJJRRRRRRRRRRRRRRJJJRRRRRRRRRJ°JJJJR¢RRRJ° °°°°°°°°°               
                             °°°                        °°°°°°°°°°°°JJJJJJJ                   RRJJRRRRRRRRRRRRRRJJJJJRRRRRRRRRJJJJJRRRRRJJ   °°°°°°°               
                             °°°                        °°°° °°°°°°°JJJJJJJJ                  J¢JJRRRRRRRRRRRRRJJJJJJRJRRRRRRRJJJJJRRRRRR°    °°°°°J               
                            °°°°                        °°°°°°°°°°°°°JJJJJJJJ                  RRJRRRRRRRJRRRRRJJJJJJJJJRRRRRRRJJJRRRRRRRJ    °°°°°J               
                            °°° °                  ° °°°°°°°°°°°°°°°°JJJJJJJJJ                 RRJRRRRRRJRRJRRRJJJJJJJJJRRRRRRRRRRRRRRRRRR    °°°° J               
                           °°°°°                  °  °°°°°°°°°°°°°°°°JJJJJJJJJ°                JRJJRRRRRJJJJRRRJJJJJJJJJRRRRRRRRRRRRRRRRRR    °°°° J               
                           °°°°°                 °  °°°°°°°°°°°°°°°°JJJJJJJJJJJ                °RJJRRRRRJRJJRRRJJJJJJJJJJRRRRRRRRRRRRRRRRR°   °J°°°J°              
                          °°°°°°°°              °°°°°°°°°°°°°°°°°°°JJJJJJJJJJJR°                RRJRRRRRRJJJJJRJJJJJJJJJJJRRRRRRRRRRRR¢RRRJ   °°°°°J               
                          °°°°°°°°°°         ° °°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJRJ                RRJRRRRRRJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRJ   °°°°°J               
                          °°°°°°°°°°°°   °° °°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJRJ                JRJJRRRRJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRR   °°°° °               
                           °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJRR                °RJJRRRJJJJJJJJJJJJJJJJJJJRRRRRJJJRRRRRRRRR  °J°°°°°               
                           °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJR                 RRJRRJRJJJJJJJJJJJJJJJJJJJJRRJJJJJJJRRRRRR° °J°°° °               
                           °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJR                 RRJRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°JJ°°°°                
                            J°°°°°JJJJJ°J°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJR                 JRJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJJ°°°                  
                            °JJ°°°JJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJ                 °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJ°°°°                  
                            °JJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJ                  RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRR°°°°°                  
                    °°°°°°°°°JJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJ                  RRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°°°                   
                  °°       °°JRRRJJJJRRJJRJJ°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJ                  JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°                     
                 °         °°JJRRRRRRRJRRRRRJ°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJ                  °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRR°                     
                °°°        °°JJRRRJJJJJJJJJRJJJ°JJ°°°°°JJJ°JJJJJJJJJJJJJJJJJJJJ°                   RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ                     
                °°        °°°JJRRJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ                    JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR¢R                     
               °°         °°°JJRRJJJJJJJJJJJJJRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                    JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR¢R                     
               °°     °   °°°°JRRJJJJJJJJJJJJJRRJJJJJJJRRRRRRRRRRRRRRRRRRJJJJ°                     °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRR¢R                     
               J°          °JJJRRJJJJJJJJJJJJJRJJJJJJJJJJJRRRRRRRRRRRRRRRJJ°                        JJJJJJJJJJJJJJJJJJJJJJJJJJJJRJRRRRRRRRRR¢¢                     
               J°          JJJJRJJJJJJJJJJJJJJRJJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                        JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRR¢¢°                    
               J°   °      JJJJRJJJJJJJJJJJJJJRRJJJJJJJJJJJJRRRRRRRRRRRRJJ°°                        °JJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRR¢J                    
              °J°  °°     °JJJRRJJJJJJJJJJJJJJRJJJJJJJJJJJJJRRRRRRRRRRRRJJ°°                        °JJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRR¢R                    
              °J°  °°     °JJJRRJJJJJJJJJJJJJJRJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                          JJJJJJJJJJJJRJRRJRRRRRRRRRRRRRRRRRRRRRRR¢R                    
              °J°° °°     JJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJJ°                          °JJRRRRRRJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢                    
               J°  °°°    JJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRJJ°°                          °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢°                   
               J°  °°°    JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°°                          °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                   
               J°  °°°°   JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJRRRRRJJJ°°                           JJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢¢RRRRJ                   
               J° °°°°°  °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJRRRRRJJJ°                            °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ                   
               J°  °°°°° °JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRJJJJJJ°                            °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJRJJ°                  
               °J  °°°°° °JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRJJJJJ°°                            °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJ°°°                  
                J° °°°°JJJJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJRJRJJJJ°°                             °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°°JJ                  
                J°  °°°°°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJRJJJJJJJJ°°                              °JJRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°JJ°°JR                  
                °°    °°°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJ°°                              °JJRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ°°°°°°°°JR                  
                 J°    °°JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°°                              °°JRRRRRRRRRRRRRRRRJJJJJJJJJJJ°°°°° °°°JJJ°                 
                 °°    °°JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°°°                               °JJRRRRRRRJRRJJJJJJJJJJJJJ°°°°°° °°°JJ°JJ                  
                  °   °°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                               °JJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°JJJJ°°J                  
                   °  °°JRJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                               °°JJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°JJ°°°                  
                    ° °°JRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                 °JRJJJ°°°°°°°°°°°°°°°°°°°°°°°      °J°°                   
                     °°JRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                 °°RRRJJ°°°°°°°°°°°°°°°°°°°°°       °°°                    
                      JJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                 °°RRJJJ°°°°JJJJJJ°°°°°°°°°°                               
                       JRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                 °JRRRRJJJJJJJJJ°°°°°°°°°°                                 
                       RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                  °JRRRRRJJJJ°°°°°°°°°°                                     
                      °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                   °JRRRRJ°°°°°°°°°         °°°                             
                      °RRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                   °JRRRR°°°°°°°°°         °                                
                      JRRR¢RRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                     JRRR°°°°°°°°°                                          
                      JRRR¢RRRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                      °JJ°°°°°°°°°°°                                        
                      RRRR¢RRRRRRRRRRJJJJRRJRRJRRRRJJJJJRRRJJJJJJJJJ°°°                                                                                            
                      RRRR¢RRRRRRRRRRRJJRRRRRRRRRRRRRRRRRRJRJRRRRJJJ°°                                                                                             
                     °RRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                             
                     JRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                             
                     JRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                             
                     RRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    °RRRR¢¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    °RRR¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    JJRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    JJJR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    JJJJRRJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    RJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                               
                   °RRJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                               
                   J¢RRJJJ°°JJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                               
                   RRRRJJJ°°°°°JJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRJJJJ°°                                                                                               
                   RRRJJRJJ°°°°°°°JJJJJJJJJJJRJRRRRRRRRRRRJJJJJJJ°°                                                                                                
                   JRJJJRRJJJJ°°°°°°°JJJJJJJJJJJJJJJJRRJJJJJJJJJJ°°                                                                                                
                   °JJJJRJJ°°°°°°°°°°°°°°°°°JJJRRJJJJJJJJJJJJJJJJ°°                                                                                                
                    JJ°JRJ°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJ°°°°JJ°J°°                                                                                                
                    JJ°JR°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°J°°                                                                                                
                    °J°JJ°°°°°°°°°°°    °  ° °°°°J°°°°°°°°°°°JJJJ°                                                                                                 
                     °JJJ°°     °°°°             °°°°°°°°°JJJJRR°°                                                                                                 
                      °J°°     °°°°°°°             °     °°JRRJJ°°                                                                                                 
                        °°°   °°°° °°°°                 °° JRJJJ°°                                                                                                 
                          °°°°°°°° °°°°           °    °°° JRJJJ°                                                                                                  
                            °°°°°   °° °°°°°  °   ° °   °°°JJJJ°°                                                                                                  
                               °°° °°°°°°°°°°°°°°°°°°°°°°°°JRJJ°                                                                                                   
                                      °°°°°°°°°°°°°°°°°°°°°JJJ°                                                                                                    
                                        °°°°°°°°°    °°°°°°°                                                                                                       
`,`
                                                                                                                    °JJJJJJJJ°°                                    
                                                                                                                 °JJJJJJJJJJJJJJJ°                                 
                                                                                                        °°°°°JJJJJ°°°°°°°°°JJJJJJJJ                                
                                                                                                     °°°°°JJ°°°°°°°°°°°°°°°°°°°JJJJJ°                              
                                                                                                    °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRJ                             
                                                                                                  °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRJ                            
                                                                                                 °°°°°°°°          ° °°°°°°°°°°JJJJJJRR°                           
                                                                                                °°°°°°°              °°°°°°°°°JJJJJJJJRR                           
                                                                                               °°°°°                  °°°°°°°°JJJJJJJJRRJ                          
                                                                                              °°°°                 ° °°°°°°°°JJJJJJJJRRRR                          
                                                                                             °°°°                   ° °°°°°°JJJJJJJJJJJRR                          
                                                                                            °°°°             °° ° °°°°°°°°°JJJJJJJJJJJJRR°                         
                                                                                           °°°                °°°° °°°°°°°°JJJJJJJJJJJJRR°                         
                                                                                          °°°                 °°° °°°°°°°°°JJJJJJJJJJJJRR°                         
                                                                                          °°°               °°°°°°°°°°°°°°°°JJJJJJJJJJJJR                          
                                                                                          °°            °°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJR                          
                                                                                         °°°°    °  °°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRJJJJJ                          
                                               °°°°°°°°                                  °°°°°°°° °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRJJJJ                           
                                          °°°°°°°°°°°°°JJ                                °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJRRJJ°                           
                                      °°°°°°°°°°°°°°°°°°JJ°                              °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRR¢J                           
                                    °°°°°°°°°°°°°°°°°°°°°JJJJ°                           °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJRR¢J                           
                                   °°°°°°°°°° °°° °°°°°°°°JJJJJ°                          J°°°°°°°°°°°°°°°°°°JJJ°°°°°°°°°°°°°°°JJJJJRR¢R                           
                                  °°°°°°°         ° °°°°°°°JJJJJJ°                        °°°°°°°°°°°°°°°°JJJJRRRJ°°°°°°°°°°°°JJJJJJRRRR                           
                                 °°°°              °°°°°°°°°JJJJJJJ°                      °J°°°°°°°°°°°°JJJRRRRRRRJ°°°°°°°°°°°JJJJJJRRR¢°                          
                                °°°°                °°°°°°°°°°JJJJJJ°                      JJ°°°°°°°°°°JJRRRRRRRRRRRJJJJJJJJJJJJJJJJRRRRJ°°°°°°°°°                 
                                °°°                    °°°°°°°°JJJJJJ°                      JJ°°°°°°°°JJRRRRRRRRRRRRRRRRRRRJJJJJJJJJRRRRJ°°°°°°°°°                 
                               °°°                    ° °°°°°°°°JJJJJJJ°                    °JJJ°J°JJJRRRRRRRRRRRRRRRRRRRRRRRJ°JJJJJR¢RRJ°°°°°°°°°°                
                              °°°°                       °°°°°°°°JJJJJJJ°                    °JJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRJ°JJJJR¢RRRJ °°°°°°°°°               
                             °°°°                        °°°°°°°°°°JJJJJJJ                    °RJJJJRRRRRRRRRRRRJRJJRRRRRRRRRRJ°JJJJR¢RRRJ° °°°°°°°°               
                             °°°                       °°°° °°°°°°°JJJJJJJJ                    RRJRRRRRRRRRRRRRJRJJJJJRRRRRRRRJ°JJJJR¢RRRJ°  °°°°°°°               
                            °°°                        °°° °°°°°°°°°JJJJJJJJ                   RRJRRRRRRRRJRRRRJJJJJJJJJRRRRRRRJJJJRRRRRRJ     °°°°°°              
                           °°°°                        °°°°°°°°°°°°°JJJJJJJJJ                  JRJJRRRRRRRRRRRRRJJJJJJJJJRRRRRRRJJJRRRRRRR     °°°°°J              
                           °°°°°                     °°°°°°°°°°°°°°°JJJJJJJJJJ                 °¢JJRRRRRRJRJJRRJJJJJJJJJJRRRRRRRRRRRRR¢RRR°    °°°°°J              
                          °°°°°                  ° °°°°°°°°°°°°°°°°°JJJJJJJJJJ                  RRJRRRRRJJJJJRRJJJJJJJJJJRRRRRRRRRRRRR¢RRRJ    J°°°°J              
                          °°°°°                 °  °°°°°°°°°°°°°°°°JJJJJJJJJJJJ                 RRJRRRRRRJJJJRRJJJJJJJJJJJRRRRRRRRRRRRRRRRR    J°°°°J              
                          °°°°°°° °          ° °°°°°°°°°°°°°°°°°°°JJJJJJJJJJJRJ                 RRJJRRRRRJJJJRRJJJJJJJJJJJRRRRRRRRRRRRRRRRR   °J°°°°J              
                          °°°°°°°° °    °°°°°  °°°°°°°°°°°°°°°°°°°JJJJJJJJJJJRR                 °RJJRRRRRJJJJJRJJJJJJJJJJJJRRRRRRRRRRRRRRRR   °J°°°°J              
                          J°°°°°°°°°°   °°  °°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJR                  RRJRRRRJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRR°  °J°°°°°              
                          °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJR°                 RRJJRRRJJJJJJJJJJJJJJJJJJJRRRRRRRJJRRRRRRRJ  °J°°°°°              
                          °J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJR°                 JRJJRRJRRJJJJJJJJJJJJJJJJJJRJJJJRJJJRRRRRRR °J°°° °               
                           J°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJ                 °RJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRR°JJ°°° °               
                           °J°°°°JJJJJJJ°°°°°°°°°°°°°°°°°°°°°°J°°°JJJJJJJJJJJJJJ                  RRJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJJ°°°° °               
                            JJ°°JJJJJJJJJJ°°°°°°°°°°°°°°°°°°°°J°°JJJJJJJJJJJJJJJ                  RR°JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJJ°°°                  
                            JJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°°J°JJJJJJJJJJJJJJJJ                  JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°°°°                  
                    °°°°°°°°JJJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJ°                  °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°°°                   
                 °°       °°JRRRRJJJRRRRRRJJ°°°°°°°°°°°°°°°°°JJJJJJJJJJJJJJJJJJ                    RRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJ°                    
                °°        °°JJJRRRJRRRRRJRRJJ°°J°°°°°°°°°°°JJJJJJJJJJJJJJJJJJJJ                    JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRJ°                    
                °°        °°JJJRRJJJJJJJJJJJJJJJJJJ°°JJJJJJJJJJJJJJJJJJJJJJJJJJ                    JRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR°                    
               °°°        °°JJJRRJJJJJJJJJJJJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                    °RJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRR¢RJ                    
               °°         °°°JJRJJJJJJJJJJJJJJRRRRJJJJJJJJJJRRRRRJJJJJRRRJJJJ°                      JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRR¢°                    
               °°    °°  °°°°JJRJJJJJJJJJJJJJJRJJJJJJJRJRJRRRRRRRRRRRRRRRJJJ°                       JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRR¢J                    
              °°°         °°JJRRJJJJJJJJJJJJJRRJJJJJJJJJJJJRRRRRRRRRRRRRRJ°°                        °JJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRR¢R                    
              °°°         °JJJRRJJJJJJJJJJJJJRRJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                         °JJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRR¢R                    
              °J°         JJJJRRJJJJJJJJJJJJJRRJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                          JJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRR¢R                    
              °J°  °°     JJJJRRJJJJJJJJJJJJJRJJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                          JJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRR¢°                   
              JJ°  °°     JJJRRJJJJJJJJJJJJJJRJJJJJJJJJJJJJRRRRRRRRRRRRRJJ°                          °JJJJJJJJJJJJJJRJJRRRRRRRRRRRRRRRRRRRRRRR¢J                   
              JJ° °°°     JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJRJ°°                          °JJJRRRRRRJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢R                   
              °J°  °°     JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°°                           JJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢R                   
              °J°  °°°   °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°                            JJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR                   
              °J°  °°°   °JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRRRRJJJ°                            °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR¢¢¢RRRRR°                  
               J° °°°°°  °JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRJRRRJJJ°°                            °°JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJRRRJ                  
               J°  °°°J  JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRJRJJJJ°°                             °JRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ                  
               J°  °°°°° JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRRRRRJJJJJJ°                              °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJ°J                  
               °J  °°°°J°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRRJRRJRJJJJ°°                              °JJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJJ°°J°                 
                J°  °°°J°JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRRJJJJJJJJJJ°°                              °°JRRRRRRRRRRRRRRRRRRRRRRRRRRRJJJJJ°JRJ°°R°                 
                J°    °°°JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJJ°°                               °JJRRRRRRRRRRRRRRRRRRRRRJRRJJJJJ°°°°°°°JJJ                 
                °J     °°JJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRRJJJJJJJJJ°°°                               °JJRRRRRRRRRRRRRRRRJJJJJJJJJJ°°°°°  °J°JJJ                 
                 °°    °JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJRJJJJJJJJJJ°°°                               °°JRRRRRRRJJRRJJJJJJJJJJJJJ°°°°°° °°JJJ°JJ                 
                  °   °°JJJRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                °°JJJJJJJJJJJJJJJJJJJJ°°°°°°°°°°°°°JJJJ°J°                 
                   °  °°JJJRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                 °JJJJJJJJJJJJJJJ°°°°°°°°°°°°°°°°° °°JJ°°                  
                      °JRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                 °°JJJJ°°°°°°°°°°°°°°°°°°°°°°°°     °JJ°°                  
                     °°JRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°                                 °°JRRJJ°°°°°°°°°°°°°°°°°°°°°°       °°°                   
                      JJRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                 °°JRJJJ°°°JJJJJJJ°°°°°°°°°°                               
                      °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                   °JRRRRJJJJJJJJ°°°°°°°°°°°                                
                      °RRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                   °JRRRRJJJJ°°°°°°°°°°° °                                  
                      JRRRRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                   °JRRRRJ°°°°°°°°°          °°                             
                      JRRR¢RRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°°                                    °JRRRJ°°°°°°°°         °°                               
                      JRRR¢RRRJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ°°                                     °JRRJ°°°°°°°°°                                         
                      RRRR¢RRRRRRRJJJJJJJRJJJJJJJJJJJJJJRJJJJJJJJJJJJ°                                        °J°°°°°°°°°°°                                        
                      RRRR¢RRRRRRRRRRJJJRRRRRRRJRRJJJJJRRRJRJJJRRJJJ°°                                                                                             
                     °RRRRRRRRRRRRRRRRJJRRRRRRRRRRRRRRRRRRRRRRRRRJJJ°°                                                                                             
                     JRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                             
                     JRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJJ°°                                                                                             
                     RRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    °RRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                              
                    J¢RR¢¢¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR°°°                                                                                              
                    JRRR¢¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    JRRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    JJRR¢RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                              
                    RJJJRJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                               
                   °RJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                               
                   JRRJJJJJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°                                                                                               
                   R¢RJJJJ°°JJJJJJJJJRRRRRRRRRRRRRRRRRRRRRRRRRRRJ°°°                                                                                               
                   RRRRJJJ°°°°°JJJJJJJJJJRRRRRRRRRRRRRRRRRRRRRJJJJ°                                                                                                
                   RRRJRRJJ°°°°°°°JJJJJJJJJJJJJJJRRRRRRRRJJJJJJJJ°°                                                                                                
                   RRJJRRRJJJJ°°°°°°°JJJJJJJJJJJJJJJJRJJJJJJJJJJJ°°                                                                                                
                   °JJJJRJJ°°°°°°°J°°°°°°°°°°°JJJRRJJJJJJJJJJJJJJ°°                                                                                                
                   °JJ°RRJ°°°°°°°°°°°°°°°°°°°°°°°°°°J°°°°°°°°JJJ°°°                                                                                                
                    JJ°RR°°°°°°°°°°°°°°°°°°°°°J°°°°°°°°°°°°°°°°J°°°                                                                                                
                    °J°JJ°°°°°°°°°°°          °°°°JJ°°°°°JJ°JJJJ°°                                                                                                 
                     °JJJ°°     °°°°             °°°° °°°°JJRRRR°°                                                                                                 
                      °J°°      °°°°°°                   °°JRJJJ°°                                                                                                 
                        °°    °°°°°°°°°                 °°°JRJJJ°                                                                                                  
                           °°°°°°° °°             °    °° °JRJJ°°                                                                                                  
                             °°°°   °°°°°°°°°°   ° °°°°°°°°JJJJ°                                                                                                   
                                °°°°°°°°°°°°°°°°°°°°°°°°°°°JJJJ                                                                                                    
                                      °°°°°°°°°°°°°°°°°°°°°J°J                                                                                                     
                                         °°°°°°°  °  °°°°°                                                                                                         
`]

let i = 0;

function animate() {
  document.getElementById("ascii").textContent = frames[i];
  i = (i + 1) % frames.length;
}

animate();
setInterval(animate, 80);
